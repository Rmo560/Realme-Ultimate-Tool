# Realme Ultimate Tool V4.6 ProGuard Rules
-keep class com.rutool.android.** { *; }
-dontwarn android.hardware.usb.**
