plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rutool.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rutool.android"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "4.6"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
