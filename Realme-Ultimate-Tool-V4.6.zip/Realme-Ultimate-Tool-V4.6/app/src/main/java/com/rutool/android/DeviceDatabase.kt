package com.rutool.android

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class DeviceEntry(
    val brand: String,
    val model: String,
    val marketingName: String,
    val soc: String,
    val platform: String,
    val androidVersions: String,
    val flashFamily: String,
    val status: String,
    val notes: String,
    val productCodes: List<String> = emptyList(),
    val regionStatus: String = "not_verified",
    val partitionLayoutStatus: String = "not_verified",
    val firmwareSourceStatus: String = "not_verified"
)

data class SmartIdentification(
    val brand: String,
    val model: String,
    val marketingName: String,
    val soc: String,
    val platform: String,
    val androidVersions: String,
    val flashFamily: String,
    val regionHint: String,
    val sourceNote: String,
    val notes: String,
    val matchedVia: String = "",
    val productCode: String = ""
)

class DeviceDatabase(context: Context) {
    private val entries: List<DeviceEntry>
    val notice: String

    // Embedded fallback map linking Samsung Build.PRODUCT codenames -> SM base model
    private val samsungProductToSm = linkedMapOf(
        "pa3q" to "SM-S938",
        "pa2q" to "SM-S936",
        "pa1q" to "SM-S931",
        "e3q" to "SM-S928",
        "e2s" to "SM-S926",
        "e2q" to "SM-S926",
        "e1s" to "SM-S921",
        "e1q" to "SM-S921",
        "r12s" to "SM-S721",
        "dm3q" to "SM-S918",
        "dm2q" to "SM-S916",
        "dm1q" to "SM-S911",
        "r11s" to "SM-S711",
        "r11q" to "SM-S711",
        "b0s" to "SM-S908",
        "b0q" to "SM-S908",
        "g0s" to "SM-S906",
        "g0q" to "SM-S906",
        "r0s" to "SM-S901",
        "r0q" to "SM-S901",
        "p3s" to "SM-G998",
        "p3q" to "SM-G998",
        "c2s" to "SM-N986",
        "c2q" to "SM-N986",
        "q6q" to "SM-F956",
        "b6q" to "SM-F741",
        "q5q" to "SM-F946",
        "b5q" to "SM-F731",
        "a55x" to "SM-A556",
        "a54x" to "SM-A546",
        "a53x" to "SM-A536",
        "a52sxq" to "SM-A528",
        "a73xq" to "SM-A736",
        "a35x" to "SM-A356",
        "a34x" to "SM-A346",
        "a33x" to "SM-A336",
        "a25x" to "SM-A256",
        "a24" to "SM-A245",
        "a15x" to "SM-A156",
        "a15" to "SM-A155",
        "a14x" to "SM-A146",
        "a14" to "SM-A145",
        "a05s" to "SM-A057",
        "a05m" to "SM-A055",
        "a13" to "SM-A135",
        "m34x" to "SM-M346",
        "m55xq" to "SM-M556",
        "gts9wifi" to "SM-X710",
        "gts9" to "SM-X710"
    )

    init {
        val raw = context.assets.open("realme_devices.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        notice = root.optString("notice")
        val array = root.getJSONArray("devices")
        val list = mutableListOf<DeviceEntry>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            list.add(
                DeviceEntry(
                    brand = o.optString("brand", "Realme"),
                    model = o.optString("model"),
                    marketingName = o.optString("marketing_name"),
                    soc = o.optString("soc"),
                    platform = o.optString("platform"),
                    androidVersions = o.optString("android_versions", "Android (check device)"),
                    flashFamily = o.optString("flash_family"),
                    status = o.optString("status"),
                    notes = o.optString("notes"),
                    productCodes = readStringArray(o.optJSONArray("product_codes")),
                    regionStatus = o.optString("region_status", "not_verified"),
                    partitionLayoutStatus = o.optString("partition_layout_status", "not_verified"),
                    firmwareSourceStatus = o.optString("firmware_source_status", "not_verified")
                )
            )
        }
        entries = list
    }

    private fun readStringArray(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        val res = ArrayList<String>(arr.length())
        for (i in 0 until arr.length()) {
            val v = arr.optString(i).trim()
            if (v.isNotEmpty()) res.add(v)
        }
        return res
    }

    fun find(model: String): DeviceEntry? {
        val q = model.trim()
        return entries.firstOrNull { entry ->
            entry.model.equals(q, ignoreCase = true) ||
                entry.marketingName.equals(q, ignoreCase = true) ||
                entry.productCodes.any { it.equals(q, ignoreCase = true) }
        }
    }

    private fun normalizeCompact(s: String): String =
        s.lowercase(Locale.US).replace(Regex("[^a-z0-9]"), "")

    private fun scoreEntry(
        item: DeviceEntry,
        rawLower: String,
        compactQuery: String,
        tokens: List<String>
    ): Int {
        val mLower = item.model.lowercase(Locale.US)
        val nLower = item.marketingName.lowercase(Locale.US)
        val bLower = item.brand.lowercase(Locale.US)
        val sLower = item.soc.lowercase(Locale.US)
        val pLower = item.platform.lowercase(Locale.US)
        val mCompact = normalizeCompact(item.model)
        val nCompact = normalizeCompact(item.marketingName)
        val nShortCompact = normalizeCompact(
            item.marketingName.removePrefix("Samsung ").removePrefix("Realme ").removePrefix("Galaxy ")
        )
        val prodLowers = item.productCodes.map { it.lowercase(Locale.US) }

        var score = 0
        if (mLower == rawLower || nLower == rawLower) score += 120
        if (mCompact == compactQuery || nCompact == compactQuery) score += 110
        if (mLower.startsWith(rawLower) || (compactQuery.isNotEmpty() && mCompact.startsWith(compactQuery))) score += 85
        if (nLower.startsWith(rawLower) || (compactQuery.isNotEmpty() && nShortCompact.startsWith(compactQuery))) score += 75
        if (prodLowers.any { it == rawLower || it.startsWith(rawLower) }) score += 65
        if (mLower.contains(rawLower) || nLower.contains(rawLower)) score += 45
        if (compactQuery.isNotEmpty() && (mCompact.contains(compactQuery) || nCompact.contains(compactQuery))) score += 40
        if (prodLowers.any { it.contains(rawLower) }) score += 35
        if (sLower.contains(rawLower) || pLower.contains(rawLower)) score += 20

        if (score == 0 && tokens.size > 1) {
            val haystack = "$bLower $nLower $mLower $sLower $pLower ${prodLowers.joinToString(" ")}"
            if (tokens.all { tok -> haystack.contains(tok) }) {
                score = 32
            }
        } else if (tokens.size > 1 && score > 0) {
            val haystack = "$bLower $nLower $mLower $sLower $pLower ${prodLowers.joinToString(" ")}"
            if (tokens.all { tok -> haystack.contains(tok) }) {
                score += 18
            }
        }
        return score
    }

    /**
     * Ranked partial search across model numbers (SM-/RMX), marketing names,
     * Build.PRODUCT codenames, SoC, and multi-word queries (e.g. "a54", "s24 ultra", "rmx 36").
     */
    fun search(query: String, brandFilter: String? = null, includeAllWhenBlank: Boolean = false): List<DeviceEntry> {
        val q = query.trim()
        val pool = if (brandFilter.isNullOrBlank() || brandFilter.equals("ALL", ignoreCase = true)) {
            entries
        } else {
            byBrand(brandFilter)
        }
        if (q.isBlank()) return if (includeAllWhenBlank) pool else emptyList()

        val rawLower = q.lowercase(Locale.US)
        val compactQuery = normalizeCompact(q)
        val tokens = rawLower.split(Regex("\\s+")).filter { it.isNotBlank() }

        return pool
            .mapNotNull { item ->
                val sc = scoreEntry(item, rawLower, compactQuery, tokens)
                if (sc > 0) item to sc else null
            }
            .sortedWith(
                compareByDescending<Pair<DeviceEntry, Int>> { it.second }
                    .thenBy { it.first.brand }
                    .thenBy { it.first.marketingName }
            )
            .map { it.first }
    }

    fun byBrand(brand: String): List<DeviceEntry> =
        entries.filter { it.brand.equals(brand, ignoreCase = true) }

    fun allSupported(brandFilter: String? = null): List<DeviceEntry> =
        search("", brandFilter = brandFilter, includeAllWhenBlank = true)
            .sortedWith(compareBy<DeviceEntry> { it.brand }.thenBy { it.marketingName })

    fun realmeCatalog(): List<DeviceEntry> = byBrand("Realme")
    fun samsungCatalog(): List<DeviceEntry> = byBrand("Samsung")
    fun all(): List<DeviceEntry> = entries
    fun count(): Int = entries.size

    fun isSamsungDevice(
        brand: String = Build.BRAND,
        manufacturer: String = Build.MANUFACTURER,
        model: String = Build.MODEL,
        product: String = Build.PRODUCT
    ): Boolean {
        val mUpper = model.uppercase(Locale.US)
        val pLower = product.lowercase(Locale.US)
        return brand.equals("samsung", ignoreCase = true) ||
            manufacturer.equals("samsung", ignoreCase = true) ||
            mUpper.startsWith("SM-") ||
            mUpper.startsWith("GT-") ||
            mUpper.startsWith("SC-") ||
            samsungProductToSm.keys.any { pLower == it || pLower.startsWith(it) }
    }

    /**
     * Programmatically identifies the current Android device using Build.MODEL and Build.PRODUCT.
     */
    fun identifyCurrentDevice(): SmartIdentification? = identifyFromBuild(
        buildModel = Build.MODEL,
        buildProduct = Build.PRODUCT,
        buildDevice = Build.DEVICE,
        buildBrand = Build.BRAND
    )

    /**
     * Programmatic recognition pipeline combining Build.MODEL, Build.PRODUCT, and Build.DEVICE.
     */
    fun identifyFromBuild(
        buildModel: String,
        buildProduct: String,
        buildDevice: String = "",
        buildBrand: String = ""
    ): SmartIdentification? {
        val byModel = identifySmart(buildModel)
        if (byModel != null) {
            val productHint = decodeSamsungProductVariant(buildProduct)
            val combinedRegion = listOf(byModel.regionHint, productHint)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" | ")
            return byModel.copy(
                regionHint = combinedRegion,
                matchedVia = "Build.MODEL ($buildModel)",
                productCode = buildProduct
            )
        }

        val byProduct = identifyByProduct(buildProduct)
        if (byProduct != null) {
            return byProduct.copy(
                matchedVia = "Build.PRODUCT ($buildProduct)",
                productCode = buildProduct
            )
        }

        if (buildDevice.isNotBlank()) {
            val byDevice = identifyByProduct(buildDevice)
            if (byDevice != null) {
                return byDevice.copy(
                    matchedVia = "Build.DEVICE ($buildDevice)",
                    productCode = buildProduct.ifBlank { buildDevice }
                )
            }
        }

        if (buildBrand.equals("samsung", ignoreCase = true)) {
            return SmartIdentification(
                brand = "Samsung",
                model = buildModel.ifBlank { "SM-UNKNOWN" },
                marketingName = "Samsung Galaxy ($buildModel)",
                soc = decodeSocHint("${Build.HARDWARE} ${Build.BOARD}"),
                platform = "Samsung Android",
                androidVersions = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                flashFamily = "Samsung Odin / Download Mode (04E8)",
                regionHint = decodeSamsungProductVariant(buildProduct).ifBlank { decodeSamsungSuffix(buildModel) },
                sourceNote = "Detected via Build.BRAND/MODEL/PRODUCT",
                notes = "Verify binary BIT/SW REV & CSC before servicing.",
                matchedVia = "Build.BRAND + Build.PRODUCT",
                productCode = buildProduct
            )
        }
        return null
    }

    /**
     * Matches Build.PRODUCT / Build.DEVICE codenames (e.g. "e3qxxx", "a54xnsxx", "dm3qeea").
     * Sorted longest-key first so prefixes like "a15x" match before "a15".
     */
    fun identifyByProduct(product: String): SmartIdentification? {
        val clean = product.trim().lowercase(Locale.US)
        if (clean.isBlank()) return null

        // 1. Direct match or prefix match against catalog product_codes (longest code first)
        val rankedEntries = entries
            .flatMap { entry -> entry.productCodes.map { code -> entry to code.lowercase(Locale.US) } }
            .sortedByDescending { it.second.length }

        val catalogHit = rankedEntries.firstOrNull { (_, code) ->
            clean == code || (code.length >= 3 && clean.startsWith(code))
        }
        if (catalogHit != null) {
            val entry = catalogHit.first
            val variant = decodeSamsungProductVariant(clean)
            return SmartIdentification(
                brand = entry.brand,
                model = entry.model,
                marketingName = entry.marketingName,
                soc = entry.soc,
                platform = entry.platform,
                androidVersions = entry.androidVersions,
                flashFamily = entry.flashFamily,
                regionHint = variant.ifBlank { decodeSamsungSuffix(entry.model) },
                sourceNote = "Matched Build.PRODUCT prefix '${catalogHit.second}'",
                notes = entry.notes,
                matchedVia = "Build.PRODUCT",
                productCode = clean
            )
        }

        // 2. Embedded Samsung SM product codename fallback (e.g. pa3q -> SM-S938)
        val fallbackKey = samsungProductToSm.keys
            .sortedByDescending { it.length }
            .firstOrNull { clean == it || clean.startsWith(it) }
        if (fallbackKey != null) {
            val smBase = samsungProductToSm[fallbackKey]!!
            val resolved = identifySmart(smBase)
            if (resolved != null) {
                val variant = decodeSamsungProductVariant(clean)
                return resolved.copy(
                    regionHint = variant.ifBlank { resolved.regionHint },
                    sourceNote = "Mapped Samsung Build.PRODUCT '$fallbackKey' -> $smBase",
                    matchedVia = "Build.PRODUCT",
                    productCode = clean
                )
            }
        }

        // 3. If Build.PRODUCT itself embeds RMX/SM- code
        if (clean.contains("sm-") || clean.contains("rmx") || clean.contains("cph")) {
            return identifySmart(clean)
        }
        return null
    }

    fun identifySmart(input: String): SmartIdentification? {
        val raw = input.trim()
        if (raw.isBlank()) return null
        val upper = raw.uppercase(Locale.US)

        // 1. Exact match in catalog (model, marketing name, or exact product code)
        val exact = find(raw)
        if (exact != null) {
            return SmartIdentification(
                brand = exact.brand,
                model = exact.model,
                marketingName = exact.marketingName,
                soc = exact.soc,
                platform = exact.platform,
                androidVersions = exact.androidVersions,
                flashFamily = exact.flashFamily,
                regionHint = decodeSamsungSuffix(exact.model),
                sourceNote = "Exact match in catalog",
                notes = exact.notes,
                matchedVia = "Catalog"
            )
        }

        // 2. Samsung SM-xxxx base match (e.g. SM-A546B / SM-S928E -> SM-A546 / SM-S928)
        val samRegex = Regex("(SM-[A-Z]\\d{3,4})([A-Z0-9]{0,3})")
        val samMatch = samRegex.find(upper)
        if (samMatch != null) {
            val base = samMatch.groupValues[1]
            val suffix = samMatch.groupValues[2]
            val fullCode = base + suffix
            val baseEntry = entries.firstOrNull {
                it.brand.equals("Samsung", ignoreCase = true) &&
                    (it.model.equals(base, ignoreCase = true) || upper.startsWith(it.model.uppercase(Locale.US)))
            }
            val region = decodeSamsungSuffix(fullCode)
            if (baseEntry != null) {
                return SmartIdentification(
                    brand = "Samsung",
                    model = fullCode,
                    marketingName = baseEntry.marketingName,
                    soc = baseEntry.soc,
                    platform = baseEntry.platform,
                    androidVersions = baseEntry.androidVersions,
                    flashFamily = baseEntry.flashFamily,
                    regionHint = region,
                    sourceNote = "Matched Samsung SM series ($base)",
                    notes = baseEntry.notes,
                    matchedVia = "SM- Series"
                )
            }
            val series = describeSamsungSmSeries(base)
            return SmartIdentification(
                brand = "Samsung",
                model = fullCode,
                marketingName = "$series ($fullCode)",
                soc = "Exynos / Snapdragon / MediaTek (verify CSC/Build)",
                platform = "Samsung Android",
                androidVersions = "Android / One UI (check local or Odin binary)",
                flashFamily = "Samsung Odin / Download Mode (04E8)",
                regionHint = region,
                sourceNote = "SM- series pattern decoded",
                notes = "Match exact binary BIT/SW REV and CSC region before servicing.",
                matchedVia = "SM- Pattern"
            )
        }

        // 3. Realme RMXxxxx / CPHxxxx pattern match
        val rmxRegex = Regex("(RMX\\d{4}|CPH\\d{4})")
        val rmxMatch = rmxRegex.find(upper)
        if (rmxMatch != null) {
            val code = rmxMatch.groupValues[1]
            val cat = find(code)
            if (cat != null) return identifySmart(cat.model)
            return SmartIdentification(
                brand = if (code.startsWith("RMX")) "Realme" else "OPPO / Realme",
                model = code,
                marketingName = if (code.startsWith("RMX")) "Realme Device ($code)" else "OPPO/Realme ($code)",
                soc = "MediaTek / Qualcomm / Unisoc (check Fastboot/ADB)",
                platform = "Realme UI",
                androidVersions = "Android / Realme UI (check Fastboot getvar:version-os)",
                flashFamily = "Fastboot / MTK BROM / Qualcomm EDL",
                regionHint = "Verify IN / Global / EEA / CN region",
                sourceNote = "Pattern decoded (not in starter catalog)",
                notes = "Use Fastboot Read-Only or USB OTG to inspect hardware and bootloader variables.",
                matchedVia = "RMX/CPH Pattern"
            )
        }

        // 4. Samsung Build.PRODUCT codename match (when user inputs codename like "e3qxxx" or "a54x")
        val byProd = identifyByProduct(raw)
        if (byProd != null) return byProd

        // 5. Partial marketing name match (e.g. "S24 Ultra", "Realme 11")
        val partial = search(raw).firstOrNull()
        if (partial != null) return identifySmart(partial.model)
        return null
    }

    private fun describeSamsungSmSeries(base: String): String = when {
        base.startsWith("SM-S93") -> "Galaxy S25 Series"
        base.startsWith("SM-S92") || base.startsWith("SM-S72") -> "Galaxy S24 Series"
        base.startsWith("SM-S91") || base.startsWith("SM-S71") -> "Galaxy S23 Series"
        base.startsWith("SM-S90") -> "Galaxy S22 Series"
        base.startsWith("SM-S") -> "Galaxy S Series"
        base.startsWith("SM-G") -> "Galaxy S / XCover Series"
        base.startsWith("SM-A") -> "Galaxy A Series"
        base.startsWith("SM-M") -> "Galaxy M Series"
        base.startsWith("SM-F9") -> "Galaxy Z Fold Series"
        base.startsWith("SM-F7") -> "Galaxy Z Flip Series"
        base.startsWith("SM-F") -> "Galaxy Z Fold / Flip Series"
        base.startsWith("SM-N") -> "Galaxy Note Series"
        base.startsWith("SM-E") -> "Galaxy F Series"
        base.startsWith("SM-T") || base.startsWith("SM-X") -> "Galaxy Tab Series"
        else -> "Samsung Galaxy Device"
    }

    fun decodeSamsungSuffix(code: String): String {
        val m = Regex("SM-[A-Z]\\d{3,4}([A-Z0-9]+)", RegexOption.IGNORE_CASE).find(code) ?: return ""
        return when (m.groupValues[1].uppercase(Locale.US)) {
            "B" -> "B — Global / Europe / MENA"
            "E" -> "E — Asia / Africa / Latin America"
            "F" -> "F — International / Europe / MEA"
            "U" -> "U — USA Carrier"
            "U1" -> "U1 — USA Factory Unlocked"
            "W" -> "W — Canada"
            "N" -> "N — South Korea"
            "0" -> "0 — China / Hong Kong"
            "M" -> "M — Latin America"
            "P" -> "P — Regional Variant"
            "DS" -> "DS — Dual-SIM International"
            else -> "Suffix ${m.groupValues[1].uppercase(Locale.US)}"
        }
    }

    fun decodeSamsungProductVariant(product: String): String {
        val p = product.trim().lowercase(Locale.US)
        if (p.isBlank()) return ""
        return when {
            p.endsWith("eea") -> "Product EEA — Europe"
            p.endsWith("nsxx") -> "Product NSXX — Global / MEA"
            p.endsWith("xxx") || p.endsWith("xx") -> "Product XX — International / Global"
            p.endsWith("sqw") || p.endsWith("ue") || p.endsWith("sq") -> "Product US/NA — North America"
            p.endsWith("ksx") || p.endsWith("ks") -> "Product KS — South Korea"
            p.endsWith("zcx") || p.endsWith("zc") -> "Product ZC — China Open"
            p.endsWith("ins") -> "Product INS — India"
            p.endsWith("vj") -> "Product VJ — Latin America"
            else -> ""
        }
    }

    fun decodeSocHint(raw: String): String {
        val s = raw.lowercase(Locale.US)
        return when {
            "mt6789" in s -> "MediaTek Helio G99 (MT6789)"
            "mt6785" in s -> "MediaTek Helio G95 (MT6785)"
            "mt6769" in s -> "MediaTek Helio G80 / G85 / G88 (MT6769)"
            "mt6768" in s -> "MediaTek Helio G70 / G80 / G85 (MT6768)"
            "mt6833" in s -> "MediaTek Dimensity 700 / 6020 (MT6833)"
            "mt6835" in s -> "MediaTek Dimensity 6100+ (MT6835)"
            "mt6877" in s -> "MediaTek Dimensity 900 / 920 / 1080 / 7050 (MT6877)"
            "mt6893" in s -> "MediaTek Dimensity 1200 (MT6893)"
            "mt6983" in s -> "MediaTek Dimensity 9000 (MT6983)"
            "mt67" in s || "mt68" in s || "mt69" in s -> "MediaTek Helio / Dimensity ($raw)"
            "s5e9945" in s || "s5e9940" in s -> "Samsung Exynos 2400 / 2400e"
            "s5e9925" in s -> "Samsung Exynos 2200 (S5E9925)"
            "s5e8845" in s -> "Samsung Exynos 1480 (S5E8845)"
            "s5e8835" in s -> "Samsung Exynos 1380 (S5E8835)"
            "s5e8825" in s -> "Samsung Exynos 1280 (S5E8825)"
            "s5e3830" in s -> "Samsung Exynos 850 (S5E3830)"
            "exynos" in s || "s5e" in s -> "Samsung Exynos ($raw)"
            "pineapple" in s || "sm8650" in s -> "Qualcomm Snapdragon 8 Gen 3"
            "kalama" in s || "sm8550" in s -> "Qualcomm Snapdragon 8 Gen 2"
            "taro" in s || "sm8450" in s -> "Qualcomm Snapdragon 8 Gen 1"
            "lahaina" in s || "sm8350" in s -> "Qualcomm Snapdragon 888"
            "bengal" in s || "khaje" in s -> "Qualcomm Snapdragon 680 / 685"
            "qcom" in s || "sm" in s -> "Qualcomm Snapdragon ($raw)"
            "ums" in s || "sprd" in s || "unisoc" in s -> "Unisoc Tiger ($raw)"
            else -> raw.ifBlank { "Unknown SoC" }
        }
    }
}
