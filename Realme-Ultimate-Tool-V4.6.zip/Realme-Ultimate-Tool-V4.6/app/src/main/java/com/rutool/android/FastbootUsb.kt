package com.rutool.android

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.InputStream
import java.nio.charset.StandardCharsets

data class FastbootResult(val ok: Boolean, val message: String)

class FastbootUsb(private val manager: UsbManager, private val device: UsbDevice) {
    private var connection: UsbDeviceConnection? = null
    private var inEndpoint: UsbEndpoint? = null
    private var outEndpoint: UsbEndpoint? = null
    private var intf: UsbInterface? = null

    fun connect(): FastbootResult {
        if (!manager.hasPermission(device)) return FastbootResult(false, "USB permission not granted")
        for (i in 0 until device.interfaceCount) {
            val candidate = device.getInterface(i)
            // Standard Fastboot interface: vendor-specific class, subclass 0x42, protocol 0x03.
            if (candidate.interfaceClass == 0xff && candidate.interfaceSubclass == 0x42 &&
                candidate.interfaceProtocol == 0x03
            ) {
                var input: UsbEndpoint? = null
                var output: UsbEndpoint? = null
                for (e in 0 until candidate.endpointCount) {
                    val ep = candidate.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) input = ep else output = ep
                    }
                }
                if (input != null && output != null) {
                    val c = manager.openDevice(device) ?: return FastbootResult(false, "Cannot open USB device")
                    if (!c.claimInterface(candidate, true)) {
                        c.close()
                        return FastbootResult(false, "Cannot claim Fastboot interface")
                    }
                    connection = c
                    intf = candidate
                    inEndpoint = input
                    outEndpoint = output
                    return FastbootResult(true, "Fastboot USB interface connected")
                }
            }
        }
        return FastbootResult(false, "No standard Fastboot USB interface found")
    }

    fun getVar(name: String): FastbootResult = command("getvar:$name", maxPackets = 32)

    fun getVarAll(): FastbootResult = command("getvar:all", maxPackets = 256)

    fun reboot(target: String = ""): FastbootResult {
        val cmd = if (target.isBlank()) "reboot" else "reboot-$target"
        return command(cmd, maxPackets = 16, timeoutMs = 8000)
    }

    fun setActiveSlot(slot: String): FastbootResult =
        command("set_active:$slot", maxPackets = 16, timeoutMs = 10000)

    fun flashImageStream(
        partition: String,
        totalBytes: Long,
        input: InputStream,
        onProgress: (Long, Long) -> Unit
    ): FastbootResult {
        if (totalBytes <= 0L) return FastbootResult(false, "Invalid image size ($totalBytes bytes)")
        val conn = connection ?: return FastbootResult(false, "Fastboot is not connected")
        val out = outEndpoint ?: return FastbootResult(false, "Missing bulk OUT endpoint")
        val inp = inEndpoint ?: return FastbootResult(false, "Missing bulk IN endpoint")

        // Check max-download-size when available
        val maxDlRes = getVar("max-download-size")
        if (maxDlRes.ok) {
            val raw = maxDlRes.message.trim().lowercase()
            val maxDl = if (raw.startsWith("0x")) raw.removePrefix("0x").toLongOrNull(16) else raw.toLongOrNull()
            if (maxDl != null && maxDl > 0L && totalBytes > maxDl) {
                return FastbootResult(
                    false,
                    "Image ($totalBytes B) exceeds device max-download-size ($maxDl B). Sparse image required."
                )
            }
        }

        // 1. Send download:<8-hex-size>
        val dlCmd = "download:%08x".format(totalBytes).toByteArray(StandardCharsets.US_ASCII)
        val sentCmd = conn.bulkTransfer(out, dlCmd, dlCmd.size, 8000)
        if (sentCmd != dlCmd.size) {
            return FastbootResult(false, "Failed to send download command ($sentCmd)")
        }

        val respBuf = ByteArray(4096)
        val n = conn.bulkTransfer(inp, respBuf, respBuf.size, 8000)
        if (n <= 0) return FastbootResult(false, "No DATA response from Fastboot bootloader")
        val dataHeader = String(respBuf, 0, n, StandardCharsets.US_ASCII)
        if (!dataHeader.startsWith("DATA")) {
            return FastbootResult(false, "Unexpected response to download: $dataHeader")
        }

        // 2. Stream raw image payload over bulk OUT
        val chunk = ByteArray(64 * 1024)
        var sentTotal = 0L
        var lastPct = -1
        while (sentTotal < totalBytes) {
            val toRead = minOf(chunk.size.toLong(), totalBytes - sentTotal).toInt()
            val read = input.read(chunk, 0, toRead)
            if (read <= 0) {
                return FastbootResult(false, "Unexpected EOF after $sentTotal / $totalBytes bytes")
            }
            var off = 0
            while (off < read) {
                val tx = conn.bulkTransfer(out, chunk, off, read - off, 15000)
                if (tx <= 0) {
                    return FastbootResult(false, "USB bulk transfer stalled at $sentTotal bytes (tx=$tx)")
                }
                off += tx
            }
            sentTotal += read
            val pct = ((sentTotal * 100L) / totalBytes).toInt()
            if (pct != lastPct) {
                lastPct = pct
                onProgress(sentTotal, totalBytes)
            }
        }

        // 3. Read OKAY/FAIL after DATA stream
        val ack = readResponsePackets(conn, inp, maxPackets = 32, timeoutMs = 15000)
        if (!ack.ok) return FastbootResult(false, "Download verification failed: ${ack.message}")

        // 4. Execute flash:<partition>
        return command("flash:$partition", maxPackets = 64, timeoutMs = 60000)
    }

    private fun command(value: String, maxPackets: Int = 32, timeoutMs: Int = 5000): FastbootResult {
        val c = connection ?: return FastbootResult(false, "Fastboot is not connected")
        val out = outEndpoint ?: return FastbootResult(false, "Missing bulk OUT endpoint")
        val input = inEndpoint ?: return FastbootResult(false, "Missing bulk IN endpoint")

        val bytes = value.toByteArray(StandardCharsets.US_ASCII)
        val sent = c.bulkTransfer(out, bytes, bytes.size, timeoutMs)
        if (sent != bytes.size) return FastbootResult(false, "Fastboot command write failed ($sent)")

        return readResponsePackets(c, input, maxPackets, timeoutMs)
    }

    private fun readResponsePackets(
        c: UsbDeviceConnection,
        input: UsbEndpoint,
        maxPackets: Int,
        timeoutMs: Int
    ): FastbootResult {
        val buffer = ByteArray(4096)
        val infoLines = ArrayList<String>()

        for (i in 0 until maxPackets) {
            val n = c.bulkTransfer(input, buffer, buffer.size, timeoutMs)
            if (n <= 0) break

            val pkt = String(buffer, 0, n, StandardCharsets.US_ASCII)
            when {
                pkt.startsWith("INFO") -> {
                    val msg = pkt.removePrefix("INFO").trim()
                    if (msg.isNotEmpty()) infoLines.add(msg)
                }
                pkt.startsWith("OKAY") -> {
                    val payload = pkt.removePrefix("OKAY").trim()
                    val combined = buildString {
                        if (infoLines.isNotEmpty()) {
                            append(infoLines.joinToString("\n"))
                            if (payload.isNotEmpty()) append("\n")
                        }
                        append(payload)
                    }
                    return FastbootResult(true, combined)
                }
                pkt.startsWith("FAIL") -> {
                    val err = pkt.removePrefix("FAIL").trim()
                    val combined = if (infoLines.isEmpty()) err
                    else infoLines.joinToString("\n") + "\nFAIL: $err"
                    return FastbootResult(false, combined)
                }
                else -> return FastbootResult(false, pkt.trim())
            }
        }

        return if (infoLines.isNotEmpty()) {
            FastbootResult(true, infoLines.joinToString("\n"))
        } else {
            FastbootResult(false, "No Fastboot response (timeout or empty read)")
        }
    }

    fun close() {
        try {
            if (connection != null && intf != null) connection?.releaseInterface(intf)
        } catch (_: Exception) {}
        try {
            connection?.close()
        } catch (_: Exception) {}
        connection = null
        intf = null
        inEndpoint = null
        outEndpoint = null
    }
}
