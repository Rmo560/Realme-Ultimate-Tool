package com.rutool.android

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

data class OdinTarEntry(
    val name: String,
    val sizeBytes: Long,
    val isPit: Boolean,
    val isCompressedLz4: Boolean
)

data class OdinSlotReport(
    val slotLabel: String,
    val fileName: String,
    val totalBytes: Long,
    val isTarMd5: Boolean,
    val tarEntries: List<OdinTarEntry>,
    val detectedModel: String?,
    val detectedBuild: String?,
    val binaryBit: String?,
    val expectedMd5: String?,
    val computedMd5: String?,
    val md5Verified: Boolean?,
    val warnings: List<String>
)

private class BoundedInputStream(private val delegate: InputStream, private var left: Long) : InputStream() {
    override fun read(): Int {
        if (left <= 0L) return -1
        val v = delegate.read()
        if (v >= 0) left--
        return v
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (left <= 0L) return -1
        val want = minOf(len.toLong(), left).toInt()
        val n = delegate.read(b, off, want)
        if (n > 0) left -= n
        return n
    }

    override fun close() {
        delegate.close()
    }
}

/**
 * Streaming USTAR TAR & .tar.md5 inspector and entry extractor for Samsung Odin firmware slots.
 */
object OdinTarParser {

    private val modelRegex = Regex("(SM-[A-Z]\\d{3,4}[A-Z0-9]*)", RegexOption.IGNORE_CASE)
    private val buildRegex = Regex("([A-Z]\\d{3,4}[A-Z0-9]{1,3}[A-Z]{2}([US])(\\d)[A-Z0-9]{3})", RegexOption.IGNORE_CASE)
    private val md5LineRegex = Regex("^([0-9a-fA-F]{32})\\s+(.+?)$")

    fun openEntryForFlash(
        resolver: ContentResolver,
        uri: Uri,
        entryName: String
    ): Pair<InputStream, Long>? {
        val rawIn = resolver.openInputStream(uri) ?: return null
        val header = ByteArray(512)
        var count = 0
        while (count < 500) {
            val read = readFullyOrEof(rawIn, header)
            if (read < 512 || isAllZero(header)) break

            val namePart = extractNullTerminatedAscii(header, 0, 100)
            val prefixPart = extractNullTerminatedAscii(header, 345, 155)
            val fullName = if (prefixPart.isNotEmpty()) "$prefixPart/$namePart" else namePart
            val cleanName = fullName.removePrefix("./").trim()
            val entrySize = parseTarSize(header, 124, 12)
            if (entrySize < 0) break

            if (cleanName == entryName) {
                val bounded = BoundedInputStream(rawIn, entrySize)
                if (!cleanName.endsWith(".lz4", ignoreCase = true)) {
                    return bounded to entrySize
                }
                // Check LZ4 header content size; fallback to fast streaming count if header lacks cSize
                val headerSize = Lz4FrameInputStream.readContentSizeFromHeader(bounded)
                bounded.close()

                val exactUncompressed = headerSize ?: run {
                    val reopen = openRawBoundedEntry(resolver, uri, entryName) ?: return null
                    var total = 0L
                    Lz4FrameInputStream(reopen).use { lz ->
                        val tmp = ByteArray(256 * 1024)
                        while (true) {
                            val r = lz.read(tmp)
                            if (r < 0) break
                            total += r
                        }
                    }
                    total
                }

                val freshRaw = openRawBoundedEntry(resolver, uri, entryName) ?: return null
                return Lz4FrameInputStream(freshRaw) to exactUncompressed
            }

            val remainder = entrySize % 512L
            val paddedSkip = entrySize + (if (remainder == 0L) 0L else 512L - remainder)
            if (paddedSkip > 0L && skipExact(rawIn, paddedSkip) < paddedSkip) break
            count++
        }
        rawIn.close()
        return null
    }

    private fun openRawBoundedEntry(resolver: ContentResolver, uri: Uri, entryName: String): InputStream? {
        val rawIn = resolver.openInputStream(uri) ?: return null
        val header = ByteArray(512)
        var count = 0
        while (count < 500) {
            val read = readFullyOrEof(rawIn, header)
            if (read < 512 || isAllZero(header)) break

            val namePart = extractNullTerminatedAscii(header, 0, 100)
            val prefixPart = extractNullTerminatedAscii(header, 345, 155)
            val fullName = if (prefixPart.isNotEmpty()) "$prefixPart/$namePart" else namePart
            val cleanName = fullName.removePrefix("./").trim()
            val entrySize = parseTarSize(header, 124, 12)
            if (entrySize < 0) break

            if (cleanName == entryName) {
                return BoundedInputStream(rawIn, entrySize)
            }
            val remainder = entrySize % 512L
            val paddedSkip = entrySize + (if (remainder == 0L) 0L else 512L - remainder)
            if (paddedSkip > 0L && skipExact(rawIn, paddedSkip) < paddedSkip) break
            count++
        }
        rawIn.close()
        return null
    }

    fun inspectSlot(
        resolver: ContentResolver,
        uri: Uri,
        slotLabel: String,
        verifyMd5: Boolean
    ): OdinSlotReport {
        val fileName = queryName(resolver, uri, slotLabel)
        val reportedSize = querySize(resolver, uri)
        val warnings = ArrayList<String>()

        val entries = ArrayList<OdinTarEntry>()
        var tarBytesRead = 0L
        var looksLikeTar = false

        try {
            (resolver.openInputStream(uri) ?: error("Cannot open selected Odin slot file")).use { rawIn ->
                val header = ByteArray(512)
                var count = 0
                while (count < 500) {
                    val read = readFullyOrEof(rawIn, header)
                    if (read < 512) break
                    tarBytesRead += 512

                    if (isAllZero(header)) break

                    val magic = String(header, 257, 5, StandardCharsets.US_ASCII)
                    if (magic != "ustar" && !looksLikeTar && count == 0) {
                        warnings.add("File does not start with a standard USTAR TAR header")
                        break
                    }
                    looksLikeTar = true

                    val namePart = extractNullTerminatedAscii(header, 0, 100)
                    val prefixPart = extractNullTerminatedAscii(header, 345, 155)
                    val fullName = if (prefixPart.isNotEmpty()) "$prefixPart/$namePart" else namePart
                    val cleanName = fullName.removePrefix("./").trim()

                    val typeFlag = header[156].toInt() and 0xff
                    val entrySize = parseTarSize(header, 124, 12)

                    if (entrySize < 0) {
                        warnings.add("Unsupported TAR entry size encoding for $cleanName")
                        break
                    }

                    if ((typeFlag == 0 || typeFlag == '0'.code) && cleanName.isNotEmpty()) {
                        entries.add(
                            OdinTarEntry(
                                name = cleanName,
                                sizeBytes = entrySize,
                                isPit = cleanName.endsWith(".pit", ignoreCase = true),
                                isCompressedLz4 = cleanName.endsWith(".lz4", ignoreCase = true)
                            )
                        )
                    }

                    val remainder = entrySize % 512L
                    val paddedSkip = entrySize + (if (remainder == 0L) 0L else 512L - remainder)
                    if (paddedSkip > 0L) {
                        val skipped = skipExact(rawIn, paddedSkip)
                        tarBytesRead += skipped
                        if (skipped < paddedSkip) {
                            warnings.add("Unexpected EOF inside entry: $cleanName")
                            break
                        }
                    }
                    count++
                }
            }
        } catch (e: Exception) {
            warnings.add("TAR scan error: ${e.message}")
        }

        val upperName = fileName.uppercase(Locale.US)
        val detectedModel = modelRegex.find(upperName)?.groupValues?.get(1)
        val buildMatch = buildRegex.find(upperName)
        val detectedBuild = buildMatch?.groupValues?.get(1)
        val binaryBit = buildMatch?.let { "${it.groupValues[2]}${it.groupValues[3]}" }
        val isTarMd5 = fileName.lowercase(Locale.US).endsWith(".tar.md5")

        var expectedMd5: String? = null
        var computedMd5: String? = null
        var md5Verified: Boolean? = null
        var actualTotalBytes = reportedSize

        if (verifyMd5) {
            try {
                val tailBuf = ByteArray(512)
                var tailLen = 0
                var totalLen = 0L
                var trailerBytesCount = 0
                var fdHandled = false

                try {
                    resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        val size = pfd.statSize
                        if (size > 0) {
                            totalLen = size
                            java.io.FileInputStream(pfd.fileDescriptor).use { fis ->
                                val ch = fis.channel
                                val startPos = maxOf(0L, size - 512L)
                                ch.position(startPos)
                                val buf = java.nio.ByteBuffer.allocate((size - startPos).toInt())
                                while (buf.hasRemaining()) {
                                    if (ch.read(buf) < 0) break
                                }
                                val arr = buf.array()
                                val parsed = extractMd5Trailer(arr, arr.size)
                                if (parsed != null) {
                                    expectedMd5 = parsed.first
                                    trailerBytesCount = parsed.second
                                }
                            }
                            fdHandled = true
                        }
                    }
                } catch (_: Exception) {}

                if (!fdHandled) {
                    (resolver.openInputStream(uri) ?: error("Cannot reopen stream")).use { s ->
                        val ring = ByteArray(512)
                        var ringFilled = 0
                        val chunk = ByteArray(256 * 1024)
                        while (true) {
                            val n = s.read(chunk)
                            if (n < 0) break
                            totalLen += n
                            if (n >= 512) {
                                System.arraycopy(chunk, n - 512, ring, 0, 512)
                                ringFilled = 512
                            } else {
                                val keep = minOf(ringFilled, 512 - n)
                                if (keep > 0) System.arraycopy(ring, ringFilled - keep, ring, 0, keep)
                                System.arraycopy(chunk, 0, ring, keep, n)
                                ringFilled = keep + n
                            }
                        }
                        System.arraycopy(ring, 0, tailBuf, 0, ringFilled)
                        tailLen = ringFilled
                    }
                    val parsed = extractMd5Trailer(tailBuf, tailLen)
                    if (parsed != null) {
                        expectedMd5 = parsed.first
                        trailerBytesCount = parsed.second
                    }
                }

                actualTotalBytes = totalLen
                val hashLimit = totalLen - trailerBytesCount
                val md = MessageDigest.getInstance("MD5")
                (resolver.openInputStream(uri) ?: error("Cannot reopen for MD5")).use { s ->
                    val buf = ByteArray(1024 * 1024)
                    var remaining = hashLimit
                    while (remaining > 0L) {
                        val toRead = minOf(buf.size.toLong(), remaining).toInt()
                        val n = s.read(buf, 0, toRead)
                        if (n < 0) break
                        md.update(buf, 0, n)
                        remaining -= n
                    }
                }
                computedMd5 = md.digest().joinToString("") { "%02x".format(it) }
                if (expectedMd5 != null) {
                    md5Verified = computedMd5.equals(expectedMd5, ignoreCase = true)
                    if (md5Verified == false) {
                        warnings.add("MD5 MISMATCH! File is corrupted or modified.")
                    }
                } else if (isTarMd5) {
                    warnings.add("No valid 32-hex MD5 footer found at end of .tar.md5")
                }
            } catch (e: Exception) {
                warnings.add("MD5 verification error: ${e.message}")
            }
        }

        return OdinSlotReport(
            slotLabel = slotLabel,
            fileName = fileName,
            totalBytes = actualTotalBytes.coerceAtLeast(tarBytesRead),
            isTarMd5 = isTarMd5,
            tarEntries = entries,
            detectedModel = detectedModel,
            detectedBuild = detectedBuild,
            binaryBit = binaryBit,
            expectedMd5 = expectedMd5,
            computedMd5 = computedMd5,
            md5Verified = md5Verified,
            warnings = warnings
        )
    }

    private fun extractMd5Trailer(tail: ByteArray, len: Int): Pair<String, Int>? {
        if (len <= 0) return null
        var lastNonZero = len - 1
        while (lastNonZero >= 0 && tail[lastNonZero].toInt() == 0) lastNonZero--
        if (lastNonZero < 34) return null

        var lineStart = lastNonZero
        while (lineStart > 0 && tail[lineStart - 1].toInt() != 0 && tail[lineStart - 1] != '\n'.code.toByte()) {
            lineStart--
        }
        val text = String(tail, lineStart, (lastNonZero - lineStart + 1), StandardCharsets.UTF_8).trim()
        val match = md5LineRegex.matchEntire(text) ?: return null
        return match.groupValues[1].lowercase(Locale.US) to (len - lineStart)
    }

    private fun parseTarSize(buf: ByteArray, offset: Int, len: Int): Long {
        val first = buf[offset].toInt() and 0xff
        if ((first and 0x80) != 0) {
            var value = (first and 0x7f).toLong()
            for (i in 1 until len) value = (value shl 8) or (buf[offset + i].toInt() and 0xff).toLong()
            return value
        }
        val raw = String(buf, offset, len, StandardCharsets.US_ASCII)
            .trim { it <= ' ' || it == '\u0000' }
        if (raw.isEmpty()) return 0L
        return raw.toLongOrNull(8) ?: -1L
    }

    private fun extractNullTerminatedAscii(buf: ByteArray, offset: Int, len: Int): String {
        var end = offset
        val limit = minOf(buf.size, offset + len)
        while (end < limit && buf[end].toInt() != 0) end++
        return String(buf, offset, end - offset, StandardCharsets.UTF_8).trim()
    }

    private fun isAllZero(buf: ByteArray): Boolean = buf.all { it.toInt() == 0 }

    private fun readFullyOrEof(input: InputStream, dst: ByteArray): Int {
        var off = 0
        while (off < dst.size) {
            val n = input.read(dst, off, dst.size - off)
            if (n < 0) break
            off += n
        }
        return off
    }

    private fun skipExact(input: InputStream, bytes: Long): Long {
        var left = bytes
        val scratch = ByteArray(64 * 1024)
        while (left > 0L) {
            val skipped = input.skip(left)
            if (skipped > 0L) {
                left -= skipped
            } else {
                val n = input.read(scratch, 0, minOf(scratch.size.toLong(), left).toInt())
                if (n < 0) break
                left -= n
            }
        }
        return bytes - left
    }

    private fun queryName(resolver: ContentResolver, uri: Uri, fallback: String): String {
        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: fallback
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: fallback
    }

    private fun querySize(resolver: ContentResolver, uri: Uri): Long {
        try {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) return it.getLong(0)
            }
        } catch (_: Exception) {}
        return 0L
    }
}
