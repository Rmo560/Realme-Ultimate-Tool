package com.rutool.android

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface

/**
 * Generates a high-DPI Cyberpunk cover banner natively on Canvas.
 * Used automatically when assets/realme_ultimate_cover.png is absent,
 * or when the user switches to the built-in HD V4.6 cover.
 */
object CyberCoverArt {

    fun createBitmap(width: Int = 1200, height: Int = 540): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val w = width.toFloat()
        val h = height.toFloat()

        // 1. Deep space gradient background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(
                    Color.rgb(6, 10, 26),
                    Color.rgb(16, 20, 48),
                    Color.rgb(11, 14, 34)
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, w, h, bgPaint)

        // 2. Neon radial glows (cyan left, purple right)
        val cyanGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                w * 0.22f, h * 0.48f, h * 0.85f,
                Color.argb(95, 6, 182, 212), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }
        c.drawCircle(w * 0.22f, h * 0.48f, h * 0.85f, cyanGlow)

        val purpleGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                w * 0.80f, h * 0.40f, h * 0.90f,
                Color.argb(110, 139, 92, 246), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }
        c.drawCircle(w * 0.80f, h * 0.40f, h * 0.90f, purpleGlow)

        // 3. Tech perspective grid & circuit lines
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(30, 56, 189, 248)
            strokeWidth = 1.5f
        }
        for (i in 1..14) {
            val x = w * (i / 15f)
            c.drawLine(x, 0f, x, h, gridPaint)
        }
        for (i in 1..7) {
            val y = h * (i / 8f)
            c.drawLine(0f, y, w, y, gridPaint)
        }

        // Circuit traces
        val tracePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            color = Color.argb(90, 34, 211, 238)
        }
        val tracePath = Path().apply {
            moveTo(0f, h * 0.18f); lineTo(w * 0.08f, h * 0.18f); lineTo(w * 0.12f, h * 0.26f)
            moveTo(w, h * 0.22f); lineTo(w * 0.88f, h * 0.22f); lineTo(w * 0.84f, h * 0.30f)
            moveTo(w, h * 0.78f); lineTo(w * 0.78f, h * 0.78f); lineTo(w * 0.74f, h * 0.70f)
        }
        c.drawPath(tracePath, tracePaint)

        // 4. Emblem ring on left
        val cx = w * 0.20f
        val cy = h * 0.46f
        val radius = h * 0.27f

        val outerRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            shader = LinearGradient(
                cx - radius, cy - radius, cx + radius, cy + radius,
                Color.rgb(34, 211, 238), Color.rgb(168, 85, 247), Shader.TileMode.CLAMP
            )
        }
        c.drawCircle(cx, cy, radius, outerRing)

        val innerRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.argb(120, 250, 204, 21)
        }
        c.drawCircle(cx, cy, radius * 0.84f, innerRing)

        // Gold crown above emblem
        val crownPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                cx - 45f, cy - radius - 35f, cx + 45f, cy - radius,
                Color.rgb(253, 224, 71), Color.rgb(217, 119, 6), Shader.TileMode.CLAMP
            )
        }
        val crownTop = cy - radius - 6f
        val crownPath = Path().apply {
            moveTo(cx - 46f, crownTop)
            lineTo(cx - 54f, crownTop - 34f)
            lineTo(cx - 22f, crownTop - 16f)
            lineTo(cx, crownTop - 44f)
            lineTo(cx + 22f, crownTop - 16f)
            lineTo(cx + 54f, crownTop - 34f)
            lineTo(cx + 46f, crownTop)
            close()
        }
        c.drawPath(crownPath, crownPaint)

        // Stylized "R" inside emblem
        val rPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = radius * 1.25f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            textAlign = Paint.Align.CENTER
            shader = LinearGradient(
                cx, cy - radius * 0.5f, cx, cy + radius * 0.5f,
                Color.rgb(253, 224, 71), Color.rgb(245, 158, 11), Shader.TileMode.CLAMP
            )
        }
        c.drawText("R", cx - 4f, cy + radius * 0.42f, rPaint)

        // 5. Right Side Typography
        val tx = w * 0.39f
        val titleGold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = h * 0.18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            shader = LinearGradient(
                tx, h * 0.18f, tx, h * 0.38f,
                Color.rgb(254, 240, 138), Color.rgb(245, 158, 11), Shader.TileMode.CLAMP
            )
        }
        c.drawText("Realme", tx, h * 0.33f, titleGold)

        val titleWhite = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = h * 0.145f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
            shader = LinearGradient(
                tx, h * 0.38f, tx, h * 0.53f,
                Color.WHITE, Color.rgb(148, 163, 184), Shader.TileMode.CLAMP
            )
        }
        c.drawText("Ultimate Tool", tx, h * 0.49f, titleWhite)

        // Neon Subtitle Pill
        val pillRect = RectF(tx, h * 0.55f, w * 0.94f, h * 0.65f)
        val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 15, 23, 42) }
        val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
            shader = LinearGradient(
                pillRect.left, 0f, pillRect.right, 0f,
                Color.rgb(34, 211, 238), Color.rgb(250, 204, 21), Shader.TileMode.CLAMP
            )
        }
        c.drawRoundRect(pillRect, 26f, 26f, pillBg)
        c.drawRoundRect(pillRect, 26f, 26f, pillStroke)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(226, 232, 240)
            textSize = h * 0.044f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        c.drawText(
            "REALME & SAMSUNG SUITE  •  V4.6",
            pillRect.centerX(),
            pillRect.centerY() + h * 0.015f,
            subPaint
        )

        // 6. Feature chips at the bottom
        val chips = listOf("USB OTG", "FASTBOOT", "MTK / EDL", "SAMSUNG", ".KO CHECK")
        val chipWidth = (w * 0.88f) / chips.size
        val startX = w * 0.06f
        val chipTop = h * 0.77f
        val chipBottom = h * 0.89f
        val chipBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(180, 17, 24, 43) }
        val chipBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = Color.argb(160, 56, 189, 248)
        }
        val chipText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(125, 211, 252)
            textSize = h * 0.040f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }

        chips.forEachIndexed { idx, label ->
            val left = startX + idx * chipWidth + 8f
            val right = left + chipWidth - 16f
            val r = RectF(left, chipTop, right, chipBottom)
            c.drawRoundRect(r, 16f, 16f, chipBg)
            c.drawRoundRect(r, 16f, 16f, chipBorder)
            c.drawText(label, r.centerX(), r.centerY() + h * 0.014f, chipText)
        }

        return bmp
    }
}
