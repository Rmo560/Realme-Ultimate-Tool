package com.rutool.android

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Xml
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.StringReader
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * Realme & Samsung Ultimate Tool — V4.6 (Breaker-Style Diagnostic Hub)
 *
 * Read-Only Multi-Brand Servicing & Identification Suite:
 *  - Page 0: Breaker Hub (2-column command grid + live device/OTG status strip)
 *  - Page 1: Devices & ID (Realme RMX/CPH & Samsung SM- Build.MODEL/Build.PRODUCT + USB OTG)
 *  - Page 2: Fastboot (Read-only getvar, getvar:all, bootloader/slot check & auto model match)
 *  - Page 3: MediaTek (MTK BROM/Preloader detection, SoC decoder, TXT/XML Scatter parser)
 *  - Page 4: Qualcomm EDL (VID 05C6 / 9008 check, Snapdragon decoder, rawprogram/patch XML reader)
 *  - Page 5: Samsung & Firmware (Odin VID 04E8, CSC/Product decoder, SHA-256 & ZIP/TAR check)
 *  - Page 6: Kernel (.ko) (ELF/ABI/vermagic inspection & root insmod loader)
 */
class MainActivity : Activity() {

    companion object {
        private const val REQ_FIRMWARE = 55
        private const val REQ_DRIVER = 56
        private const val REQ_QUALCOMM_XML = 57
        private const val REQ_ODIN_BL = 58
        private const val REQ_ODIN_AP = 59
        private const val REQ_ODIN_CP = 60
        private const val REQ_ODIN_CSC = 61
        private const val REQ_ODIN_USERDATA = 62
        private const val REQ_FASTBOOT_IMG = 63
        private val ODIN_SLOTS = arrayOf("BL", "AP", "CP", "CSC", "USERDATA")
        private const val MAX_LOG_LINES = 300
        private const val MAX_MODULE_BYTES = 32L * 1024 * 1024
        private const val MAX_SCATTER_BYTES = 4 * 1024 * 1024
        private const val USB_ACTION = "com.rutool.android.USB_PERMISSION"

        private const val PAGE_HOME = 0
        private const val PAGE_DEVICES = 1
        private const val PAGE_FASTBOOT = 2
        private const val PAGE_MTK = 3
        private const val PAGE_QUALCOMM = 4
        private const val PAGE_SAMSUNG_FW = 5
        private const val PAGE_KERNEL = 6
    }

    // ---- Breaker dark industrial theme palette ----
    private val colBg = Color.rgb(7, 10, 19)
    private val colCard = Color.rgb(15, 22, 39)
    private val colCardBorder = Color.rgb(38, 53, 88)
    private val colInputBg = Color.rgb(10, 15, 29)
    private val colConsoleBg = Color.rgb(5, 8, 16)
    private val colCyan = Color.rgb(34, 211, 238)
    private val colAmber = Color.rgb(245, 158, 11)
    private val colEmerald = Color.rgb(45, 212, 191)
    private val colPurple = Color.rgb(168, 85, 247)
    private val colBlue = Color.rgb(59, 130, 246)
    private val colRose = Color.rgb(244, 63, 94)
    private val colText = Color.rgb(226, 232, 240)
    private val colMuted = Color.rgb(148, 163, 184)
    private val colBtnPrimary = Color.rgb(29, 78, 137)
    private val colBtnPurple = Color.rgb(91, 33, 182)
    private val colBtnTeal = Color.rgb(15, 118, 110)
    private val colBtnAmber = Color.rgb(180, 83, 9)
    private val colBtnDanger = Color.rgb(153, 27, 27)
    private val colBtnNeutral = Color.rgb(51, 65, 85)

    // ---- views ----
    private lateinit var deviceText: TextView
    private lateinit var dossierText: TextView
    private lateinit var fastbootText: TextView
    private lateinit var mtkText: TextView
    private lateinit var qcomText: TextView
    private lateinit var firmwareText: TextView
    private lateinit var samsungText: TextView
    private lateinit var odinPortBanner: TextView
    private lateinit var odinStatusText: TextView
    private val odinSlotChecks = arrayOfNulls<CheckBox>(5)
    private val odinSlotInfoViews = arrayOfNulls<TextView>(5)
    private lateinit var driverText: TextView
    private lateinit var logText: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var modelInput: EditText
    private lateinit var regionInput: EditText
    private lateinit var progress: ProgressBar
    private lateinit var otgBadge: TextView
    private lateinit var topStatusChip: TextView
    private lateinit var liveSearchSummary: TextView
    private lateinit var liveResultsList: LinearLayout
    private lateinit var showAllBtn: Button
    private lateinit var coverView: ImageView

    // ---- services ----
    private lateinit var usb: UsbManager
    private lateinit var deviceDb: DeviceDatabase
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val stampFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    // ---- state ----
    @Volatile private var destroyed = false
    @Volatile private var busy = false
    private var arabic = true
    private var currentPage = PAGE_HOME
    private var brandFilter = "ALL"
    private var showAllSupported = false
    private var useBuiltInCover = false
    private var hasAssetCover = false
    private var cachedBuiltInCover: Bitmap? = null
    private var modelValue = ""
    private var regionValue = ""
    private var dossierShown: String? = null
    private var fastbootShown: String? = null
    private var mtkShown: String? = null
    private var qcomShown: String? = null
    private var firmwareShown: String? = null
    private var samsungShown: String? = null
    private var odinStatusShown: String? = null
    private val odinSlotUris = arrayOfNulls<Uri>(5)
    private val odinSlotNames = arrayOfNulls<String>(5)
    private val odinSlotSummaries = arrayOfNulls<String>(5)
    private val odinSlotEnabled = booleanArrayOf(true, true, true, true, false)
    private val odinSlotReports = arrayOfNulls<OdinSlotReport>(5)
    private var driverShown: String? = null
    private val logLines = ArrayList<String>()
    private var selectedUri: Uri? = null
    private var fastbootImgUri: Uri? = null
    private var qcomXmlUri: Uri? = null
    private var driverUri: Uri? = null
    private var driverFile: File? = null
    private var driverSha: String? = null
    private var driverVermagicOk: Boolean? = null
    private var driverHasRoot = false
    @Volatile private var fastboot: FastbootUsb? = null
    @Volatile private var fastbootName: String? = null
    @Volatile private var odinClient: OdinUsb? = null
    @Volatile private var odinDeviceName: String? = null
    private val permissionAsked = HashSet<String>()

    // =====================================================================
    // Lifecycle
    // =====================================================================

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val d = usbDeviceExtra(intent)
            when (intent.action) {
                USB_ACTION -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    log(
                        t(
                            "إذن USB: ${if (granted) "ممنوح" else "مرفوض"} — ${d?.deviceName}",
                            "USB permission ${if (granted) "granted" else "denied"} — ${d?.deviceName}"
                        )
                    )
                    scanUsb(logResult = false, askPermission = false)
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    log(t("تم توصيل جهاز USB: ${d?.deviceName}", "USB device attached: ${d?.deviceName}"))
                    scanUsb()
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    log(t("تم فصل جهاز USB: ${d?.deviceName}", "USB device detached: ${d?.deviceName}"))
                    d?.deviceName?.let { name ->
                        permissionAsked.remove(name)
                        if (name == fastbootName) closeFastboot()
                        if (name == odinDeviceName) closeOdin()
                    }
                    scanUsb(logResult = false)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usb = getSystemService(USB_SERVICE) as UsbManager
        deviceDb = DeviceDatabase(this)
        hasAssetCover = checkAssetExists("realme_ultimate_cover.png")
        restoreState(savedInstanceState)

        val filter = IntentFilter().apply {
            addAction(USB_ACTION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        buildUi()
        if (logLines.isEmpty()) {
            log("Breaker Suite V4.6 Ready — ${deviceDb.count()} Realme & Samsung models")
            detectLocalDeviceDossier(silent = true)
        }
        scanUsb(logResult = false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        syncInputsToState()
        outState.putBoolean("arabic", arabic)
        outState.putInt("page", currentPage)
        outState.putString("brandFilter", brandFilter)
        outState.putBoolean("showAll", showAllSupported)
        outState.putBoolean("builtInCover", useBuiltInCover)
        outState.putString("model", modelValue)
        outState.putString("region", regionValue)
        outState.putString("dossier", dossierShown)
        outState.putString("fb", fastbootShown)
        outState.putString("mtk", mtkShown)
        outState.putString("qcom", qcomShown)
        outState.putString("fw", firmwareShown)
        outState.putString("sam", samsungShown)
        outState.putString("odinStatus", odinStatusShown)
        outState.putStringArray("odinUris", Array(5) { i -> odinSlotUris[i]?.toString() ?: "" })
        outState.putStringArray("odinNames", Array(5) { i -> odinSlotNames[i] ?: "" })
        outState.putStringArray("odinSums", Array(5) { i -> odinSlotSummaries[i] ?: "" })
        outState.putBooleanArray("odinEn", odinSlotEnabled)
        outState.putString("drv", driverShown)
        outState.putStringArray("log", logLines.toTypedArray())
        outState.putString("fwUri", selectedUri?.toString())
        outState.putString("fbImgUri", fastbootImgUri?.toString())
        outState.putString("qcomUri", qcomXmlUri?.toString())
        outState.putString("drvUri", driverUri?.toString())
        outState.putString("drvFile", driverFile?.absolutePath)
        outState.putString("drvSha", driverSha)
        outState.putString("drvVmOk", driverVermagicOk?.toString())
        outState.putBoolean("drvRoot", driverHasRoot)
    }

    private fun restoreState(s: Bundle?) {
        s ?: return
        arabic = s.getBoolean("arabic", true)
        currentPage = s.getInt("page", PAGE_HOME)
        brandFilter = s.getString("brandFilter") ?: "ALL"
        showAllSupported = s.getBoolean("showAll", false)
        useBuiltInCover = s.getBoolean("builtInCover", false)
        modelValue = s.getString("model") ?: ""
        regionValue = s.getString("region") ?: ""
        dossierShown = s.getString("dossier")
        fastbootShown = s.getString("fb")
        mtkShown = s.getString("mtk")
        qcomShown = s.getString("qcom")
        firmwareShown = s.getString("fw")
        samsungShown = s.getString("sam")
        odinStatusShown = s.getString("odinStatus")
        s.getStringArray("odinUris")?.forEachIndexed { idx, v ->
            if (idx < 5) odinSlotUris[idx] = if (v.isBlank()) null else Uri.parse(v)
        }
        s.getStringArray("odinNames")?.forEachIndexed { idx, v ->
            if (idx < 5) odinSlotNames[idx] = v.ifBlank { null }
        }
        s.getStringArray("odinSums")?.forEachIndexed { idx, v ->
            if (idx < 5) odinSlotSummaries[idx] = v.ifBlank { null }
        }
        s.getBooleanArray("odinEn")?.forEachIndexed { idx, b ->
            if (idx < 5) odinSlotEnabled[idx] = b
        }
        driverShown = s.getString("drv")
        s.getStringArray("log")?.let { logLines.addAll(it) }
        selectedUri = s.getString("fwUri")?.let { Uri.parse(it) }
        fastbootImgUri = s.getString("fbImgUri")?.let { Uri.parse(it) }
        qcomXmlUri = s.getString("qcomUri")?.let { Uri.parse(it) }
        driverUri = s.getString("drvUri")?.let { Uri.parse(it) }
        driverFile = s.getString("drvFile")?.let { File(it) }?.takeIf { it.exists() }
        driverSha = if (driverFile != null) s.getString("drvSha") else null
        driverVermagicOk = if (driverFile != null) s.getString("drvVmOk")?.toBooleanStrictOrNull() else null
        driverHasRoot = if (driverFile != null) s.getBoolean("drvRoot", false) else false
    }

    private fun syncInputsToState() {
        if (::modelInput.isInitialized) modelValue = modelInput.text.toString()
        if (::regionInput.isInitialized) regionValue = regionInput.text.toString()
    }

    override fun onDestroy() {
        destroyed = true
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        try {
            io.execute {
                try { fastboot?.close() } catch (_: Exception) {}
                try { odinClient?.close() } catch (_: Exception) {}
                fastboot = null
                odinClient = null
            }
        } catch (_: Exception) {}
        io.shutdown()
        if (isFinishing) driverFile?.delete()
        cachedBuiltInCover?.recycle()
        cachedBuiltInCover = null
        super.onDestroy()
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private fun t(ar: String, en: String) = if (arabic) ar else en

    private fun ui(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block()
        else main.post { if (!destroyed) block() }
    }

    private fun background(task: () -> Unit) {
        if (busy) {
            log(t("عملية أخرى قيد التنفيذ…", "Another operation is still running…"))
            return
        }
        busy = true
        ui { if (::progress.isInitialized) progress.visibility = View.VISIBLE }
        try {
            io.execute {
                try {
                    task()
                } catch (e: Throwable) {
                    log(t("خطأ: ${e.message}", "Error: ${e.message}"))
                } finally {
                    busy = false
                    ui { if (::progress.isInitialized) progress.visibility = View.GONE }
                }
            }
        } catch (_: Exception) {
            busy = false
            ui { if (::progress.isInitialized) progress.visibility = View.GONE }
        }
    }

    private fun log(s: String) = ui {
        logLines.add("[${stampFormat.format(Date())}] $s")
        while (logLines.size > MAX_LOG_LINES) logLines.removeAt(0)
        refreshLogView()
    }

    private fun refreshLogView() {
        if (!::logText.isInitialized) return
        logText.text = logLines.joinToString("\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyLog() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("breaker-log", logLines.joinToString("\n")))
        Toast.makeText(this, t("تم نسخ السجل", "Log copied"), Toast.LENGTH_SHORT).show()
    }

    private fun copyFullDiagnosticReport() {
        val fullReport = buildString {
            append("=== REALME & SAMSUNG BREAKER DIAGNOSTIC REPORT (V4.6) ===\n")
            append("Model: ${Build.MODEL} | Product: ${Build.PRODUCT} | Android: ${Build.VERSION.RELEASE}\n")
            dossierShown?.let { append("\n--- DEVICE DOSSIER ---\n$it\n") }
            fastbootShown?.let { append("\n--- FASTBOOT ---\n$it\n") }
            mtkShown?.let { append("\n--- MEDIATEK ---\n$it\n") }
            qcomShown?.let { append("\n--- QUALCOMM ---\n$it\n") }
            samsungShown?.let { append("\n--- SAMSUNG ---\n$it\n") }
            odinStatusShown?.let { append("\n--- SAMSUNG ODIN ---\n$it\n") }
            firmwareShown?.let { append("\n--- FIRMWARE ---\n$it\n") }
            driverShown?.let { append("\n--- KERNEL .KO ---\n$it\n") }
            append("\n--- CONSOLE LOG ---\n")
            append(logLines.joinToString("\n"))
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("breaker-report", fullReport))
        Toast.makeText(this, t("تم نسخ التقرير الشامل", "Full report copied"), Toast.LENGTH_SHORT).show()
    }

    private fun setDossierText(s: String) = ui {
        dossierShown = s
        if (::dossierText.isInitialized) dossierText.text = s
    }

    private fun setFastbootText(s: String) = ui {
        fastbootShown = s
        if (::fastbootText.isInitialized) fastbootText.text = s
    }

    private fun setMtkText(s: String) = ui {
        mtkShown = s
        if (::mtkText.isInitialized) mtkText.text = s
    }

    private fun setQcomText(s: String) = ui {
        qcomShown = s
        if (::qcomText.isInitialized) qcomText.text = s
    }

    private fun setFirmwareText(s: String) = ui {
        firmwareShown = s
        if (::firmwareText.isInitialized) firmwareText.text = s
    }

    private fun setSamsungText(s: String) = ui {
        samsungShown = s
        if (::samsungText.isInitialized) samsungText.text = s
    }

    private fun setOdinStatusText(s: String) = ui {
        odinStatusShown = s
        if (::odinStatusText.isInitialized) odinStatusText.text = s
    }

    private fun setDriverText(s: String) = ui {
        driverShown = s
        if (::driverText.isInitialized) driverText.text = s
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun fmtSize(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(Locale.US, b / (1024.0 * 1024 * 1024))
        b >= 1L shl 20 -> "%.2f MB".format(Locale.US, b / (1024.0 * 1024))
        b >= 1L shl 10 -> "%.1f KB".format(Locale.US, b / 1024.0)
        else -> "$b B"
    }

    private fun roundedBg(
        fill: Int,
        stroke: Int = Color.TRANSPARENT,
        radiusDp: Int = 12,
        strokeDp: Int = 1
    ) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != Color.TRANSPARENT && strokeDp > 0) {
            setStroke(dp(strokeDp), stroke)
        }
    }

    private fun checkAssetExists(name: String): Boolean = try {
        assets.open(name).use { true }
    } catch (_: Exception) {
        false
    }

    private fun applyCoverBitmap() {
        if (!::coverView.isInitialized) return
        if (!useBuiltInCover && hasAssetCover) {
            try {
                assets.open("realme_ultimate_cover.png").use { input ->
                    val bmp = BitmapFactory.decodeStream(input)
                    if (bmp != null) {
                        coverView.setImageBitmap(bmp)
                        return
                    }
                }
            } catch (_: Exception) {}
        }
        val fallback = cachedBuiltInCover ?: CyberCoverArt.createBitmap().also {
            cachedBuiltInCover = it
        }
        coverView.setImageBitmap(fallback)
    }

    // =====================================================================
    // UI — Breaker Hub & Dedicated Protocol Pages
    // =====================================================================

    private fun switchPage(page: Int) {
        if (currentPage == page) return
        syncInputsToState()
        currentPage = page
        buildUi()
        scanUsb(logResult = false, askPermission = false)
    }

    private fun buildUi() {
        syncInputsToState()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(colBg)
        }

        // --- Breaker Top Brand Bar ---
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(6))
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(TextView(this).apply {
            text = "BREAKER SUITE • V4.6"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        titleCol.addView(TextView(this).apply {
            text = t("أداة تشخيص وتنفيذ ريلمي وسامسونج عبر USB OTG", "REALME & SAMSUNG SERVICE & FLASH SUITE")
            textSize = 10.5f
            setTextColor(colAmber)
            typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        if (currentPage != PAGE_HOME) {
            header.addView(smallButton(t("الرئيسية", "HUB"), colBtnNeutral) { switchPage(PAGE_HOME) })
        }
        header.addView(smallButton(if (arabic) "EN" else "عربي", colBtnPurple) {
            arabic = !arabic
            buildUi()
            scanUsb(logResult = false, askPermission = false)
        })
        root.addView(header)

        // --- Live Hardware Status Strip ---
        val localSmart = deviceDb.identifyCurrentDevice()
        val deviceSummary = localSmart?.marketingName ?: "${Build.BRAND} ${Build.MODEL}"
        val statusBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedBg(colCard, colCardBorder, radiusDp = 10, strokeDp = 1)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        statusBar.addView(TextView(this).apply {
            text = "$deviceSummary · ${Build.MODEL} · Android ${Build.VERSION.RELEASE}"
            textSize = 11f
            setTextColor(colText)
            maxLines = 1
        }, LinearLayout.LayoutParams(0, -2, 1f))
        topStatusChip = TextView(this).apply {
            text = "OTG: 0"
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(colCyan)
        }
        statusBar.addView(topStatusChip)
        root.addView(statusBar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = if (busy) View.VISIBLE else View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)).apply { bottomMargin = dp(6) })

        // --- Horizontal Mode Switcher Bar ---
        val tabBarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(1), dp(2), dp(3))
        }
        val pages = listOf(
            PAGE_HOME to t("لوحة بريكر", "Breaker Hub"),
            PAGE_DEVICES to t("الأجهزة وOTG", "Devices & ID"),
            PAGE_FASTBOOT to t("فاست بوت", "Fastboot"),
            PAGE_MTK to t("ميديا تك", "MediaTek"),
            PAGE_QUALCOMM to t("كوالكوم EDL", "Qualcomm"),
            PAGE_SAMSUNG_FW to t("سامسونج Odin", "Samsung Odin"),
            PAGE_KERNEL to t("النواة .ko", "Kernel .ko")
        )
        pages.forEach { (id, label) ->
            val active = currentPage == id
            val btn = Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (active) Color.rgb(8, 12, 24) else colText)
                background = roundedBg(
                    if (active) colCyan else colCard,
                    if (active) colCyan else colCardBorder,
                    radiusDp = 9,
                    strokeDp = 1
                )
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(12), dp(4), dp(12), dp(4))
                layoutParams = LinearLayout.LayoutParams(-2, dp(34)).apply { marginEnd = dp(6) }
                setOnClickListener { switchPage(id) }
            }
            tabRow.addView(btn)
        }
        tabBarScroll.addView(tabRow)
        root.addView(tabBarScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        // --- Page Body ScrollView ---
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)

        when (currentPage) {
            PAGE_HOME -> buildBreakerHubPage(body)
            PAGE_DEVICES -> buildDevicesPage(body)
            PAGE_FASTBOOT -> buildFastbootPage(body)
            PAGE_MTK -> buildMediaTekPage(body)
            PAGE_QUALCOMM -> buildQualcommPage(body)
            PAGE_SAMSUNG_FW -> buildSamsungFirmwarePage(body)
            PAGE_KERNEL -> buildKernelPage(body)
        }

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // --- Breaker-Style Bottom Terminal Log ---
        val logContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(colCard, colCardBorder, radiusDp = 12, strokeDp = 1)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val logHeader = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(6))
        }
        logHeader.addView(TextView(this).apply {
            text = t("وحدة الأوامر والسجل", "BREAKER CONSOLE")
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(colEmerald)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        logHeader.addView(smallButton(t("تقرير", "REPORT"), colBtnTeal) { copyFullDiagnosticReport() })
        logHeader.addView(smallButton(t("نسخ", "COPY"), colBtnPrimary) { copyLog() })
        logHeader.addView(smallButton(t("مسح", "CLEAR"), colBtnNeutral) {
            logLines.clear()
            refreshLogView()
        })
        logContainer.addView(logHeader)

        logText = TextView(this).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.rgb(167, 243, 208))
            setTextIsSelectable(true)
        }
        logScroll = ScrollView(this).apply {
            background = roundedBg(colConsoleBg, Color.rgb(30, 41, 59), radiusDp = 8, strokeDp = 1)
            setPadding(dp(8), dp(6), dp(8), dp(6))
            addView(logText)
        }
        logContainer.addView(logScroll, LinearLayout.LayoutParams(-1, dp(105)))
        root.addView(logContainer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        setContentView(root)
        refreshLogView()
    }

    // ---------------------------------------------------------------------
    // Page 0: Breaker Style Launcher Hub (2-Column Grid + Quick Bar)
    // ---------------------------------------------------------------------

    private fun buildBreakerHubPage(body: LinearLayout) {
        val coverFrame = FrameLayout(this).apply {
            background = roundedBg(Color.rgb(6, 10, 26), colCyan, radiusDp = 14, strokeDp = 1)
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        coverView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = t("غلاف Realme Ultimate Tool", "Realme Ultimate Tool cover")
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            clipToOutline = true
        }
        applyCoverBitmap()
        coverFrame.addView(coverView, FrameLayout.LayoutParams(-1, dp(148)))

        if (hasAssetCover) {
            val toggleCoverBtn = Button(this).apply {
                text = "🎨"
                textSize = 11f
                minWidth = 0
                minimumWidth = 0
                minHeight = 0
                minimumHeight = 0
                setPadding(dp(8), dp(4), dp(8), dp(4))
                background = roundedBg(Color.argb(190, 15, 23, 42), colCyan, radiusDp = 10, strokeDp = 1)
                setOnClickListener {
                    useBuiltInCover = !useBuiltInCover
                    applyCoverBitmap()
                }
            }
            coverFrame.addView(
                toggleCoverBtn,
                FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
                    topMargin = dp(6)
                    marginEnd = dp(6)
                }
            )
        }
        body.addView(coverFrame, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        // Quick Actions Strip
        buttonRow(
            body,
            t("فحص الجهاز الحالي", "READ THIS PHONE"), colBtnTeal, {
                detectLocalDeviceDossier(silent = false)
                switchPage(PAGE_DEVICES)
            },
            t("فحص USB / OTG", "SCAN OTG PORT"), colBtnPrimary, {
                scanUsb()
                switchPage(PAGE_DEVICES)
            }
        )

        card(body, t("أقسام بريكر السريعة (${deviceDb.count()} موديلاً)", "BREAKER MODULE LAUNCHER")) {
            val gridPairs = listOf(
                Pair(
                    TileSpec("SAMSUNG ODIN", t("Download Mode · BL/AP/CP/CSC", "Download Mode · BL/AP/CP/CSC"), colBlue) {
                        brandFilter = "Samsung"
                        switchPage(PAGE_SAMSUNG_FW)
                    },
                    TileSpec("REALME / OPPO", t("RMX · CPH · كتالوج الأجهزة", "RMX · CPH · Device Catalog"), colAmber) {
                        brandFilter = "Realme"
                        switchPage(PAGE_DEVICES)
                    }
                ),
                Pair(
                    TileSpec("FASTBOOT", t("getvar · البوتلودر · Slot", "getvar · Bootloader · Slot"), colCyan) {
                        switchPage(PAGE_FASTBOOT)
                    },
                    TileSpec("MEDIATEK (MTK)", t("BROM · Preloader · Scatter", "BROM · Preloader · Scatter"), colEmerald) {
                        switchPage(PAGE_MTK)
                    }
                ),
                Pair(
                    TileSpec("QUALCOMM (EDL)", t("VID 05C6 · 9008 · XML", "VID 05C6 · 9008 · rawprogram"), colPurple) {
                        switchPage(PAGE_QUALCOMM)
                    },
                    TileSpec("FIRMWARE / SHA", t("فحص الروم · ZIP · Odin TAR", "ROM Check · ZIP · Odin TAR"), colBtnTeal) {
                        switchPage(PAGE_SAMSUNG_FW)
                    }
                ),
                Pair(
                    TileSpec("USB / OTG HUB", t("منافذ USB المتصلة الآن", "Live VID/PID · Interfaces"), colCyan) {
                        switchPage(PAGE_DEVICES)
                        scanUsb()
                    },
                    TileSpec("KERNEL (.ko)", t("ELF · vermagic · Root", "ELF · vermagic · insmod"), colRose) {
                        switchPage(PAGE_KERNEL)
                    }
                )
            )

            gridPairs.forEach { (leftTile, rightTile) ->
                val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(
                    breakerTile(leftTile),
                    LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) }
                )
                row.addView(
                    breakerTile(rightTile),
                    LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) }
                )
                addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }

        card(body, t("ملخص الجهاز المتصل محلياً", "LOCAL DEVICE SNAPSHOT")) {
            dossierText = panel(
                dossierShown ?: t("جارٍ قراءة بيانات الجهاز…", "Reading local device info…")
            )
            addView(dossierText)
        }
    }

    private data class TileSpec(
        val title: String,
        val subtitle: String,
        val accent: Int,
        val onClick: () -> Unit
    )

    private fun breakerTile(spec: TileSpec): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(colInputBg, spec.accent, radiusDp = 12, strokeDp = 1)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
            isFocusable = true

            addView(TextView(this@MainActivity).apply {
                text = spec.title
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(spec.accent)
            })
            addView(TextView(this@MainActivity).apply {
                text = spec.subtitle
                textSize = 10.5f
                setTextColor(colMuted)
                setPadding(0, dp(3), 0, 0)
            })
            setOnClickListener { spec.onClick() }
        }
    }

    // ---------------------------------------------------------------------
    // Page 1: Devices & Unified Realme/Samsung Identifier
    // ---------------------------------------------------------------------

    private fun buildDevicesPage(body: LinearLayout) {
        card(body, t("التعرّف الذكي على Realme وSamsung", "REALME & SAMSUNG DEVICE IDENTIFIER")) {
            val realmeCount = deviceDb.realmeCatalog().size
            val samsungCount = deviceDb.samsungCatalog().size
            val filterRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
            }
            listOf(
                "ALL" to t("الكل (${deviceDb.count()})", "All (${deviceDb.count()})"),
                "Realme" to "Realme ($realmeCount)",
                "Samsung" to "Samsung ($samsungCount)"
            ).forEach { (key, label) ->
                val active = brandFilter == key
                filterRow.addView(Button(this@MainActivity).apply {
                    text = label
                    isAllCaps = false
                    textSize = 11f
                    setTextColor(if (active) Color.rgb(8, 12, 24) else colText)
                    background = roundedBg(
                        if (active) colEmerald else colInputBg,
                        if (active) colEmerald else colCardBorder,
                        radiusDp = 8,
                        strokeDp = 1
                    )
                    layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginEnd = dp(4) }
                    setOnClickListener {
                        brandFilter = key
                        buildUi()
                        scanUsb(logResult = false, askPermission = false)
                    }
                })
            }
            addView(filterRow)

            modelInput = editText(
                t("اكتب جزءاً من الاسم أو الموديل (مثال: A54، S24، 3630، e3q)", "Type partial name or model (e.g. A54, S24, 3630, e3q)"),
                modelValue
            )
            modelInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    modelValue = s?.toString().orEmpty()
                    updateLiveSearchResults()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            addView(modelInput)

            buttonRow(
                this,
                t("تعرّف على الموديل", "IDENTIFY MODEL"), colBtnPrimary, { identifyModel() },
                t("فحص هذا الهاتف", "THIS PHONE INFO"), colBtnTeal, { detectLocalDeviceDossier(silent = false) }
            )

            val listBtnRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            showAllBtn = styledButton(
                if (showAllSupported) t("إخفاء الكل", "HIDE ALL")
                else t("عرض الكل (ريلمي وسامسونج)", "SHOW ALL SUPPORTED"),
                if (showAllSupported) colBtnAmber else colBtnPurple
            ) {
                showAllSupported = !showAllSupported
                updateShowAllButtonLabel()
                updateLiveSearchResults()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) }
            }
            val modalCatalogBtn = styledButton(t("نافذة الكتالوج", "CATALOG POPUP"), colBtnNeutral) {
                showCatalogDialog()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) }
            }
            listBtnRow.addView(showAllBtn)
            listBtnRow.addView(modalCatalogBtn)
            addView(listBtnRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })

            liveSearchSummary = TextView(this@MainActivity).apply {
                textSize = 11f
                setTextColor(colCyan)
                setPadding(dp(2), dp(2), dp(2), dp(4))
            }
            addView(liveSearchSummary)

            liveResultsList = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
            }
            addView(liveResultsList, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

            dossierText = panel(
                dossierShown ?: t(
                    "ابدأ بكتابة أي جزء من اسم أو رقم الموديل لتظهر النتائج تلقائياً، أو اضغط «عرض الكل» لعرض جميع أجهزة Realme وSamsung المدعومة.",
                    "Start typing any part of a device name or model number for instant matches, or tap 'Show All Supported' to browse all Realme & Samsung devices."
                )
            )
            addView(dossierText)
            updateLiveSearchResults()
        }

        card(body, t("إدارة USB وOTG المباشر", "USB OTG DEVICE SCANNER")) {
            otgBadge = TextView(this@MainActivity).apply {
                text = t("OTG: جارٍ الفحص…", "OTG: Scanning…")
                textSize = 11f
                setTextColor(colCyan)
                setPadding(0, 0, 0, dp(6))
            }
            addView(otgBadge)
            deviceText = panel(t("جارٍ الفحص…", "Scanning…"))
            addView(deviceText)
            buttonRow(
                this,
                t("فحص OTG", "SCAN OTG"), colBtnPrimary, { scanUsb() },
                t("تفاصيل USB", "USB DETAILS"), colBtnTeal, { showUsbDetails() }
            )
            addView(styledButton(t("تنفيذ إعادة التشغيل عبر ADB OTG (Download / Bootloader)", "ADB OTG REBOOT (DOWNLOAD / BOOTLOADER)"), colBtnAmber) {
                showAdbOtgRebootDialog()
            })
        }
    }

    // ---------------------------------------------------------------------
    // Page 2: Fastboot Dedicated Page (Read & Execute)
    // ---------------------------------------------------------------------

    private fun buildFastbootPage(body: LinearLayout) {
        card(body, t("صفحة الفاست بوت (قراءة وتنفيذ أوامر Fastboot)", "FASTBOOT DIAGNOSTIC & FLASH EXECUTION")) {
            fastbootText = panel(
                fastbootShown ?: t(
                    "وصّل جهاز Realme أو Android في وضع Fastboot عبر OTG لقراءة المتغيرات أو تفليش ملفات .img وتبديل الـ Slot وإعادة التشغيل.",
                    "Connect a Fastboot device via OTG to read variables, flash .img partitions, switch A/B slots, or reboot."
                )
            )
            addView(fastbootText)
            buttonRow(
                this,
                t("قراءة وتعرّف تلقائي", "READ & IDENTIFY"), colBtnPrimary, { readFastbootInfo() },
                t("فحص البوتلودر والـ Slot", "BOOTLOADER & SLOT"), colBtnAmber, { readFastbootBootloaderCheck() }
            )
            buttonRow(
                this,
                t("قراءة الكل (getvar:all)", "GETVAR ALL"), colBtnTeal, { readFastbootAll() },
                t("إنهاء الاتصال", "DISCONNECT"), colBtnNeutral, {
                    closeFastboot()
                    log(t("تم إنهاء اتصال Fastboot.", "Fastboot disconnected."))
                }
            )
            buttonRow(
                this,
                t("اختيار ملف .img", "SELECT .IMG"), colBtnPurple, { chooseFastbootImg() },
                t("تفليش قسم (Flash)", "FLASH PARTITION"), colBtnDanger, { confirmFastbootFlash() }
            )
            buttonRow(
                this,
                t("تبديل Slot (A / B)", "SET ACTIVE SLOT"), colBtnPrimary, { showFastbootSlotDialog() },
                t("إعادة تشغيل (Reboot)", "REBOOT TARGET"), colBtnTeal, { showFastbootRebootDialog() }
            )
        }
    }

    // ---------------------------------------------------------------------
    // Page 3: MediaTek Dedicated Page
    // ---------------------------------------------------------------------

    private fun buildMediaTekPage(body: LinearLayout) {
        card(body, t("صفحة معالج ميديا تك (MediaTek MTK)", "MEDIATEK (MTK) PROCESSOR & SCATTER")) {
            mtkText = panel(
                mtkShown ?: t(
                    "تفحص هذه الصفحة معالجات Helio / Dimensity (مثل MT6789, MT6877) وأوضاع USB (BROM 0003 / Preloader 2000) وتحلل ملفات Scatter نصياً وXML للقراءة فقط.",
                    "Inspects Helio/Dimensity SoCs, MTK USB modes (BROM 0003 / Preloader 2000), and read-only TXT/XML Scatter files."
                )
            )
            addView(mtkText)
            buttonRow(
                this,
                t("فحص معالج الجهاز وMTK USB", "DETECT MTK / SOC"), colBtnPrimary, { inspectMediaTekStatus() },
                t("اختيار ملف Scatter", "SELECT SCATTER"), colBtnTeal, { chooseFirmware() }
            )
            addView(styledButton(t("تحليل MTK Scatter (TXT / XML)", "ANALYZE MTK SCATTER (TXT / XML)"), colBtnPurple) {
                analyzeScatter(targetMtkPanel = true)
            })
        }
    }

    // ---------------------------------------------------------------------
    // Page 4: Qualcomm EDL Dedicated Page
    // ---------------------------------------------------------------------

    private fun buildQualcommPage(body: LinearLayout) {
        card(body, t("صفحة كوالكوم (Qualcomm EDL 9008 & XML)", "QUALCOMM EDL 9008 & RAWPROGRAM READER")) {
            qcomText = panel(
                qcomShown ?: t(
                    "تفحص هذه الصفحة معالجات Snapdragon المحلية وأجهزة Qualcomm المتصلة عبر OTG (VID 05C6: 9008 EDL / 9091 Diag) وتحلل ملفات rawprogram*.xml / patch*.xml للقراءة فقط.",
                    "Inspects Snapdragon hardware, Qualcomm USB OTG (VID 05C6: 9008 EDL / 9091 Diag), and read-only rawprogram/patch XML files."
                )
            )
            addView(qcomText)
            buttonRow(
                this,
                t("فحص Snapdragon وOTG 9008", "DETECT QCOM / 9008"), colBtnPrimary, { inspectQualcommStatus() },
                t("اختيار rawprogram XML", "SELECT QCOM XML"), colBtnTeal, { chooseQualcommXml() }
            )
            addView(styledButton(t("تحليل rawprogram / patch XML (قراءة فقط)", "ANALYZE QUALCOMM XML (READ ONLY)"), colBtnPurple) {
                analyzeQualcommXml()
            })
        }
    }

    // ---------------------------------------------------------------------
    // Page 5: Samsung Odin & Firmware Page
    // ---------------------------------------------------------------------

    private fun buildSamsungFirmwarePage(body: LinearLayout) {
        card(body, t("سامسونج Odin — وضع Download ومصافحة OTG", "SAMSUNG ODIN — DOWNLOAD MODE & ID:COM")) {
            odinPortBanner = TextView(this@MainActivity).apply {
                textSize = 12f
                typeface = Typeface.MONOSPACE
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
            }
            addView(odinPortBanner)
            updateOdinPortBanner()

            odinStatusText = panel(
                odinStatusShown ?: t(
                    "منفذ Odin جاهز: يمكنك إدخال الجهاز في وضع Download، التحقق من مصافحة ODIN->LOKE عبر OTG، وفحص حزم BL / AP / CP / CSC / USERDATA (.tar.md5) قبل التفليش.",
                    "Odin workspace ready: enter Download Mode, verify ODIN->LOKE OTG handshake, and validate BL / AP / CP / CSC / USERDATA (.tar.md5) packages."
                )
            )
            addView(odinStatusText)

            buttonRow(
                this,
                t("الدخول لوضع Download", "ENTER DOWNLOAD MODE"), colBtnAmber, { showEnterDownloadModeDialog() },
                t("مصافحة Odin (LOKE)", "ODIN HANDSHAKE"), colBtnPrimary, { runOdinHandshake() }
            )
            buttonRow(
                this,
                t("سحب جدول PIT", "DUMP PIT TABLE"), colBtnPurple, { dumpOdinPit() },
                t("إعادة تشغيل من Odin", "REBOOT DEVICE"), colBtnNeutral, { rebootOdinPhone() }
            )
        }

        card(body, t("خانات Odin الخمس (BL / AP / CP / CSC / USERDATA)", "ODIN 5-SLOT FIRMWARE LOADER (.TAR / .TAR.MD5)")) {
            for (idx in ODIN_SLOTS.indices) {
                val slot = ODIN_SLOTS[idx]
                val slotRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    background = roundedBg(colInputBg, colCardBorder, radiusDp = 10, strokeDp = 1)
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
                }

                val topLine = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val cb = CheckBox(this@MainActivity).apply {
                    isChecked = odinSlotEnabled[idx]
                    setOnCheckedChangeListener { _, checked ->
                        odinSlotEnabled[idx] = checked
                    }
                }
                odinSlotChecks[idx] = cb
                topLine.addView(cb)

                val pickBtn = Button(this@MainActivity).apply {
                    text = slot
                    isAllCaps = false
                    textSize = 11.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    background = roundedBg(colBtnPrimary, Color.argb(90, 255, 255, 255), radiusDp = 8, strokeDp = 1)
                    minWidth = 0
                    minimumWidth = 0
                    setPadding(dp(12), dp(4), dp(12), dp(4))
                    layoutParams = LinearLayout.LayoutParams(dp(92), dp(34)).apply { marginEnd = dp(8) }
                    setOnClickListener { chooseOdinSlot(idx) }
                }
                topLine.addView(pickBtn)

                val fileLabel = TextView(this@MainActivity).apply {
                    text = odinSlotNames[idx] ?: t("اضغط $slot لاختيار ملف .tar / .tar.md5", "Tap $slot to select .tar / .tar.md5")
                    textSize = 11.5f
                    setTextColor(if (odinSlotNames[idx] != null) colCyan else colMuted)
                    maxLines = 2
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                }
                topLine.addView(fileLabel)
                slotRow.addView(topLine)

                val infoView = TextView(this@MainActivity).apply {
                    val sum = odinSlotSummaries[idx]
                    text = sum ?: ""
                    textSize = 10.5f
                    setTextColor(colEmerald)
                    setPadding(dp(4), dp(4), dp(4), 0)
                    visibility = if (sum.isNullOrBlank()) View.GONE else View.VISIBLE
                }
                odinSlotInfoViews[idx] = infoView
                slotRow.addView(infoView)

                addView(slotRow)
            }

            buttonRow(
                this,
                t("فحص جميع الخانات (TAR/MD5)", "VERIFY ALL (.TAR/MD5)"), colBtnTeal, { verifyAllOdinSlots() },
                t("مسح جميع الخانات", "CLEAR SLOTS"), colBtnNeutral, { clearOdinSlots() }
            )

            addView(styledButton(t("بدء التفليش عبر Odin (تنفيذ فعلي)", "START ODIN FLASH (EXECUTE)"), colBtnDanger) {
                confirmAndStartOdinFlash()
            })
        }

        card(body, t("فحص موديل سامسونج وOTG", "SAMSUNG DEVICE & OTG CHECK")) {
            samsungText = panel(
                samsungShown ?: t(
                    "تعرّف على أجهزة Galaxy (سلسلة SM) عبر Build.MODEL وBuild.PRODUCT مع فك شفرة المنطقة (B/E/U/W/N/0) واكتشاف أجهزة Samsung المتصلة عبر USB (VID 04E8).",
                    "Identifies Galaxy SM models via Build.MODEL & Build.PRODUCT, decodes regional suffixes, and inspects Samsung USB OTG (VID 04E8)."
                )
            )
            addView(samsungText)
            buttonRow(
                this,
                t("فحص سامسونج (محلي + OTG)", "CHECK SAMSUNG"), colBtnPrimary, { inspectSamsungOtg() },
                t("عرض كتالوج سامسونج", "SAMSUNG CATALOG"), colBtnTeal, {
                    brandFilter = "Samsung"
                    showCatalogDialog()
                }
            )
        }

        card(body, t("فحص توافق الروم العام وSHA-256", "GENERAL FIRMWARE & SHA-256 INSPECTOR")) {
            regionInput = editText(
                t("المنطقة / CSC (مثال: Global أو EGY أو XSG)", "Region / CSC (e.g. Global, EGY, XSG)"),
                regionValue
            )
            addView(regionInput)
            firmwareText = panel(firmwareShown ?: t("لم يتم اختيار ملف روم", "No firmware selected"))
            addView(firmwareText)
            buttonRow(
                this,
                t("اختيار ملف الروم", "SELECT FIRMWARE"), colBtnPrimary, { chooseFirmware() },
                t("فحص SHA-256 / ZIP", "INSPECT FILE"), colBtnTeal, { inspectFirmware() }
            )
        }
    }

    // ---------------------------------------------------------------------
    // Page 6: Kernel (.ko) Page
    // ---------------------------------------------------------------------

    private fun buildKernelPage(body: LinearLayout) {
        card(body, t("إدارة وحدات النواة (.ko)", "KERNEL MODULE MANAGER (.ko)")) {
            driverText = panel(
                driverShown ?: t(
                    "لم يتم اختيار ملف. يدعم هذا القسم وحدات نواة Android بصيغة .ko فقط.",
                    "No file selected. This section supports Android kernel modules (.ko) only."
                )
            )
            addView(driverText)
            buttonRow(
                this,
                t("اختيار ملف .ko", "SELECT .ko"), colBtnPrimary, { chooseDriver() },
                t("فحص التوافق", "CHECK MODULE"), colBtnTeal, { inspectDriver() }
            )
            addView(styledButton(t("تحميل وحدة .ko (يتطلب Root)", "LOAD .ko MODULE (ROOT REQUIRED)"), colBtnDanger) {
                confirmDriverInstall()
            })
        }
    }

    // =====================================================================
    // UI Component Factories
    // =====================================================================

    private fun card(parent: LinearLayout, title: String, content: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(colCard, colCardBorder, radiusDp = 14, strokeDp = 1)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(colEmerald)
            setPadding(0, 0, 0, dp(8))
        })
        box.content()
        parent.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun panel(s: String) = TextView(this).apply {
        text = s
        textSize = 12f
        setTextColor(colText)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = roundedBg(colInputBg, Color.rgb(30, 41, 59), radiusDp = 10, strokeDp = 1)
        setTextIsSelectable(true)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
    }

    private fun editText(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        setSingleLine()
        textSize = 13f
        inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        setTextColor(Color.WHITE)
        setHintTextColor(colMuted)
        background = roundedBg(colInputBg, colCardBorder, radiusDp = 10, strokeDp = 1)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
    }

    private fun styledButton(
        label: String,
        bgColor: Int = colBtnPrimary,
        action: () -> Unit
    ) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = roundedBg(bgColor, Color.argb(90, 255, 255, 255), radiusDp = 10, strokeDp = 1)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        layoutParams = LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(6) }
        setOnClickListener { action() }
    }

    private fun buttonRow(
        parent: LinearLayout,
        leftLabel: String,
        leftColor: Int,
        leftAction: () -> Unit,
        rightLabel: String,
        rightColor: Int,
        rightAction: () -> Unit
    ) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b1 = styledButton(leftLabel, leftColor, leftAction).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) }
        }
        val b2 = styledButton(rightLabel, rightColor, rightAction).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) }
        }
        row.addView(b1)
        row.addView(b2)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
    }

    private fun smallButton(label: String, bgColor: Int = colBtnNeutral, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 10.5f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = roundedBg(bgColor, Color.argb(90, 255, 255, 255), radiusDp = 8, strokeDp = 1)
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(30)).apply { marginStart = dp(5) }
        setOnClickListener { action() }
    }

    // =====================================================================
    // Local Device & Unified Realme/Samsung Recognition
    // =====================================================================

    private fun detectLocalDeviceDossier(silent: Boolean) {
        val brand = Build.BRAND
        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL
        val product = Build.PRODUCT
        val device = Build.DEVICE
        val hw = Build.HARDWARE
        val board = Build.BOARD
        val socGuess = deviceDb.decodeSocHint("$hw $board $product")
        val smart = deviceDb.identifyCurrentDevice()

        val report = buildString {
            append(t("📱 الهاتف الحالي (محلي):\n", "📱 Current Local Device:\n"))
            append(t("الشركة / العلامة: $manufacturer ($brand)\n", "Brand: $manufacturer ($brand)\n"))
            if (smart != null) {
                append(t("الاسم التجاري: ${smart.marketingName}\n", "Marketing Name: ${smart.marketingName}\n"))
            }
            append("Build.MODEL: $model\n")
            append("Build.PRODUCT: $product (Build.DEVICE: $device)\n")
            append(t("إصدار أندرويد: Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n", "OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n"))
            append(t("التحديث الأمني: ${Build.VERSION.SECURITY_PATCH}\n", "Security Patch: ${Build.VERSION.SECURITY_PATCH}\n"))
            append(t("رقم البناء: ${Build.DISPLAY}\n", "Build ID: ${Build.DISPLAY}\n"))
            append(t("البوتلودر: ${Build.BOOTLOADER}\n", "Bootloader: ${Build.BOOTLOADER}\n"))
            append(t("النواة: ${System.getProperty("os.version") ?: "unknown"}\n", "Kernel: ${System.getProperty("os.version") ?: "unknown"}\n"))
            append(t("المعالج / العتاد: $socGuess ($hw / $board)\n", "SoC / Hardware: $socGuess ($hw / $board)\n"))
            append("ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
            if (smart != null) {
                append("\n\n" + formatSmartSummary(smart))
            }
        }
        setDossierText(report)
        if (!silent) {
            log(t("تم فحص الهاتف الحالي: $brand $model ($product) — Android ${Build.VERSION.RELEASE}", "Local device: $brand $model ($product) — Android ${Build.VERSION.RELEASE}"))
        }
    }

    private fun updateShowAllButtonLabel() {
        if (!::showAllBtn.isInitialized) return
        showAllBtn.text = if (showAllSupported) t("إخفاء الكل", "HIDE ALL")
        else t("عرض الكل (ريلمي وسامسونج)", "SHOW ALL SUPPORTED")
        showAllBtn.background = roundedBg(
            if (showAllSupported) colBtnAmber else colBtnPurple,
            Color.argb(90, 255, 255, 255),
            radiusDp = 10,
            strokeDp = 1
        )
    }

    private fun updateLiveSearchResults() {
        if (!::liveResultsList.isInitialized || !::liveSearchSummary.isInitialized) return
        val q = modelValue.trim()
        val filter = if (brandFilter == "ALL") null else brandFilter

        if (q.isBlank() && !showAllSupported) {
            liveResultsList.removeAllViews()
            liveResultsList.visibility = View.GONE
            liveSearchSummary.text = t(
                "اكتب أي جزء من اسم أو رقم الموديل للبحث الفوري، أو اضغط «عرض الكل».",
                "Type any part of a model name/number for instant matches, or tap 'Show All Supported'."
            )
            liveSearchSummary.setTextColor(colMuted)
            return
        }

        val results = if (q.isNotBlank()) {
            deviceDb.search(q, filter)
        } else {
            deviceDb.allSupported(filter)
        }

        liveResultsList.removeAllViews()
        if (results.isEmpty()) {
            liveResultsList.visibility = View.GONE
            liveSearchSummary.text = t(
                "لا توجد نتائج مطابقة لـ '$q' — اضغط «تعرّف على الموديل» لتحليل الصيغة.",
                "No catalog match for '$q' — tap 'Identify Model' for pattern decoding."
            )
            liveSearchSummary.setTextColor(colAmber)
            return
        }

        liveResultsList.visibility = View.VISIBLE
        val displayList = if (q.isNotBlank()) results.take(15) else results
        liveSearchSummary.text = if (q.isNotBlank()) {
            t(
                "نتائج البحث التلقائي: ${results.size} جهاز (اضغط على أي جهاز لعرض تفاصيله)",
                "Auto-matched devices: ${results.size} (tap any item for details)"
            )
        } else {
            t(
                "عرض الكل: ${results.size} جهازاً مدعوماً (ريلمي وسامسونج)",
                "Showing all ${results.size} supported Realme & Samsung devices"
            )
        }
        liveSearchSummary.setTextColor(colEmerald)

        displayList.forEach { entry ->
            liveResultsList.addView(
                buildSearchRowView(entry),
                LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) }
            )
        }
    }

    private fun buildSearchRowView(entry: DeviceEntry): LinearLayout {
        val isSam = entry.brand.equals("Samsung", ignoreCase = true)
        val accent = if (isSam) colCyan else colAmber
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(colInputBg, colCardBorder, radiusDp = 10, strokeDp = 1)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            isClickable = true
            isFocusable = true

            addView(TextView(this@MainActivity).apply {
                text = "[${entry.brand}] ${entry.marketingName}  •  ${entry.model}"
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(accent)
            })
            val codes = if (entry.productCodes.isNotEmpty()) {
                " • Code: " + entry.productCodes.take(2).joinToString("/")
            } else ""
            addView(TextView(this@MainActivity).apply {
                text = "${entry.soc} • ${entry.androidVersions}$codes"
                textSize = 10.5f
                setTextColor(colMuted)
                setPadding(0, dp(2), 0, 0)
            })

            setOnClickListener {
                modelValue = entry.model
                if (::modelInput.isInitialized) {
                    modelInput.setText(entry.model)
                    modelInput.setSelection(entry.model.length)
                }
                val smart = deviceDb.identifySmart(entry.model)
                if (smart != null) {
                    setDossierText(formatSmartSummary(smart))
                    log("${entry.brand} | ${entry.marketingName} (${entry.model}) | ${entry.androidVersions}")
                }
            }
        }
    }

    private fun identifyModel() {
        val value = if (::modelInput.isInitialized) modelInput.text.toString().trim() else modelValue.trim()
        if (value.isBlank()) {
            log(t("أدخل رقم الموديل أو الاسم أولاً.", "Enter a model number or name first."))
            return
        }
        background {
            val smart = deviceDb.identifySmart(value)
            if (smart != null) {
                val formatted = formatSmartSummary(smart)
                setDossierText(formatted)
                log("${smart.brand} | ${smart.marketingName} | ${smart.model} | ${smart.androidVersions}")
                return@background
            }

            val matches = deviceDb.search(value, if (brandFilter == "ALL") null else brandFilter)
            if (matches.isEmpty()) {
                val msg = t(
                    "لم يتم العثور على '$value' في القاعدة ولا يطابق صيغة Realme (RMX/CPH) أو Samsung (SM-).",
                    "'${value}' was not found in catalog and does not match Realme (RMX/CPH) or Samsung (SM-) patterns."
                )
                setDossierText(msg)
                log(msg)
            } else {
                val text = matches.take(8).joinToString("\n\n") { m ->
                    "${m.brand} — ${m.marketingName} (${m.model})\nSoC: ${m.soc}\nOS: ${m.androidVersions}\nMode: ${m.flashFamily}"
                }
                setDossierText(text)
                matches.take(5).forEach { m ->
                    log("${m.brand} | ${m.marketingName} | ${m.model} | ${m.soc}")
                }
            }
        }
    }

    private fun formatSmartSummary(s: SmartIdentification): String = buildString {
        append(t("العلامة: ${s.brand}\n", "Brand: ${s.brand}\n"))
        append(t("الاسم التجاري: ${s.marketingName}\n", "Device Name: ${s.marketingName}\n"))
        append(t("الموديل: ${s.model}\n", "Model: ${s.model}\n"))
        if (s.productCode.isNotBlank()) {
            append("Build.PRODUCT: ${s.productCode}\n")
        }
        if (s.regionHint.isNotBlank()) {
            append(t("المنطقة / اللاحقة: ${s.regionHint}\n", "Region / Suffix: ${s.regionHint}\n"))
        }
        append(t("إصدار النظام: ${s.androidVersions}\n", "OS Versions: ${s.androidVersions}\n"))
        append(t("المعالج: ${s.soc} (${s.platform})\n", "Processor: ${s.soc} (${s.platform})\n"))
        append(t("وضع الصيانة/التفليش: ${s.flashFamily}\n", "Service Family: ${s.flashFamily}\n"))
        if (s.matchedVia.isNotBlank()) {
            append(t("طريقة التعرّف: ${s.matchedVia}\n", "Identified Via: ${s.matchedVia}\n"))
        }
        append(t("حالة التطابق: ${s.sourceNote}\n", "Match Source: ${s.sourceNote}\n"))
        if (s.notes.isNotBlank()) append(t("ملاحظات: ${s.notes}", "Notes: ${s.notes}"))
    }

    private fun showCatalogDialog() {
        val list = if (brandFilter == "ALL") deviceDb.all() else deviceDb.byBrand(brandFilter)
        if (list.isEmpty()) return
        val items = list.map { "${it.brand}: ${it.marketingName} (${it.model}) — ${it.platform}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(t("كتالوج الأجهزة (${list.size})", "Device Catalog (${list.size})"))
            .setItems(items) { _, which ->
                val chosen = list[which]
                modelValue = chosen.model
                if (::modelInput.isInitialized) modelInput.setText(chosen.model)
                val smart = deviceDb.identifySmart(chosen.model)
                if (smart != null) {
                    setDossierText(formatSmartSummary(smart))
                    log("${chosen.brand} | ${chosen.marketingName} (${chosen.model}) | ${chosen.androidVersions}")
                }
            }
            .setNegativeButton(t("إغلاق", "CLOSE"), null)
            .show()
    }

    // =====================================================================
    // USB & OTG
    // =====================================================================

    @Suppress("DEPRECATION")
    private fun usbDeviceExtra(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else i.getParcelableExtra(UsbManager.EXTRA_DEVICE)

    private fun requestUsbPermission(d: UsbDevice) {
        if (usb.hasPermission(d) || !permissionAsked.add(d.deviceName)) return
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(
            this, d.deviceId, Intent(USB_ACTION).setPackage(packageName), flags
        )
        usb.requestPermission(d, pi)
    }

    private fun hasInterface(d: UsbDevice, cls: Int, sub: Int, proto: Int): Boolean =
        (0 until d.interfaceCount).any {
            val x = d.getInterface(it)
            x.interfaceClass == cls && x.interfaceSubclass == sub && x.interfaceProtocol == proto
        }

    private fun isFastboot(d: UsbDevice) = hasInterface(d, 0xff, 0x42, 0x03)
    private fun isAdb(d: UsbDevice) = hasInterface(d, 0xff, 0x42, 0x01)

    private fun scanUsb(logResult: Boolean = true, askPermission: Boolean = true) {
        val list = usb.deviceList.values.toList()
        if (::topStatusChip.isInitialized) {
            topStatusChip.text = "OTG: ${list.size}"
            topStatusChip.setTextColor(if (list.isEmpty()) colMuted else colEmerald)
        }
        if (::otgBadge.isInitialized) {
            if (list.isEmpty()) {
                otgBadge.text = t("OTG: غير متصل (0 أجهزة)", "OTG: Idle (0 devices)")
                otgBadge.setTextColor(colMuted)
            } else {
                otgBadge.text = t("OTG: متصل (${list.size} جهاز)", "OTG: Connected (${list.size} device(s))")
                otgBadge.setTextColor(colEmerald)
            }
        }
        if (::deviceText.isInitialized) {
            if (list.isEmpty()) {
                deviceText.text = t(
                    "لا يوجد جهاز USB متصل. استخدم كابل بيانات وOTG.",
                    "No USB device connected. Use a data cable and OTG."
                )
            } else {
                deviceText.text = list.joinToString("\n\n") { d ->
                    val name = listOfNotNull(d.manufacturerName, d.productName).joinToString(" ")
                    val smart = if (name.isNotBlank()) deviceDb.identifySmart(name) else null
                    buildString {
                        append("${usbFamily(d)} | ${usbMode(d)}\n")
                        append("VID:%04X PID:%04X\n".format(d.vendorId, d.productId))
                        if (name.isNotBlank()) append("$name\n")
                        if (smart != null) append("Match: ${smart.marketingName} (${smart.model})\n")
                        append("${d.deviceName} | IF:${d.interfaceCount} | ")
                        append(if (usb.hasPermission(d)) t("الإذن ✓", "permission ✓") else t("بدون إذن", "no permission"))
                    }
                }
            }
        }
        updateOdinPortBanner()
        if (askPermission) list.forEach { requestUsbPermission(it) }
        if (logResult) {
            if (list.isEmpty()) log(t("لم يتم العثور على أجهزة OTG.", "No OTG devices found."))
            else log(t("تم اكتشاف ${list.size} جهاز USB عبر OTG.", "Detected ${list.size} USB OTG device(s)."))
        }
    }

    private fun usbFamily(d: UsbDevice): String = when (d.vendorId) {
        0x04e8 -> "Samsung"
        0x0e8d -> "MediaTek"
        0x05c6 -> "Qualcomm"
        0x18d1 -> "Android / Google"
        0x22d9 -> "OPPO / realme"
        0x2a70 -> "OnePlus"
        0x2717 -> "Xiaomi"
        0x12d1 -> "Huawei"
        0x22b8 -> "Motorola"
        0x1782 -> "Unisoc / Spreadtrum"
        else -> t("USB غير معروف", "Unknown USB")
    }

    private fun usbMode(d: UsbDevice): String {
        val vid = d.vendorId
        val pid = d.productId
        if (vid == 0x05c6) {
            return when (pid) {
                0x9008 -> "Qualcomm EDL / Sahara (9008)"
                0x9091, 0x9025 -> "Qualcomm Diag / Composite (%04X)".format(pid)
                0x900e -> "Qualcomm Download / Ramdump (900E)"
                else -> "Qualcomm USB (PID %04X)".format(pid)
            }
        }
        if (vid == 0x04e8) {
            return when (pid) {
                0x685d -> "Samsung Odin / Download Mode (685D)"
                0x6860 -> "Samsung MTP / ADB (6860)"
                0x6866 -> "Samsung CDC Serial / Modem (6866)"
                else -> "Samsung USB (PID %04X)".format(pid)
            }
        }
        if (isFastboot(d)) return "Fastboot"
        if (isAdb(d)) return "ADB"
        if (vid == 0x0e8d) {
            return when (pid) {
                0x0003 -> "MediaTek BROM (0003)"
                0x2000 -> "MediaTek Preloader (2000)"
                else -> "MediaTek USB (PID %04X)".format(pid)
            }
        }
        val classes = (0 until d.interfaceCount).map { d.getInterface(it).interfaceClass }
        return when {
            UsbConstants.USB_CLASS_MASS_STORAGE in classes -> "Mass Storage"
            UsbConstants.USB_CLASS_STILL_IMAGE in classes -> "MTP / PTP"
            else -> t("وضع غير محدد", "Mode not identified")
        }
    }

    private fun showUsbDetails() {
        val list = usb.deviceList.values.toList()
        if (list.isEmpty()) {
            log(t("لا توجد أجهزة OTG لعرض تفاصيلها.", "No OTG devices available for details."))
            return
        }
        val report = buildString {
            list.forEach { d ->
                append("${usbFamily(d)} — ${usbMode(d)}\n")
                append("VID: %04X | PID: %04X | Device: %s\n".format(d.vendorId, d.productId, d.deviceName))
                append("Manufacturer: ${d.manufacturerName ?: "N/A"} | Product: ${d.productName ?: "N/A"}\n")
                for (i in 0 until d.interfaceCount) {
                    val intf = d.getInterface(i)
                    append("  IF$i: class=${intf.interfaceClass}, sub=${intf.interfaceSubclass}, proto=${intf.interfaceProtocol}\n")
                }
                append("Permission: ${if (usb.hasPermission(d)) "granted" else "not granted"}\n\n")
            }
        }
        AlertDialog.Builder(this)
            .setTitle(t("تفاصيل أجهزة USB / OTG", "USB / OTG Device Details"))
            .setMessage(report)
            .setPositiveButton("OK", null)
            .show()
    }

    // =====================================================================
    // Page 2 Logic: Fastboot Read-Only & Auto Device Lookup
    // =====================================================================

    private fun closeFastboot() {
        try {
            io.execute {
                try { fastboot?.close() } catch (_: Exception) {}
                fastboot = null
                fastbootName = null
            }
        } catch (_: Exception) {
            fastboot = null
            fastbootName = null
        }
    }

    private fun connectFastbootDevice(): Pair<UsbDevice, FastbootUsb>? {
        val candidates = usb.deviceList.values.filter { isFastboot(it) }
        if (candidates.size != 1) {
            val msg = t(
                "يجب توصيل جهاز Fastboot واحد فقط عبر OTG. الأجهزة المطابقة: ${candidates.size}",
                "Connect exactly one Fastboot device via OTG. Matching devices: ${candidates.size}"
            )
            setFastbootText(msg)
            log(msg)
            return null
        }
        val d = candidates[0]
        if (!usb.hasPermission(d)) {
            permissionAsked.remove(d.deviceName)
            requestUsbPermission(d)
            log(t("تم طلب إذن USB. اضغط قراءة مرة أخرى بعد الموافقة.", "USB permission requested. Tap read again after granting."))
            return null
        }
        try { fastboot?.close() } catch (_: Exception) {}
        val client = FastbootUsb(usb, d)
        val connected = client.connect()
        if (!connected.ok) {
            setFastbootText(connected.message)
            log(connected.message)
            return null
        }
        fastboot = client
        fastbootName = d.deviceName
        return d to client
    }

    private fun readFastbootInfo() {
        background {
            val pair = connectFastbootDevice() ?: return@background
            val dev = pair.first
            val client = pair.second
            val keys = listOf(
                "product", "variant", "version-os", "version-bootloader",
                "version-baseband", "secure", "unlocked", "is-userspace",
                "current-slot", "serialno", "max-download-size"
            )
            val map = linkedMapOf<String, String>()
            val out = buildString {
                append("USB: ${usbFamily(dev)} (${dev.productName ?: "Fastboot"})\n\n")
                keys.forEach { key ->
                    val r = client.getVar(key)
                    val valStr = if (r.ok) r.message else "N/A (${r.message})"
                    if (r.ok && r.message.isNotBlank()) map[key] = r.message
                    append("$key = $valStr\n")
                }
                val probe = map["product"] ?: map["variant"] ?: dev.productName.orEmpty()
                val smart = if (probe.isNotBlank()) deviceDb.identifySmart(probe) else null
                if (smart != null) {
                    append("\n--- Matched Device ---\n")
                    append(formatSmartSummary(smart))
                }
            }
            setFastbootText(out)
            log(t("تمت قراءة متغيرات Fastboot بنجاح.", "Fastboot variables read."))
        }
    }

    private fun readFastbootBootloaderCheck() {
        background {
            val pair = connectFastbootDevice() ?: return@background
            val client = pair.second
            val keys = listOf("product", "unlocked", "secure", "current-slot", "slot-count", "is-userspace", "version-bootloader")
            val out = buildString {
                append(t("فحص حالة البوتلودر وSlot (قراءة فقط):\n\n", "Bootloader & Slot Read-Only Check:\n\n"))
                keys.forEach { k ->
                    val r = client.getVar(k)
                    append("$k = ${if (r.ok) r.message else "N/A (${r.message})"}\n")
                }
            }
            setFastbootText(out)
            log(t("تم فحص حالة البوتلودر والـ Slot عبر Fastboot.", "Fastboot bootloader & slot check completed."))
        }
    }

    private fun readFastbootAll() {
        background {
            val pair = connectFastbootDevice() ?: return@background
            val client = pair.second
            log(t("قراءة getvar:all من Fastboot…", "Reading Fastboot getvar:all…"))
            val result = client.getVarAll()
            if (result.ok) {
                setFastbootText(result.message)
                log("Fastboot getvar:all completed.")
            } else {
                setFastbootText("getvar:all ERROR: ${result.message}")
                log("getvar:all ERROR: ${result.message}")
            }
        }
    }

    private fun chooseFastbootImg() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }, REQ_FASTBOOT_IMG)
    }

    private fun confirmFastbootFlash() {
        val uri = fastbootImgUri ?: run {
            log(t("اختر ملف .img أولاً.", "Select an .img file first."))
            return
        }
        val fileName = queryDisplayName(uri, "image.img")
        val partitions = arrayOf("boot", "init_boot", "vendor_boot", "recovery", "vbmeta", "dtbo", "boot_a", "boot_b", "custom...")
        AlertDialog.Builder(this)
            .setTitle(t("اختر القسم المراد تفليشه", "Select Target Partition"))
            .setItems(partitions) { _, which ->
                val chosen = partitions[which]
                if (chosen == "custom...") {
                    val input = EditText(this).apply {
                        hint = t("اسم القسم (مثال: super أو system)", "Partition name (e.g. vbmeta_system)")
                        setSingleLine()
                    }
                    AlertDialog.Builder(this)
                        .setTitle(t("اسم القسم المخصص", "Custom Partition Name"))
                        .setView(input)
                        .setPositiveButton(t("متابعة", "NEXT")) { _, _ ->
                            val custom = input.text.toString().trim()
                            if (custom.isNotEmpty()) askFinalFastbootFlashConfirm(custom, uri, fileName)
                        }
                        .setNegativeButton(t("إلغاء", "CANCEL"), null)
                        .show()
                } else {
                    askFinalFastbootFlashConfirm(chosen, uri, fileName)
                }
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun askFinalFastbootFlashConfirm(partition: String, uri: Uri, fileName: String) {
        AlertDialog.Builder(this)
            .setTitle(t("تأكيد تفليش Fastboot", "Confirm Fastboot Flash"))
            .setMessage(
                t(
                    "سيتم تفليش الملف:\n$fileName\nعلى القسم: $partition\n\nتأكد من توافق الصورة مع الجهاز ومن فتح البوتلودر.",
                    "Flashing:\n$fileName\nTarget partition: $partition\n\nVerify image compatibility and unlocked bootloader before proceeding."
                )
            )
            .setPositiveButton(t("تفليش الآن", "FLASH NOW")) { _, _ ->
                executeFastbootFlash(partition, uri, fileName)
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun executeFastbootFlash(partition: String, uri: Uri, fileName: String) {
        background {
            val pair = connectFastbootDevice() ?: return@background
            val client = pair.second
            var fileSize = 0L
            try {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                    if (afd.length > 0) fileSize = afd.length
                }
            } catch (_: Exception) {}
            if (fileSize <= 0L) {
                (contentResolver.openInputStream(uri) ?: error("Cannot size file")).use { s ->
                    val b = ByteArray(128 * 1024)
                    while (true) {
                        val r = s.read(b)
                        if (r < 0) break
                        fileSize += r
                    }
                }
            }
            log(t("بدء بث $fileName (${fmtSize(fileSize)}) إلى $partition…", "Streaming $fileName (${fmtSize(fileSize)}) to $partition…"))
            val res = (contentResolver.openInputStream(uri) ?: error("Cannot open image stream")).use { stream ->
                client.flashImageStream(partition, fileSize, stream) { sent, total ->
                    val pct = (sent * 100L / total).toInt()
                    if (pct % 20 == 0 || pct == 100) {
                        log("Fastboot [$partition]: $pct% (${fmtSize(sent)} / ${fmtSize(total)})")
                    }
                }
            }
            val msg = if (res.ok) {
                t("✓ تم تفليش القسم $partition بنجاح:\n${res.message}", "✓ Flashed $partition successfully:\n${res.message}")
            } else {
                t("✗ فشل تفليش $partition:\n${res.message}", "✗ Flash failed on $partition:\n${res.message}")
            }
            setFastbootText(msg)
            log(msg)
        }
    }

    private fun showFastbootSlotDialog() {
        val slots = arrayOf("a", "b")
        AlertDialog.Builder(this)
            .setTitle(t("تعيين الـ Slot النشط (set_active)", "Set Active Slot"))
            .setItems(slots) { _, which ->
                val targetSlot = slots[which]
                background {
                    val pair = connectFastbootDevice() ?: return@background
                    val res = pair.second.setActiveSlot(targetSlot)
                    val out = if (res.ok) "set_active:$targetSlot OK\n${res.message}" else "set_active:$targetSlot FAILED: ${res.message}"
                    setFastbootText(out)
                    log(out)
                }
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun showFastbootRebootDialog() {
        val labels = arrayOf(
            t("إعادة تشغيل عادية (System)", "Reboot System"),
            t("إعادة تشغيل للبوتلودر (Bootloader)", "Reboot Bootloader"),
            t("وضع Fastbootd (Userspace)", "Reboot Fastbootd"),
            t("وضع الريكفري (Recovery)", "Reboot Recovery")
        )
        val targets = arrayOf("", "bootloader", "fastboot", "recovery")
        AlertDialog.Builder(this)
            .setTitle(t("إعادة تشغيل عبر Fastboot", "Fastboot Reboot Target"))
            .setItems(labels) { _, which ->
                val tgt = targets[which]
                background {
                    val pair = connectFastbootDevice() ?: return@background
                    val res = pair.second.reboot(tgt)
                    val out = if (res.ok) "Fastboot reboot('${tgt.ifBlank { "system" }}') OK" else "Reboot error: ${res.message}"
                    setFastbootText(out)
                    log(out)
                }
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun showAdbOtgRebootDialog() {
        val targets = arrayOf(
            "download" to t("إدخال سامسونج لوضع Download Mode", "Reboot Samsung to Download Mode"),
            "bootloader" to t("إعادة تشغيل لوضع Bootloader / Fastboot", "Reboot to Bootloader / Fastboot"),
            "recovery" to t("إعادة تشغيل لوضع Recovery", "Reboot to Recovery"),
            "edl" to t("إعادة تشغيل لوضع Qualcomm EDL", "Reboot to Qualcomm EDL"),
            "" to t("إعادة تشغيل عادية (System)", "Reboot System")
        )
        val labels = targets.map { it.second }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(t("تنفيذ إعادة التشغيل عبر ADB OTG", "Execute Reboot via ADB OTG"))
            .setItems(labels) { _, which ->
                val tgt = targets[which].first
                executeAdbOtgReboot(tgt)
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun executeAdbOtgReboot(target: String) {
        val adbDevs = usb.deviceList.values.filter { AdbUsb.isAdbDevice(it) }
        if (adbDevs.isEmpty()) {
            log(t("لا يوجد جهاز متصل مع تفعيل تصحيح USB (ADB) عبر OTG.", "No ADB USB Debugging device connected via OTG."))
            return
        }
        val dev = adbDevs.first()
        if (!usb.hasPermission(dev)) {
            permissionAsked.remove(dev.deviceName)
            requestUsbPermission(dev)
            log(t("تم طلب إذن USB لـ ADB. وافق ثم أعد المحاولة.", "USB permission requested for ADB. Grant and retry."))
            return
        }
        background {
            val adbClient = AdbUsb(this, usb, dev)
            try {
                log(t("جارٍ مصافحة ADB وتوقيع RSA (قد يظهر تأكيد على شاشة الهاتف الآخر)…", "Connecting ADB OTG (check target phone screen for 'Allow USB Debugging')…"))
                val conn = adbClient.connectAndAuthorize()
                if (!conn.ok) {
                    log("ADB Error: ${conn.message}")
                    setOdinStatusText("ADB Error: ${conn.message}")
                    return@background
                }
                val reb = adbClient.rebootTarget(target)
                log(reb.message)
                setOdinStatusText(reb.message)
            } finally {
                adbClient.close()
            }
        }
    }

    // =====================================================================
    // Page 3 Logic: MediaTek Inspector
    // =====================================================================

    private fun inspectMediaTekStatus() {
        val mtkUsb = usb.deviceList.values.filter { it.vendorId == 0x0e8d }
        val localHw = "${Build.HARDWARE} ${Build.BOARD} ${Build.PRODUCT}"
        val decoded = deviceDb.decodeSocHint(localHw)
        val report = buildString {
            append(t("1) معالج الجهاز الحالي:\n", "1) Local Device SoC Check:\n"))
            append("   Hardware: ${Build.HARDWARE} | Board: ${Build.BOARD}\n")
            append("   Decoded: $decoded\n\n")
            append(t("2) أجهزة MediaTek المتصلة عبر OTG (VID 0E8D): ${mtkUsb.size}\n", "2) Connected MTK OTG Devices (VID 0E8D): ${mtkUsb.size}\n"))
            if (mtkUsb.isEmpty()) {
                append(t("   لا يوجد جهاز MTK متصل في وضع BROM أو Preloader حالياً.", "   No MTK BROM/Preloader USB device connected."))
            } else {
                mtkUsb.forEach { d ->
                    append("   • ${usbMode(d)} — VID:%04X PID:%04X (${d.deviceName})\n".format(d.vendorId, d.productId))
                }
            }
            append(t("\n\nملاحظة أمان: التحليل للقراءة فقط (بدون كتابة BROM/Preloader).", "\n\nSafety: Read-only analysis (no BROM/Preloader writes)."))
        }
        setMtkText(report)
        log(t("تم فحص حالة MediaTek: $decoded", "MediaTek check: $decoded"))
    }

    // =====================================================================
    // Page 4 Logic: Qualcomm EDL & rawprogram/patch XML Inspector
    // =====================================================================

    private fun inspectQualcommStatus() {
        val qcomUsb = usb.deviceList.values.filter { it.vendorId == 0x05c6 }
        val localHw = "${Build.HARDWARE} ${Build.BOARD} ${Build.PRODUCT}"
        val decoded = deviceDb.decodeSocHint(localHw)
        val report = buildString {
            append(t("1) عتاد Qualcomm المحلي:\n", "1) Local Qualcomm Hardware Check:\n"))
            append("   Hardware: ${Build.HARDWARE} | Board: ${Build.BOARD}\n")
            append("   Decoded: $decoded\n\n")
            append(t("2) أجهزة Qualcomm المتصلة عبر OTG (VID 05C6): ${qcomUsb.size}\n", "2) Connected Qualcomm OTG Devices (VID 05C6): ${qcomUsb.size}\n"))
            if (qcomUsb.isEmpty()) {
                append(t("   لا يوجد جهاز متصل في وضع EDL 9008 أو Diag حالياً.", "   No Qualcomm EDL 9008 or Diag device connected."))
            } else {
                qcomUsb.forEach { d ->
                    append("   • ${usbMode(d)} — VID:%04X PID:%04X (${d.deviceName})\n".format(d.vendorId, d.productId))
                }
            }
            append(t("\n\nملاحظة أمان: كشف وفحص للقراءة فقط (بدون إرسال Firehose).", "\n\nSafety: Read-only detection & XML analysis (no Firehose writes)."))
        }
        setQcomText(report)
        log(t("تم فحص حالة Qualcomm: ${qcomUsb.size} جهاز OTG.", "Qualcomm check: ${qcomUsb.size} OTG device(s)."))
    }

    private fun chooseQualcommXml() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }, REQ_QUALCOMM_XML)
    }

    private fun analyzeQualcommXml() {
        val uri = qcomXmlUri ?: run {
            log(t("اختر ملف rawprogram*.xml أو patch*.xml أولاً.", "Select a rawprogram*.xml or patch*.xml file first."))
            return
        }
        background {
            val xmlText = (contentResolver.openInputStream(uri) ?: error("Cannot open XML file")).use { input ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_SCATTER_BYTES) error("XML exceeds 4 MB safety limit")
                    out.write(buf, 0, n)
                }
                String(out.toByteArray(), Charsets.UTF_8)
            }

            val rows = ArrayList<String>()
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(xmlText))
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    val tag = parser.name.orEmpty().lowercase(Locale.US)
                    if (tag == "program" || tag == "patch") {
                        val label = parser.getAttributeValue(null, "label").orEmpty()
                        val file = parser.getAttributeValue(null, "filename").orEmpty()
                        val start = parser.getAttributeValue(null, "start_sector").orEmpty()
                        val kb = parser.getAttributeValue(null, "size_in_KB").orEmpty()
                        val sector = parser.getAttributeValue(null, "byte_offset").orEmpty()
                        val title = label.ifBlank { file.ifBlank { tag.uppercase(Locale.US) } }
                        rows.add("• $title | file=${file.ifBlank { "(none)" }} | start=$start | KB=${kb.ifBlank { sector }}")
                    }
                }
                event = parser.next()
            }

            val out = if (rows.isEmpty()) {
                t("لم يُعثر على وسوم <program> أو <patch> صالحة داخل الملف.", "No valid <program> or <patch> tags found in XML.")
            } else {
                buildString {
                    append(t("سجلات Qualcomm XML (${rows.size}):\n\n", "Qualcomm XML Records (${rows.size}):\n\n"))
                    append(rows.take(150).joinToString("\n"))
                    append(t("\n\nتحليل للقراءة فقط — لم يتم تعديل أو تفليش أي قطاع.", "\n\nREAD-ONLY ANALYSIS — no sector written."))
                }
            }
            setQcomText(out)
            log(t("تم تحليل ${rows.size} سجل Qualcomm XML (قراءة فقط).", "Parsed ${rows.size} Qualcomm XML records (read-only)."))
        }
    }

    // =====================================================================
    // Page 5 Logic: Samsung Odin, Download Mode & Firmware Inspector
    // =====================================================================

    private fun closeOdin() {
        try {
            io.execute {
                try { odinClient?.close() } catch (_: Exception) {}
                odinClient = null
                odinDeviceName = null
            }
        } catch (_: Exception) {
            odinClient = null
            odinDeviceName = null
        }
    }

    private fun updateOdinPortBanner() {
        if (!::odinPortBanner.isInitialized) return
        val samDevices = usb.deviceList.values.filter { it.vendorId == OdinUsb.SAMSUNG_VID }
        val dlDev = samDevices.firstOrNull { OdinUsb.isDownloadMode(it) }
        val mtpDev = samDevices.firstOrNull { OdinUsb.isSamsungMtpOrAdb(it) }

        when {
            dlDev != null -> {
                val perm = if (usb.hasPermission(dlDev)) "USB ✓" else "NO PERM"
                odinPortBanner.text = t(
                    "ID:COM [0:OTG] متصل في وضع Download Mode (%04X:%04X) · $perm",
                    "ID:COM [0:OTG] DOWNLOAD MODE CONNECTED (%04X:%04X) · $perm"
                ).format(dlDev.vendorId, dlDev.productId)
                odinPortBanner.setTextColor(Color.rgb(8, 12, 24))
                odinPortBanner.background = roundedBg(colCyan, colEmerald, radiusDp = 10, strokeDp = 1)
            }
            mtpDev != null -> {
                odinPortBanner.text = t(
                    "ID:COM [MTP/ADB] جهاز سامسونج متصل (%04X:%04X) — ليس في وضع Download",
                    "ID:COM [MTP/ADB] SAMSUNG CONNECTED (%04X:%04X) — Enter Download Mode"
                ).format(mtpDev.vendorId, mtpDev.productId)
                odinPortBanner.setTextColor(Color.WHITE)
                odinPortBanner.background = roundedBg(colBtnAmber, colAmber, radiusDp = 10, strokeDp = 1)
            }
            samDevices.isNotEmpty() -> {
                val first = samDevices.first()
                odinPortBanner.text = "ID:COM [SAMSUNG] VID:%04X PID:%04X".format(first.vendorId, first.productId)
                odinPortBanner.setTextColor(Color.WHITE)
                odinPortBanner.background = roundedBg(colBtnPrimary, colCyan, radiusDp = 10, strokeDp = 1)
            }
            else -> {
                odinPortBanner.text = t(
                    "ID:COM [IDLE] — وصّل هاتف سامسونج في وضع Download عبر كابل OTG (VID 04E8)",
                    "ID:COM [IDLE] — Connect Samsung phone in Download Mode via OTG (VID 04E8)"
                )
                odinPortBanner.setTextColor(colMuted)
                odinPortBanner.background = roundedBg(colInputBg, colCardBorder, radiusDp = 10, strokeDp = 1)
            }
        }
    }

    private fun showEnterDownloadModeDialog() {
        val isLocalSam = deviceDb.isSamsungDevice()
        val hasAdbOtg = usb.deviceList.values.any { AdbUsb.isAdbDevice(it) }
        val msg = buildString {
            append(
                t(
                    "طرق إدخال أجهزة سامسونج في وضع Download (Odin Mode):\n\n" +
                        "1) عبر كابل OTG + تصحيح USB (ADB) لهاتف آخر:\n" +
                        "   • اضغط «ADB OTG -> Download» لإدخال الهاتف المتصل مباشرة.\n\n" +
                        "2) عبر أزرار الهاتف (USB-C Galaxy الحديثة):\n" +
                        "   • أطفئ الهاتف، اضغط (رفع + خفض الصوت) معاً ثم وصّل كابل OTG، ثم اضغط رفع الصوت.\n\n" +
                        "3) الأجهزة الأقدم (Home/Bixby):\n" +
                        "   • أطفئ الهاتف ثم اضغط (خفض الصوت + Home/Bixby + التشغيل).\n\n" +
                        "4) هذا الجهاز مباشرة (يتطلب Root):\n" +
                        "   • ينفذ su -c reboot download.",
                    "How to enter Samsung Download Mode (Odin Mode):\n\n" +
                        "1) Connected phone via OTG + USB Debugging (ADB):\n" +
                        "   • Tap 'ADB OTG -> DOWNLOAD' to reboot connected phone directly.\n\n" +
                        "2) Modern USB-C Galaxy keys:\n" +
                        "   • Power off, hold (Vol Up + Vol Down) while plugging OTG cable, then Vol Up.\n\n" +
                        "3) Legacy Galaxy (Home/Bixby):\n" +
                        "   • Hold (Vol Down + Home/Bixby + Power).\n\n" +
                        "4) This local phone (Root): executes su -c reboot download."
                )
            )
            if (isLocalSam) {
                append("\n\n" + t("✓ الجهاز الحالي سامسونج (${Build.MODEL}).", "✓ Current phone is Samsung (${Build.MODEL})."))
            }
            if (hasAdbOtg) {
                append("\n" + t("✓ تم اكتشاف جهاز ADB متصل عبر OTG وجاهز لإعادة التوجيه.", "✓ ADB OTG device detected and ready."))
            }
        }

        val dlg = AlertDialog.Builder(this)
            .setTitle(t("الدخول إلى وضع Download Mode", "Enter Samsung Download Mode"))
            .setMessage(msg)
            .setPositiveButton(
                if (hasAdbOtg) t("ADB OTG -> Download", "ADB OTG -> DOWNLOAD")
                else t("فحص OTG الآن", "SCAN OTG NOW")
            ) { _, _ ->
                if (hasAdbOtg) executeAdbOtgReboot("download") else scanUsb()
            }
            .setNegativeButton(t("إغلاق", "CLOSE"), null)

        if (isLocalSam) {
            dlg.setNeutralButton(t("تنفيذ Root -> Download", "ROOT -> DOWNLOAD")) { _, _ ->
                confirmRootRebootDownload()
            }
        }
        dlg.show()
    }

    private fun confirmRootRebootDownload() {
        AlertDialog.Builder(this)
            .setTitle(t("تأكيد إعادة التشغيل لوضع Download", "Confirm Reboot to Download Mode"))
            .setMessage(
                t(
                    "سيتم تنفيذ الأمر: su -c "reboot download" لإدخال هذا الجهاز (${Build.MODEL}) في وضع Odin. هل تريد المتابعة؟",
                    "This runs 'su -c reboot download' on this device (${Build.MODEL}). Continue?"
                )
            )
            .setPositiveButton(t("تنفيذ الآن", "REBOOT NOW")) { _, _ ->
                background {
                    val hasRoot = runShell("id").contains("uid=0")
                    if (!hasRoot) {
                        val noRoot = t("لم يُكتشف Root على هذا الجهاز. استخدم أزرار الصوت أو ADB OTG.", "Root not available on this device. Use hardware volume keys or ADB OTG.")
                        setOdinStatusText(noRoot)
                        log(noRoot)
                        return@background
                    }
                    log(t("جارٍ إرسال أمر reboot download عبر Root…", "Sending 'reboot download' via Root…"))
                    val out = runShell("reboot download 2>&1")
                    setOdinStatusText(t("تم إرسال أمر reboot download: $out", "Sent reboot download: $out"))
                }
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun connectOdinDevice(): Pair<UsbDevice, OdinUsb>? {
        val candidates = usb.deviceList.values.filter { OdinUsb.isDownloadMode(it) }
        if (candidates.isEmpty()) {
            val mtp = usb.deviceList.values.firstOrNull { OdinUsb.isSamsungMtpOrAdb(it) }
            val msg = if (mtp != null) {
                t(
                    "الجهاز متصل في وضع MTP/ADB (PID %04X) وليس في وضع Download. اضغط «الدخول لوضع Download» أولاً.",
                    "Device connected in MTP/ADB mode (PID %04X), not Download Mode. Tap 'Enter Download Mode' first."
                ).format(mtp.productId)
            } else {
                t(
                    "لم يتم العثور على جهاز سامسونج في وضع Download (VID 04E8 / PID 685D). وصّل الهاتف في وضع Download عبر OTG.",
                    "No Samsung Download Mode device found (VID 04E8 / PID 685D). Connect in Download Mode via OTG."
                )
            }
            setOdinStatusText(msg)
            log(msg)
            return null
        }

        val dev = candidates.first()
        if (!usb.hasPermission(dev)) {
            permissionAsked.remove(dev.deviceName)
            requestUsbPermission(dev)
            val askMsg = t("تم طلب إذن USB لجهاز Odin. وافق على الإذن ثم أعد المحاولة.", "USB permission requested for Odin device. Grant permission and retry.")
            setOdinStatusText(askMsg)
            log(askMsg)
            return null
        }

        try { odinClient?.close() } catch (_: Exception) {}
        val client = OdinUsb(usb, dev)
        val connRes = client.connect()
        if (!connRes.ok) {
            setOdinStatusText("Odin Connect Error: ${connRes.message}")
            log("Odin Connect Error: ${connRes.message}")
            return null
        }
        odinClient = client
        odinDeviceName = dev.deviceName
        return dev to client
    }

    private fun runOdinHandshake() {
        background {
            val pair = connectOdinDevice() ?: return@background
            val dev = pair.first
            val client = pair.second
            val loke = client.handshakeLoke()
            val session = if (loke.ok) client.beginSession() else null
            val report = buildString {
                append(t("حالة اتصال Odin (OTG):\n", "Odin OTG Connection Status:\n"))
                append("USB: VID:%04X PID:%04X (${dev.deviceName})\n".format(dev.vendorId, dev.productId))
                append("Interface: ${loke.interfaceInfo}\n")
                append("Handshake (ODIN -> LOKE): ${loke.message}\n")
                if (session != null) {
                    append("Session: ${session.message}\n")
                }
            }
            setOdinStatusText(report)
            log(loke.message)
        }
    }

    private fun dumpOdinPit() {
        background {
            val pair = connectOdinDevice() ?: return@background
            val client = pair.second
            val loke = client.handshakeLoke()
            if (!loke.ok) {
                setOdinStatusText(loke.message)
                log(loke.message)
                return@background
            }
            val session = client.beginSession()
            if (!session.ok) {
                setOdinStatusText(session.message)
                log(session.message)
                return@background
            }
            val (res, entries) = client.dumpPit()
            val report = buildString {
                append(res.message + "\n\n")
                entries.take(80).forEach { e ->
                    append("[${e.partId}] ${e.partitionName} <- ${e.flashFilename.ifBlank { "(none)" }} (bin=${e.binType}, blocks=${e.blockCount})\n")
                }
                if (entries.size > 80) append("... + ${entries.size - 80} more partitions")
            }
            setOdinStatusText(report)
            log(res.message)
        }
    }

    private fun rebootOdinPhone() {
        background {
            val pair = connectOdinDevice() ?: return@background
            val client = pair.second
            client.handshakeLoke()
            client.beginSession()
            val res = client.endSessionAndReboot(reboot = true)
            setOdinStatusText(res.message)
            log(res.message)
        }
    }

    private fun chooseOdinSlot(idx: Int) {
        if (idx !in ODIN_SLOTS.indices) return
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }, REQ_ODIN_BL + idx)
    }

    private fun inspectOdinSlotHeader(idx: Int, uri: Uri) {
        val slot = ODIN_SLOTS[idx]
        background {
            val report = OdinTarParser.inspectSlot(contentResolver, uri, slot, verifyMd5 = false)
            odinSlotReports[idx] = report
            val summary = buildString {
                append(fmtSize(report.totalBytes))
                report.detectedModel?.let { append(" • $it") }
                report.binaryBit?.let { append(" • BIT:$it") }
                append(" • TAR entries: ${report.tarEntries.size}")
                val pitCount = report.tarEntries.count { it.isPit }
                if (pitCount > 0) append(" (PIT ✓)")
            }
            odinSlotNames[idx] = report.fileName
            odinSlotSummaries[idx] = summary
            ui {
                buildUi()
                scanUsb(logResult = false, askPermission = false)
            }
            log("Odin [$slot] loaded: ${report.fileName} ($summary)")
        }
    }

    private fun verifyAllOdinSlots() {
        val activeIndices = ODIN_SLOTS.indices.filter { odinSlotEnabled[it] && odinSlotUris[it] != null }
        if (activeIndices.isEmpty()) {
            val msg = t("اختر ملف .tar أو .tar.md5 واحد على الأقل في خانات BL / AP / CP / CSC ثم اضغط فحص.", "Select at least one .tar / .tar.md5 file in BL / AP / CP / CSC first.")
            setOdinStatusText(msg)
            log(msg)
            return
        }

        background {
            val reports = ArrayList<OdinSlotReport>()
            activeIndices.forEach { idx ->
                val uri = odinSlotUris[idx] ?: return@forEach
                val slot = ODIN_SLOTS[idx]
                log(t("جارٍ فحص TAR وMD5 للخانة $slot…", "Verifying TAR & MD5 for slot $slot…"))
                val r = OdinTarParser.inspectSlot(contentResolver, uri, slot, verifyMd5 = true)
                odinSlotReports[idx] = r
                reports.add(r)

                val badge = when (r.md5Verified) {
                    true -> "MD5 ✓"
                    false -> "MD5 ✗ MISMATCH"
                    null -> if (r.isTarMd5) "MD5 ?" else "TAR"
                }
                odinSlotSummaries[idx] = buildString {
                    append(fmtSize(r.totalBytes))
                    r.detectedModel?.let { append(" • $it") }
                    r.binaryBit?.let { append(" • BIT:$it") }
                    append(" • ${r.tarEntries.size} files • $badge")
                }
            }

            val models = reports.mapNotNull { it.detectedModel?.take(7) }.distinct()
            val bits = reports.mapNotNull { it.binaryBit }.distinct()
            val md5Failed = reports.any { it.md5Verified == false }

            val fullReport = buildString {
                append(t("=== تقرير التحقق المسبق لحزمة Odin ===\n", "=== ODIN PRE-FLASH VERIFICATION REPORT ===\n"))
                if (models.size > 1) {
                    append(t("⚠ تحذير: تعارض موديلات بين الخانات: ${models.joinToString()}\n", "⚠ WARNING: Model mismatch across slots: ${models.joinToString()}\n"))
                } else if (models.size == 1) {
                    append(t("✓ الموديل متطابق: ${models.first()}\n", "✓ Consistent Model: ${models.first()}\n"))
                }
                if (bits.size > 1) {
                    append(t("⚠ تحذير: اختلاف رقم الحماية (Binary BIT): ${bits.joinToString()}\n", "⚠ WARNING: Binary BIT mismatch: ${bits.joinToString()}\n"))
                } else if (bits.size == 1) {
                    append(t("✓ رقم الحماية (BIT) متطابق: ${bits.first()}\n", "✓ Consistent Binary BIT: ${bits.first()}\n"))
                }

                reports.forEach { r ->
                    append("\n[${r.slotLabel}] ${r.fileName} (${fmtSize(r.totalBytes)})\n")
                    append("  Build: ${r.detectedBuild ?: "N/A"} | BIT: ${r.binaryBit ?: "N/A"}\n")
                    append("  MD5: ${when (r.md5Verified) { true -> "VERIFIED ✓ (${r.computedMd5})"; false -> "FAILED ✗"; null -> r.computedMd5 ?: "N/A" }}\n")
                    if (r.tarEntries.isNotEmpty()) {
                        val preview = r.tarEntries.take(8).joinToString { "${it.name}(${fmtSize(it.sizeBytes)})" }
                        val extra = if (r.tarEntries.size > 8) " + ${r.tarEntries.size - 8} more" else ""
                        append("  Partitions (${r.tarEntries.size}): $preview$extra\n")
                    }
                    r.warnings.forEach { w -> append("  ⚠ $w\n") }
                }

                append("\n")
                append(
                    if (md5Failed || models.size > 1) {
                        t("❌ النتيجة: لا تقم بالتفليش — يوجد تلف في MD5 أو تعارض موديل.", "❌ VERDICT: DO NOT FLASH — MD5 failure or model conflict detected.")
                    } else {
                        t("✅ النتيجة: الحزمة سليمة وجاهزة للتفليش عبر زر START ODIN FLASH.", "✅ VERDICT: Archive integrity & structure verified. Ready to flash via START ODIN FLASH.")
                    }
                )
            }

            setOdinStatusText(fullReport)
            ui {
                buildUi()
                scanUsb(logResult = false, askPermission = false)
            }
            log(t("اكتمل فحص حزم Odin (${reports.size} خانات).", "Odin verification finished (${reports.size} slots)."))
        }
    }

    private fun clearOdinSlots() {
        for (i in ODIN_SLOTS.indices) {
            odinSlotUris[i] = null
            odinSlotNames[i] = null
            odinSlotSummaries[i] = null
            odinSlotReports[i] = null
        }
        odinSlotEnabled[0] = true
        odinSlotEnabled[1] = true
        odinSlotEnabled[2] = true
        odinSlotEnabled[3] = true
        odinSlotEnabled[4] = false
        odinStatusShown = null
        buildUi()
        scanUsb(logResult = false, askPermission = false)
        log(t("تم مسح خانات Odin.", "Odin slots cleared."))
    }

    private fun confirmAndStartOdinFlash() {
        val activeIndices = ODIN_SLOTS.indices.filter { odinSlotEnabled[it] && odinSlotUris[it] != null }
        if (activeIndices.isEmpty()) {
            val msg = t("اختر ملف روم .tar / .tar.md5 في إحدى الخانات (BL / AP / CP / CSC) أولاً.", "Select at least one .tar / .tar.md5 file in BL / AP / CP / CSC first.")
            setOdinStatusText(msg)
            log(msg)
            return
        }
        val hasDl = usb.deviceList.values.any { OdinUsb.isDownloadMode(it) }
        if (!hasDl) {
            val msg = t("يجب توصيل جهاز سامسونج في وضع Download Mode (VID 04E8 / PID 685D) أولاً.", "Connect Samsung device in Download Mode (VID 04E8 / PID 685D) first.")
            setOdinStatusText(msg)
            log(msg)
            return
        }

        val summaryLines = activeIndices.joinToString("\n") { idx ->
            val slot = ODIN_SLOTS[idx]
            val name = odinSlotNames[idx] ?: "package"
            "• [$slot] $name"
        }

        AlertDialog.Builder(this)
            .setTitle(t("تأكيد بدء تفليش Odin", "Confirm Odin Firmware Flash"))
            .setMessage(
                t(
                    "سيتم تفليش الخانات التالية على الهاتف المتصل في وضع Download:\n\n$summaryLines\n\n" +
                        "سيتم فحص التطابق مع جدول PIT وسحب الـ Part IDs وفك ضغط .lz4 تلقائياً.\nلا تفصل كابل OTG أثناء التفليش.",
                    "Flashing the following slots to connected Download Mode device:\n\n$summaryLines\n\n" +
                        "Live PIT partition matching & .lz4 streaming decompression will run automatically.\nDo NOT unplug the OTG cable during flashing."
                )
            )
            .setPositiveButton(t("تفليش وإعادة تشغيل", "FLASH & AUTO REBOOT")) { _, _ ->
                executeOdinFlashSequence(activeIndices, autoReboot = true)
            }
            .setNeutralButton(t("تفليش بدون إعادة تشغيل", "FLASH ONLY")) { _, _ ->
                executeOdinFlashSequence(activeIndices, autoReboot = false)
            }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun executeOdinFlashSequence(activeIndices: List<Int>, autoReboot: Boolean) {
        background {
            val pair = connectOdinDevice() ?: return@background
            val client = pair.second

            log(t("1) مصافحة ODIN -> LOKE…", "1) Handshaking ODIN -> LOKE…"))
            val loke = client.handshakeLoke()
            if (!loke.ok) {
                setOdinStatusText("PASS/FAIL: ${loke.message}")
                log(loke.message)
                return@background
            }

            val sess = client.beginSession()
            if (!sess.ok) {
                setOdinStatusText("Session Failed: ${sess.message}")
                log(sess.message)
                return@background
            }

            log(t("2) سحب جدول الأقسام PIT من الهاتف…", "2) Dumping live PIT table from phone…"))
            val (pitRes, pitEntries) = client.dumpPit()
            if (!pitRes.ok || pitEntries.isEmpty()) {
                setOdinStatusText("PIT Error: ${pitRes.message}")
                log("PIT Error: ${pitRes.message}")
                return@background
            }

            // Prepare flash plan matched against phone PIT
            data class FlashTask(val slot: String, val uri: Uri, val entryName: String, val rawSize: Long, val pit: OdinPitEntry)
            val tasks = ArrayList<FlashTask>()

            for (idx in activeIndices) {
                val uri = odinSlotUris[idx] ?: continue
                val slot = ODIN_SLOTS[idx]
                val rep = odinSlotReports[idx] ?: OdinTarParser.inspectSlot(contentResolver, uri, slot, verifyMd5 = false)

                if (rep.md5Verified == false) {
                    val err = t("❌ توقف: فشل التحقق من MD5 في خانة $slot!", "❌ ABORTED: MD5 mismatch detected in slot $slot!")
                    setOdinStatusText(err)
                    log(err)
                    return@background
                }

                for (tarEntry in rep.tarEntries) {
                    if (tarEntry.isPit || tarEntry.name.endsWith(".asc", true) || tarEntry.name.endsWith(".txt", true)) continue
                    val normalizedBase = tarEntry.name.substringAfterLast('/').removeSuffix(".lz4").lowercase(Locale.US)
                    val matchedPit = pitEntries.firstOrNull { p ->
                        p.flashFilename.equals(normalizedBase, ignoreCase = true) ||
                            p.flashFilename.removeSuffix(".lz4").equals(normalizedBase, ignoreCase = true) ||
                            p.partitionName.equals(normalizedBase.substringBefore('.'), ignoreCase = true)
                    }
                    if (matchedPit == null) {
                        log(t("تخطي ${tarEntry.name} (غير موجود في PIT الهاتف)", "Skipping ${tarEntry.name} (not in device PIT)"))
                        continue
                    }
                    tasks.add(FlashTask(slot, uri, tarEntry.name, tarEntry.sizeBytes, matchedPit))
                }
            }

            if (tasks.isEmpty()) {
                val noMatch = t("❌ لم يتطابق أي ملف داخل الحزم المختارة مع جدول PIT الخاص بالهاتف.", "❌ No entries in selected TAR packages matched this device's PIT table.")
                setOdinStatusText(noMatch)
                log(noMatch)
                return@background
            }

            log(t("3) إعداد الحجم وتفليش ${tasks.size} أقسام…", "3) Preparing transfer sizes for ${tasks.size} partitions…"))
            client.setupFilePartSize(131072)
            val plannedTotal = tasks.sumOf { it.rawSize.coerceAtLeast(0L) }
            var totalBytesSentHeader = false
            if (tasks.size > 1 && plannedTotal > 0L) {
                client.sendTotalBytes(plannedTotal)
                totalBytesSentHeader = true
            }

            var flashedCount = 0
            for (task in tasks) {
                log(t("فتح وبث [${task.slot}] ${task.entryName} -> ${task.pit.partitionName} (ID=${task.pit.partId})…", "Streaming [${task.slot}] ${task.entryName} -> ${task.pit.partitionName} (ID=${task.pit.partId})…"))
                val opened = OdinTarParser.openEntryForFlash(contentResolver, task.uri, task.entryName)
                if (opened == null) {
                    val err = "Failed opening ${task.entryName}"
                    setOdinStatusText(err)
                    log(err)
                    return@background
                }

                val (stream, exactSize) = opened
                if (!totalBytesSentHeader) {
                    client.sendTotalBytes(exactSize)
                    totalBytesSentHeader = true
                }
                val flashRes = stream.use { s ->
                    client.flashPartitionStream(task.pit, s, exactSize) { sent, total ->
                        val pct = (sent * 100L / total).toInt()
                        if (pct % 20 == 0 || pct == 100) {
                            log("Odin [${task.pit.partitionName}]: $pct% (${fmtSize(sent)} / ${fmtSize(total)})")
                        }
                    }
                }
                if (!flashRes.ok) {
                    val err = t("❌ توقف التفليش عند ${task.pit.partitionName}:\n${flashRes.message}", "❌ Flash aborted at ${task.pit.partitionName}:\n${flashRes.message}")
                    setOdinStatusText(err)
                    log(err)
                    return@background
                }
                flashedCount++
            }

            val endRes = client.endSessionAndReboot(autoReboot)
            val finalMsg = t(
                "✅ PASS! تم تفليش $flashedCount قسم بنجاح.\n${endRes.message}",
                "✅ PASS! Flashed $flashedCount partition(s) successfully.\n${endRes.message}"
            )
            setOdinStatusText(finalMsg)
            log(finalMsg)
        }
    }

    private fun inspectSamsungOtg() {
        val samUsb = usb.deviceList.values.filter { it.vendorId == 0x04e8 }
        val localSam = if (deviceDb.isSamsungDevice()) {
            deviceDb.identifyCurrentDevice()
        } else null

        val report = buildString {
            if (localSam != null) {
                append(t("هذا الهاتف جهاز سامسونج (Build.MODEL / Build.PRODUCT):\n", "Local Samsung Device (Build.MODEL / Build.PRODUCT):\n"))
                append(formatSmartSummary(localSam))
                append("\n\n")
            }
            append(t("أجهزة Samsung المتصلة عبر OTG (VID 04E8): ${samUsb.size}\n", "Connected Samsung OTG Devices (VID 04E8): ${samUsb.size}\n"))
            if (samUsb.isEmpty()) {
                append(t("لا يوجد جهاز Samsung متصل عبر OTG حالياً (وضع Download/Odin يعطي PID 685D).", "No Samsung USB device connected (Download/Odin uses PID 685D)."))
            } else {
                samUsb.forEach { d ->
                    append("• ${usbMode(d)} — VID:%04X PID:%04X\n".format(d.vendorId, d.productId))
                    append("  Product: ${d.productName ?: "N/A"}\n")
                }
            }
        }
        setSamsungText(report)
        log(t("تم فحص أجهزة Samsung OTG (${samUsb.size}).", "Checked Samsung OTG (${samUsb.size})."))
    }

    private fun chooseFirmware() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }, REQ_FIRMWARE)
    }

    private fun isInterestingEntry(name: String): Boolean =
        name.endsWith(".img", true) || name.endsWith(".mbn", true) ||
            name.endsWith(".tar", true) || name.endsWith(".md5", true) ||
            name.contains("scatter", true) || name.contains("rawprogram", true) ||
            name.contains("patch", true) || name.contains("payload", true) ||
            name.contains("metadata", true) || name.endsWith(".xml", true)

    private fun inspectFirmware() {
        val uri = selectedUri ?: run {
            log(t("اختر ملفاً أولاً.", "Choose a file first."))
            return
        }
        val model = if (::modelInput.isInitialized) modelInput.text.toString().trim() else modelValue.trim()
        val region = if (::regionInput.isInitialized) regionInput.text.toString().trim() else regionValue.trim()
        background {
            val name = queryDisplayName(uri, "firmware")

            val digest = MessageDigest.getInstance("SHA-256")
            val head = ByteArray(4)
            var headLen = 0
            var total = 0L
            (contentResolver.openInputStream(uri) ?: error("Cannot read file")).use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (headLen < 4) {
                        val c = minOf(4 - headLen, n)
                        System.arraycopy(buffer, 0, head, headLen, c)
                        headLen += c
                    }
                    digest.update(buffer, 0, n)
                    total += n
                }
            }
            val sha = digest.digest().joinToString("") { "%02x".format(it) }
            val isZip = headLen == 4 &&
                head[0] == 0x50.toByte() && head[1] == 0x4b.toByte() &&
                head[2] == 0x03.toByte() && head[3] == 0x04.toByte()

            val entries = ArrayList<String>()
            var scanned = 0
            var truncated = false
            var zipError: String? = null
            if (isZip) {
                try {
                    ZipInputStream(contentResolver.openInputStream(uri) ?: error("Cannot reopen file")).use { zip ->
                        var e = zip.nextEntry
                        while (e != null) {
                            if (++scanned > 20000) {
                                truncated = true
                                break
                            }
                            if (!e.isDirectory && entries.size < 500 && isInterestingEntry(e.name)) {
                                entries.add(e.name)
                            }
                            zip.closeEntry()
                            e = zip.nextEntry
                        }
                    }
                } catch (e: Exception) {
                    zipError = e.message ?: "Malformed or encrypted ZIP"
                }
            }

            val modelRegex = Regex("(RMX\\d{4}|SM-[A-Z]\\d{3,4}[A-Z0-9]*)", RegexOption.IGNORE_CASE)
            val seenModels = (listOf(name) + entries)
                .flatMap { s -> modelRegex.findAll(s).map { it.value.uppercase() }.toList() }
                .toSet()

            val isOdin = (listOf(name) + entries).any {
                it.startsWith("AP_", true) || it.startsWith("BL_", true) ||
                    it.startsWith("CP_", true) || it.startsWith("CSC_", true) ||
                    it.contains(".tar.md5", true)
            }

            val warnings = ArrayList<String>()
            val wanted = model.uppercase()
            if (modelRegex.matches(wanted) && seenModels.isNotEmpty() && seenModels.none { it.startsWith(wanted.take(7)) }) {
                warnings.add(
                    t(
                        "⚠ اسم الملف يشير إلى موديل مختلف: ${seenModels.joinToString()} (المُدخل: $wanted)",
                        "⚠ File names point to a different model: ${seenModels.joinToString()} (entered: $wanted)"
                    )
                )
            }
            if (!isZip) warnings.add(t("ملف منفرد؛ لم يتم تحليل بنيته.", "Single file; internal structure not parsed."))
            if (zipError != null) warnings.add(t("⚠ تعذر قراءة عناصر ZIP بالكامل: $zipError", "⚠ Could not read all ZIP entries: $zipError"))
            if (truncated) warnings.add(t("الأرشيف كبير؛ تم فحص أول 20000 عنصر فقط.", "Large archive; only the first 20000 entries were scanned."))

            val known = if (model.isBlank()) null else deviceDb.identifySmart(model)
            val verdict = if (known == null || region.isBlank()) {
                t(
                    "النتيجة: غير متحقق — يلزم موديل معروف ومنطقة/CSC محددة وبيانات روم موثوقة.",
                    "Result: UNVERIFIED — a known model, region/CSC and trusted firmware metadata are required."
                )
            } else {
                t(
                    "الموديل معروف (${known.marketingName})، لكن التوافق الفعلي مع البناء يتطلب مطابقة SHA-256 والمنطقة.",
                    "Model recognized (${known.marketingName}), verify SHA-256 and regional build before any service."
                )
            }

            val report = buildString {
                append(t("الملف: $name\n", "File: $name\n"))
                append(t("الحجم: ${fmtSize(total)} ($total بايت)\n", "Size: ${fmtSize(total)} ($total bytes)\n"))
                append("SHA-256: $sha\n")
                append(t("النوع: ${if (isZip) "ZIP" else "ملف منفرد"}${if (isOdin) " (Odin AP/BL/CP/CSC)" else ""}\n", "Type: ${if (isZip) "ZIP" else "single file"}${if (isOdin) " (Odin AP/BL/CP/CSC)" else ""}\n"))
                if (seenModels.isNotEmpty()) {
                    append(t("موديلات ظاهرة بالأسماء: ", "Models seen in names: ") + seenModels.joinToString() + "\n")
                }
                if (warnings.isNotEmpty()) append("\n" + warnings.joinToString("\n") + "\n")
                append(t("\nالعناصر (${entries.size}):\n", "\nEntries (${entries.size}):\n"))
                append(entries.joinToString("\n"))
            }
            setFirmwareText(report)
            log(verdict)
            warnings.forEach { log(it) }
        }
    }

    private fun analyzeScatter(targetMtkPanel: Boolean = false) {
        val uri = selectedUri ?: run {
            log(t("اختر ملف Scatter (نصي أو XML) أولاً.", "Select an MTK scatter file (TXT or XML) first."))
            return
        }
        background {
            val bytes = (contentResolver.openInputStream(uri) ?: error("Cannot open selected file")).use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_SCATTER_BYTES) error("Scatter file exceeds 4 MB safety limit")
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
            if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) {
                val msg = t(
                    "الملف المختار أرشيف ZIP. استخرج ملف scatter (.txt أو .xml) أولاً واخترْه.",
                    "Selected file is a ZIP archive. Extract the scatter (.txt or .xml) first and select it."
                )
                if (targetMtkPanel) setMtkText(msg) else setFirmwareText(msg)
                log(msg)
                return@background
            }
            val parts = ScatterParser.parse(String(bytes, Charsets.UTF_8))
            val formatted = ScatterParser.format(parts)
            if (targetMtkPanel) setMtkText(formatted) else setFirmwareText(formatted)
            log(
                t(
                    "تم تحليل ${parts.size} سجل قسم. التحليل للقراءة فقط.",
                    "Parsed ${parts.size} partition records (read-only)."
                )
            )
        }
    }

    // =====================================================================
    // Page 6 Logic: Kernel module (.ko)
    // =====================================================================

    private fun chooseDriver() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }, REQ_DRIVER)
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun findVermagic(file: File): String? {
        val key = "vermagic=".toByteArray(Charsets.US_ASCII)
        val buf = ByteArray(8192)
        var validLen = 0
        file.inputStream().use { input ->
            while (true) {
                val read = input.read(buf, validLen, buf.size - validLen)
                if (read < 0 && validLen == 0) break
                val total = if (read > 0) validLen + read else validLen

                var i = 0
                while (i <= total - key.size) {
                    var match = true
                    for (j in key.indices) {
                        if (buf[i + j] != key[j]) {
                            match = false
                            break
                        }
                    }
                    if (match) {
                        val start = i + key.size
                        var end = start
                        while (end < total && buf[end].toInt() != 0 && end - start < 256) {
                            end++
                        }
                        if (end < total || read < 0) {
                            return String(buf, start, end - start, Charsets.US_ASCII)
                        }
                        break
                    }
                    i++
                }

                if (read < 0) break
                val keep = minOf(total, 512)
                System.arraycopy(buf, total - keep, buf, 0, keep)
                validLen = keep
            }
        }
        return null
    }

    private fun inspectDriver() {
        val uri = driverUri ?: run {
            log(t("اختر ملف .ko أولاً.", "Choose a .ko file first."))
            return
        }
        background {
            driverFile = null
            driverSha = null
            driverVermagicOk = null
            val name = queryDisplayName(uri, "driver")
            if (!name.lowercase(Locale.US).endsWith(".ko")) {
                setDriverText(
                    t(
                        "الملف: $name\nهذا ليس ملف وحدة نواة .ko.",
                        "File: $name\nThis is not an Android .ko kernel module."
                    )
                )
                log(t("نوع الملف غير مدعوم للتثبيت على Android.", "Unsupported module file type."))
                return@background
            }

            val out = File(cacheDir, "driver_module.ko")
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            try {
                (contentResolver.openInputStream(uri) ?: error("Cannot open driver file")).use { input ->
                    FileOutputStream(out).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            total += n
                            if (total > MAX_MODULE_BYTES) error("Module exceeds 32 MB safety limit")
                            digest.update(buffer, 0, n)
                            output.write(buffer, 0, n)
                        }
                    }
                }
                if (total < 64) error("Invalid ELF module file")

                val hdr = ByteArray(20)
                out.inputStream().use { DataInputStream(it).readFully(hdr) }
                val isElf = hdr[0] == 0x7f.toByte() && hdr[1] == 0x45.toByte() &&
                    hdr[2] == 0x4c.toByte() && hdr[3] == 0x46.toByte()
                if (!isElf) error("Invalid ELF module file")
                if (hdr[5].toInt() != 1) error("Unsupported ELF endianness (big-endian)")
                val eType = (hdr[16].toInt() and 0xff) or ((hdr[17].toInt() and 0xff) shl 8)
                val eMachine = (hdr[18].toInt() and 0xff) or ((hdr[19].toInt() and 0xff) shl 8)
                if (eType != 1) error("ELF is not a relocatable kernel module (.ko expected)")

                val (archName, archOk) = when (eMachine) {
                    183 -> "AArch64" to ("arm64-v8a" in Build.SUPPORTED_ABIS)
                    40 -> "ARM" to ("armeabi-v7a" in Build.SUPPORTED_ABIS)
                    62 -> "x86-64" to ("x86_64" in Build.SUPPORTED_ABIS)
                    3 -> "x86" to ("x86" in Build.SUPPORTED_ABIS)
                    else -> "machine=$eMachine" to false
                }

                val kernel = System.getProperty("os.version") ?: ""
                val vermagic = findVermagic(out)
                val vermagicOk = vermagic?.let { it.substringBefore(' ') == kernel }
                val root = runShell("id").contains("uid=0")
                val sha = digest.digest().joinToString("") { "%02x".format(it) }

                driverFile = out
                driverSha = sha
                driverVermagicOk = vermagicOk
                driverHasRoot = root

                val vmLine = when (vermagicOk) {
                    true -> t("vermagic ✓ مطابق للنواة", "vermagic ✓ matches running kernel")
                    false -> t("vermagic ✗ غير مطابق: $vermagic", "vermagic ✗ MISMATCH: $vermagic")
                    null -> t("vermagic غير موجود", "vermagic not found")
                }
                setDriverText(
                    t(
                        "الملف: $name\nالحجم: ${fmtSize(total)}\nSHA-256: $sha\nالمعمارية: $archName ${if (archOk) "✓" else "✗ لا تطابق الجهاز"}\n" +
                            "النواة: ${kernel.ifBlank { "غير معروفة" }}\n$vmLine\nصلاحية Root: ${if (root) "متاحة" else "غير متاحة"}",
                        "File: $name\nSize: ${fmtSize(total)}\nSHA-256: $sha\nArch: $archName ${if (archOk) "✓" else "✗ mismatch"}\n" +
                            "Kernel: ${kernel.ifBlank { "unknown" }}\n$vmLine\nRoot: ${if (root) "available" else "not available"}"
                    )
                )
                log(t("تم فحص ملف .ko دون تحميله.", "Module inspected (not loaded)."))
            } catch (e: Exception) {
                out.delete()
                driverFile = null
                driverSha = null
                setDriverText(t("فشل الفحص: ${e.message}", "Inspection failed: ${e.message}"))
                log(t("تعذر فحص التعريف: ${e.message}", "Driver inspection failed: ${e.message}"))
            }
        }
    }

    private fun confirmDriverInstall() {
        val file = driverFile ?: run {
            log(t("افحص ملف .ko أولاً.", "Inspect a .ko file first."))
            return
        }
        if (!driverHasRoot) {
            log(t("لم يُكتشف Root. لا يمكن تحميل الوحدة.", "Root not detected. Cannot load module."))
            return
        }
        AlertDialog.Builder(this)
            .setTitle(t("تأكيد تحميل تعريف النواة", "Confirm kernel module loading"))
            .setMessage(
                t(
                    "سيتم تنفيذ insmod على ملف ${file.name}. هل تريد المتابعة؟",
                    "This will run insmod on ${file.name}. Proceed?"
                )
            )
            .setPositiveButton(t("تحميل الوحدة", "LOAD MODULE")) { _, _ -> loadDriverModule(file) }
            .setNegativeButton(t("إلغاء", "CANCEL"), null)
            .show()
    }

    private fun loadDriverModule(file: File) {
        background {
            if (!file.exists() || sha256(file) != driverSha) {
                log(t("تغيّر الملف منذ الفحص أو حُذف.", "File changed or missing since inspection."))
                return@background
            }
            val safePath = "'" + file.absolutePath.replace("'", "'\\''") + "'"
            val result = runShell("chmod 600 $safePath && insmod $safePath 2>&1; echo __RUT_EXIT:\$?")
            if (result.contains("__RUT_EXIT:0")) {
                log(t("تم تنفيذ insmod بنجاح.", "insmod completed."))
            } else {
                log(t("نتيجة insmod: $result", "insmod result: $result"))
            }
            val dmesg = runShell("dmesg 2>&1 | tail -n 5")
            if (dmesg.isNotBlank()) log("dmesg:\n$dmesg")
        }
    }

    private fun runShell(command: String, timeoutSec: Long = 20): String {
        val proc = try {
            ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        } catch (_: Exception) {
            return ""
        }
        val out = StringBuilder()
        val reader = Thread {
            try {
                proc.inputStream.bufferedReader().forEachLine { out.append(it).append('\n') }
            } catch (_: Exception) {}
        }
        reader.start()
        return try {
            val finished = proc.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!finished) {
                proc.destroyForcibly()
                "TIMEOUT"
            } else {
                reader.join(2000)
                out.toString().trim()
            }
        } catch (_: Exception) {
            ""
        } finally {
            proc.destroyForcibly()
        }
    }

    // =====================================================================
    // File picking
    // =====================================================================

    private fun queryDisplayName(uri: Uri, fallback: String): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: fallback
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: fallback
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            in REQ_ODIN_BL..REQ_ODIN_USERDATA -> {
                val slotIdx = requestCode - REQ_ODIN_BL
                odinSlotUris[slotIdx] = uri
                odinSlotEnabled[slotIdx] = true
                inspectOdinSlotHeader(slotIdx, uri)
            }
            REQ_FASTBOOT_IMG -> {
                fastbootImgUri = uri
                val name = queryDisplayName(uri, "image.img")
                setFastbootText(t("تم اختيار صورة Fastboot: $name — اضغط FLASH PARTITION للتفليش.", "Selected Fastboot image: $name — tap FLASH PARTITION to execute."))
                log("Fastboot image selected: $name")
            }
            REQ_FIRMWARE -> {
                selectedUri = uri
                val name = queryDisplayName(uri, t("تم اختيار الملف", "File selected"))
                setFirmwareText(name)
                if (currentPage == PAGE_MTK) {
                    setMtkText(t("تم اختيار: $name — اضغط تحليل MTK Scatter.", "Selected: $name — tap Analyze MTK Scatter."))
                }
                log(t("تم اختيار ملف: $name", "File selected: $name"))
            }
            REQ_QUALCOMM_XML -> {
                qcomXmlUri = uri
                val name = queryDisplayName(uri, "rawprogram.xml")
                setQcomText(t("تم اختيار: $name — اضغط تحليل Qualcomm XML.", "Selected: $name — tap Analyze Qualcomm XML."))
                log(t("تم اختيار ملف XML: $name", "Qualcomm XML selected: $name"))
            }
            REQ_DRIVER -> {
                driverUri = uri
                driverFile?.delete()
                driverFile = null
                driverSha = null
                driverVermagicOk = null
                driverHasRoot = false
                setDriverText(
                    queryDisplayName(uri, "driver") + " — " +
                        t("تم اختيار الملف؛ اضغط فحص التوافق.", "Selected; tap Check Module.")
                )
                log(t("تم اختيار ملف تعريف من الذاكرة.", "Driver file selected."))
            }
        }
    }
}
