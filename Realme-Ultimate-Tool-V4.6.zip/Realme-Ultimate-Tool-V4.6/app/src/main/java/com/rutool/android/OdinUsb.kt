package com.rutool.android

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

data class OdinHandshakeResult(
    val ok: Boolean,
    val message: String,
    val protocolVersion: Int? = null,
    val interfaceInfo: String = ""
)

data class OdinPitEntry(
    val binType: Int,
    val devType: Int,
    val partId: Int,
    val blockSizeOrOffset: Long,
    val blockCount: Long,
    val partitionName: String,
    val flashFilename: String,
    val fotaFilename: String
)

/**
 * Samsung Download Mode (Odin / LOKE) USB OTG protocol client.
 * Supports connection, "ODIN" -> "LOKE" handshake, BeginSession, live PIT dump & parser,
 * FileTransfer sequence streaming, EndSession, and Reboot.
 */
class OdinUsb(private val manager: UsbManager, private val device: UsbDevice) {

    companion object {
        const val SAMSUNG_VID = 0x04e8
        val DOWNLOAD_MODE_PIDS = setOf(0x685d, 0x685e, 0x6601)

        private const val CONTROL_PACKET_SIZE = 1024
        private const val RESPONSE_PACKET_SIZE = 8
        private const val PIT_MAGIC = 0x12349876
        private const val PIT_HEADER_SIZE = 28
        private const val PIT_ENTRY_SIZE = 132

        private const val CMD_SESSION = 0x64
        private const val CMD_PIT_FILE = 0x65
        private const val CMD_FILE_TRANSFER = 0x66
        private const val CMD_END_SESSION = 0x67

        private const val SESSION_BEGIN = 0x00
        private const val SESSION_TOTAL_BYTES = 0x02
        private const val SESSION_FILE_PART_SIZE = 0x05

        private const val PIT_DUMP = 0x01
        private const val PIT_PART = 0x02
        private const val PIT_END = 0x03

        private const val FILE_TRANSFER_SEQUENCE = 0x00
        private const val FILE_TRANSFER_BEGIN = 0x02
        private const val FILE_TRANSFER_END = 0x03

        private const val END_SESSION_ONLY = 0x00
        private const val END_SESSION_REBOOT = 0x01

        fun isDownloadMode(d: UsbDevice): Boolean =
            d.vendorId == SAMSUNG_VID && d.productId in DOWNLOAD_MODE_PIDS

        fun isSamsungMtpOrAdb(d: UsbDevice): Boolean =
            d.vendorId == SAMSUNG_VID && (d.productId == 0x6860 || d.productId == 0x6866)
    }

    private var connection: UsbDeviceConnection? = null
    private var dataInterface: UsbInterface? = null
    private var inEndpoint: UsbEndpoint? = null
    private var outEndpoint: UsbEndpoint? = null
    private var boundInfo: String = ""
    var protocolVersion: Int = 2
        private set

    fun connect(): OdinHandshakeResult {
        if (device.vendorId != SAMSUNG_VID) {
            return OdinHandshakeResult(false, "Not a Samsung USB device (VID=%04X)".format(device.vendorId))
        }
        if (!manager.hasPermission(device)) {
            return OdinHandshakeResult(false, "USB permission not granted for Samsung device")
        }

        var chosenIntf: UsbInterface? = null
        var chosenIn: UsbEndpoint? = null
        var chosenOut: UsbEndpoint? = null

        val sortedIndices = (0 until device.interfaceCount).sortedByDescending { idx ->
            when (device.getInterface(idx).interfaceClass) {
                UsbConstants.USB_CLASS_CDC_DATA -> 3
                UsbConstants.USB_CLASS_VENDOR_SPEC -> 2
                else -> 1
            }
        }

        for (i in sortedIndices) {
            val candidate = device.getInterface(i)
            var input: UsbEndpoint? = null
            var output: UsbEndpoint? = null
            for (e in 0 until candidate.endpointCount) {
                val ep = candidate.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN && input == null) input = ep
                    if (ep.direction == UsbConstants.USB_DIR_OUT && output == null) output = ep
                }
            }
            if (input != null && output != null) {
                chosenIntf = candidate
                chosenIn = input
                chosenOut = output
                break
            }
        }

        val targetIntf = chosenIntf ?: return OdinHandshakeResult(
            false,
            "No Bulk IN/OUT interface found on PID %04X (ensure Download Mode 685D)".format(device.productId)
        )

        val conn = manager.openDevice(device)
            ?: return OdinHandshakeResult(false, "Cannot open Samsung USB device")

        if (!conn.claimInterface(targetIntf, true)) {
            conn.close()
            return OdinHandshakeResult(false, "Failed to claim Samsung USB bulk interface")
        }

        connection = conn
        dataInterface = targetIntf
        inEndpoint = chosenIn
        outEndpoint = chosenOut
        boundInfo = "IF#${targetIntf.id} class=${targetIntf.interfaceClass} " +
            "IN=0x%02X OUT=0x%02X".format(chosenIn!!.address, chosenOut!!.address)

        return OdinHandshakeResult(
            ok = true,
            message = "Download Mode bulk interface claimed ($boundInfo)",
            interfaceInfo = boundInfo
        )
    }

    fun handshakeLoke(): OdinHandshakeResult {
        val conn = connection ?: return OdinHandshakeResult(false, "Odin USB not connected")
        val out = outEndpoint ?: return OdinHandshakeResult(false, "Missing bulk OUT endpoint")
        val input = inEndpoint ?: return OdinHandshakeResult(false, "Missing bulk IN endpoint")

        val probe = "ODIN".toByteArray(StandardCharsets.US_ASCII)
        val sent = conn.bulkTransfer(out, probe, probe.size, 3000)
        if (sent != probe.size) {
            return OdinHandshakeResult(
                false,
                "Failed sending ODIN handshake probe (sent=$sent)",
                interfaceInfo = boundInfo
            )
        }

        val reply = ByteArray(64)
        val n = conn.bulkTransfer(input, reply, reply.size, 3000)
        if (n <= 0) {
            return OdinHandshakeResult(
                false,
                "No LOKE reply from Download Mode (bytes=$n). Device may need reconnect.",
                interfaceInfo = boundInfo
            )
        }

        val ascii = String(reply, 0, minOf(n, 4), StandardCharsets.US_ASCII)
        if (ascii == "LOKE") {
            val proto = if (n >= 8) {
                ByteBuffer.wrap(reply, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            } else null

            val verLabel = if (proto != null) " (0x%08X)".format(proto) else ""
            return OdinHandshakeResult(
                ok = true,
                message = "LOKE handshake verified!$verLabel — Download Mode active",
                protocolVersion = proto,
                interfaceInfo = boundInfo
            )
        }

        val hex = reply.take(minOf(n, 16)).joinToString(" ") { "%02X".format(it) }
        return OdinHandshakeResult(false, "Unexpected reply ($n bytes): $hex", interfaceInfo = boundInfo)
    }

    fun beginSession(preferredProto: Int = 4): OdinHandshakeResult {
        val resp = sendControlAndRead(intArrayOf(CMD_SESSION, SESSION_BEGIN, preferredProto))
            ?: return OdinHandshakeResult(false, "No response to BeginSession")
        if (resp.first != CMD_SESSION) {
            return OdinHandshakeResult(false, "BeginSession unexpected cmd=0x%02X".format(resp.first))
        }
        val devVer = (resp.second ushr 16) and 0xffff
        protocolVersion = if (devVer in 1..10) devVer else 2
        return OdinHandshakeResult(
            ok = true,
            message = "Odin Session started (device protocol v$protocolVersion)",
            protocolVersion = protocolVersion,
            interfaceInfo = boundInfo
        )
    }

    fun sendTotalBytes(totalBytes: Long): OdinHandshakeResult {
        if (protocolVersion < 2 || totalBytes <= 0L) {
            return OdinHandshakeResult(true, "TotalBytes skipped (v$protocolVersion)")
        }
        val low = (totalBytes and 0xffffffffL).toInt()
        val high = ((totalBytes ushr 32) and 0xffffffffL).toInt()
        val resp = sendControlAndRead(intArrayOf(CMD_SESSION, SESSION_TOTAL_BYTES, low, high))
            ?: return OdinHandshakeResult(false, "No ACK for TotalBytes")
        return if (resp.first == CMD_SESSION) {
            OdinHandshakeResult(true, "TotalBytes acknowledged ($totalBytes B)")
        } else {
            OdinHandshakeResult(false, "TotalBytes failed (resp=${resp.first})")
        }
    }

    fun setupFilePartSize(packetSize: Int = 131072): OdinHandshakeResult {
        if (protocolVersion < 3) {
            return OdinHandshakeResult(true, "Default 131KB packet size for proto v$protocolVersion")
        }
        val resp = sendControlAndRead(intArrayOf(CMD_SESSION, SESSION_FILE_PART_SIZE, packetSize))
            ?: return OdinHandshakeResult(false, "No ACK for FilePartSize")
        return if (resp.first == CMD_SESSION) {
            OdinHandshakeResult(true, "Packet size negotiated: $packetSize B")
        } else {
            OdinHandshakeResult(false, "FilePartSize failed (resp=${resp.first})")
        }
    }

    fun dumpPit(): Pair<OdinHandshakeResult, List<OdinPitEntry>> {
        val dumpResp = sendControlAndRead(intArrayOf(CMD_PIT_FILE, PIT_DUMP))
            ?: return OdinHandshakeResult(false, "No response to PIT dump request") to emptyList()
        if (dumpResp.first != CMD_PIT_FILE || dumpResp.second <= 0 || dumpResp.second > 256 * 1024) {
            return OdinHandshakeResult(false, "Invalid PIT size: ${dumpResp.second}") to emptyList()
        }

        val pitSize = dumpResp.second
        val pitBytes = ByteArray(pitSize)
        val conn = connection ?: return OdinHandshakeResult(false, "Disconnected") to emptyList()
        val inp = inEndpoint ?: return OdinHandshakeResult(false, "No IN endpoint")

        var collected = 0
        var partIndex = 0
        val chunkBuf = ByteArray(1024)
        while (collected < pitSize) {
            if (!sendControlOnly(intArrayOf(CMD_PIT_FILE, PIT_PART, partIndex))) {
                return OdinHandshakeResult(false, "Failed requesting PIT part $partIndex") to emptyList()
            }
            val n = conn.bulkTransfer(inp, chunkBuf, chunkBuf.size, 5000)
            if (n <= 0) {
                return OdinHandshakeResult(false, "Timeout reading PIT part $partIndex") to emptyList()
            }
            val copyLen = minOf(n, pitSize - collected)
            System.arraycopy(chunkBuf, 0, pitBytes, collected, copyLen)
            collected += copyLen
            partIndex++
        }

        val endResp = sendControlAndRead(intArrayOf(CMD_PIT_FILE, PIT_END))
        if (endResp == null || endResp.first != CMD_PIT_FILE) {
            return OdinHandshakeResult(false, "Failed closing PIT transfer") to emptyList()
        }

        val entries = parsePit(pitBytes)
        return OdinHandshakeResult(true, "PIT dumped: $pitSize bytes, ${entries.size} partitions") to entries
    }

    private fun parsePit(data: ByteArray): List<OdinPitEntry> {
        if (data.size < PIT_HEADER_SIZE) return emptyList()
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val magic = bb.getInt(0)
        if (magic != PIT_MAGIC) return emptyList()
        val count = bb.getInt(4).coerceIn(0, (data.size - PIT_HEADER_SIZE) / PIT_ENTRY_SIZE)

        val list = ArrayList<OdinPitEntry>(count)
        for (i in 0 until count) {
            val base = PIT_HEADER_SIZE + i * PIT_ENTRY_SIZE
            val binType = bb.getInt(base)
            val devType = bb.getInt(base + 4)
            val partId = bb.getInt(base + 8)
            val blockOffset = bb.getInt(base + 20).toLong() and 0xffffffffL
            val blockCount = bb.getInt(base + 24).toLong() and 0xffffffffL
            val partName = readCString(data, base + 36, 32)
            val flashName = readCString(data, base + 68, 32)
            val fotaName = readCString(data, base + 100, 32)
            if (partName.isNotEmpty() || flashName.isNotEmpty()) {
                list.add(
                    OdinPitEntry(
                        binType = binType,
                        devType = devType,
                        partId = partId,
                        blockSizeOrOffset = blockOffset,
                        blockCount = blockCount,
                        partitionName = partName,
                        flashFilename = flashName,
                        fotaFilename = fotaName
                    )
                )
            }
        }
        return list
    }

    fun flashPartitionStream(
        pit: OdinPitEntry,
        stream: InputStream,
        exactBytes: Long,
        packetSize: Int = 131072,
        packetsPerSequence: Int = 30,
        onProgress: (Long, Long) -> Unit
    ): OdinHandshakeResult {
        if (exactBytes <= 0L) return OdinHandshakeResult(false, "Empty partition payload for ${pit.partitionName}")
        val conn = connection ?: return OdinHandshakeResult(false, "Odin USB disconnected")
        val out = outEndpoint ?: return OdinHandshakeResult(false, "Missing OUT endpoint")
        val inp = inEndpoint ?: return OdinHandshakeResult(false, "Missing IN endpoint")

        val beginResp = sendControlAndRead(intArrayOf(CMD_FILE_TRANSFER, FILE_TRANSFER_BEGIN))
            ?: return OdinHandshakeResult(false, "No response to FileTransfer begin (${pit.partitionName})")
        if (beginResp.first != CMD_FILE_TRANSFER) {
            return OdinHandshakeResult(false, "Device rejected FileTransfer begin (cmd=${beginResp.first})")
        }

        val maxSeqBytes = packetSize.toLong() * packetsPerSequence
        val packetBuf = ByteArray(packetSize)
        var remaining = exactBytes
        var totalSent = 0L
        var lastPct = -1

        while (remaining > 0L) {
            val seqEffective = minOf(remaining, maxSeqBytes).toInt()
            val seqPaddedTotal = ((seqEffective + packetSize - 1) / packetSize) * packetSize

            val seqStartResp = sendControlAndRead(
                intArrayOf(CMD_FILE_TRANSFER, FILE_TRANSFER_SEQUENCE, seqPaddedTotal)
            ) ?: return OdinHandshakeResult(false, "No ACK starting sequence at $totalSent B")
            if (seqStartResp.first != CMD_FILE_TRANSFER) {
                return OdinHandshakeResult(false, "Sequence rejected at $totalSent B (cmd=${seqStartResp.first})")
            }

            var seqLeft = seqEffective
            while (seqLeft > 0) {
                packetBuf.fill(0)
                val want = minOf(packetSize, seqLeft)
                var got = 0
                while (got < want) {
                    val r = stream.read(packetBuf, got, want - got)
                    if (r < 0) break
                    got += r
                }
                if (got < want) {
                    return OdinHandshakeResult(false, "Unexpected EOF streaming ${pit.partitionName} at $totalSent B")
                }

                // Send full padded packetSize block over bulk OUT
                var off = 0
                while (off < packetSize) {
                    val tx = conn.bulkTransfer(out, packetBuf, off, packetSize - off, 15000)
                    if (tx <= 0) {
                        return OdinHandshakeResult(false, "USB write error during ${pit.partitionName} (tx=$tx)")
                    }
                    off += tx
                }
                if (out.maxPacketSize > 0 && packetSize % out.maxPacketSize == 0) {
                    conn.bulkTransfer(out, ByteArray(0), 0, 2000)
                }

                seqLeft -= got
                remaining -= got
                totalSent += got
                val pct = ((totalSent * 100L) / exactBytes).toInt()
                if (pct != lastPct) {
                    lastPct = pct
                    onProgress(totalSent, exactBytes)
                }
            }

            val seqAck = readControlResponse(conn, inp, timeoutMs = 20000)
                ?: return OdinHandshakeResult(false, "Missing sequence write ACK at $totalSent B")
            if (seqAck.first != CMD_FILE_TRANSFER) {
                return OdinHandshakeResult(false, "Sequence write failed (cmd=${seqAck.first})")
            }

            val eofFlag = if (remaining <= 0L) 1 else 0
            val destination = if (pit.binType == 1) 1 else 0 // 0=Phone(AP), 1=Modem(CP)
            val endTransferResp = sendControlAndRead(
                intArrayOf(
                    CMD_FILE_TRANSFER,
                    FILE_TRANSFER_END,
                    destination,
                    seqEffective,
                    0,
                    pit.devType,
                    pit.partId,
                    eofFlag,
                    pit.binType
                ),
                timeoutMs = 30000
            ) ?: return OdinHandshakeResult(false, "No ACK finalizing ${pit.partitionName}")

            if (endTransferResp.first != CMD_FILE_TRANSFER) {
                return OdinHandshakeResult(
                    false,
                    "Partition write rejected for ${pit.partitionName} (cmd=${endTransferResp.first}, arg=${endTransferResp.second})"
                )
            }
        }

        return OdinHandshakeResult(true, "Flashed ${pit.partitionName} (${exactBytes} B) OK")
    }

    fun endSessionAndReboot(reboot: Boolean): OdinHandshakeResult {
        val endAck = sendControlAndRead(intArrayOf(CMD_END_SESSION, END_SESSION_ONLY), timeoutMs = 8000)
            ?: return OdinHandshakeResult(false, "No ACK to EndSession")
        if (endAck.first != CMD_END_SESSION) {
            return OdinHandshakeResult(false, "EndSession returned cmd=${endAck.first}")
        }
        if (!reboot) {
            return OdinHandshakeResult(true, "Odin session ended cleanly (device stays in Download Mode)")
        }
        val rebAck = sendControlAndRead(intArrayOf(CMD_END_SESSION, END_SESSION_REBOOT), timeoutMs = 8000)
        return if (rebAck == null || rebAck.first == CMD_END_SESSION) {
            OdinHandshakeResult(true, "Odin session closed and reboot command sent")
        } else {
            OdinHandshakeResult(false, "Reboot response cmd=${rebAck.first}")
        }
    }

    private fun sendControlOnly(words: IntArray, timeoutMs: Int = 5000): Boolean {
        val conn = connection ?: return false
        val out = outEndpoint ?: return false
        val pkt = ByteArray(CONTROL_PACKET_SIZE)
        val bb = ByteBuffer.wrap(pkt).order(ByteOrder.LITTLE_ENDIAN)
        words.forEachIndexed { index, value ->
            if (index * 4 + 4 <= pkt.size) bb.putInt(index * 4, value)
        }
        val sent = conn.bulkTransfer(out, pkt, pkt.size, timeoutMs)
        return sent == pkt.size
    }

    private fun sendControlAndRead(words: IntArray, timeoutMs: Int = 5000): Pair<Int, Int>? {
        val conn = connection ?: return null
        val inp = inEndpoint ?: return null
        if (!sendControlOnly(words, timeoutMs)) return null
        return readControlResponse(conn, inp, timeoutMs)
    }

    private fun readControlResponse(conn: UsbDeviceConnection, inp: UsbEndpoint, timeoutMs: Int): Pair<Int, Int>? {
        val buf = ByteArray(RESPONSE_PACKET_SIZE)
        val n = conn.bulkTransfer(inp, buf, buf.size, timeoutMs)
        if (n < RESPONSE_PACKET_SIZE) return null
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        return bb.getInt(0) to bb.getInt(4)
    }

    private fun readCString(data: ByteArray, offset: Int, maxLen: Int): String {
        var end = offset
        val limit = minOf(data.size, offset + maxLen)
        while (end < limit && data[end].toInt() != 0) end++
        return String(data, offset, end - offset, StandardCharsets.US_ASCII).trim()
    }

    fun close() {
        try {
            if (connection != null && dataInterface != null) {
                connection?.releaseInterface(dataInterface)
            }
        } catch (_: Exception) {}
        try {
            connection?.close()
        } catch (_: Exception) {}
        connection = null
        dataInterface = null
        inEndpoint = null
        outEndpoint = null
    }
}
