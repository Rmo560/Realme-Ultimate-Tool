package com.rutool.android

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.util.Locale

data class ScatterPartition(
    val index: String,
    val name: String,
    val fileName: String,
    val isDownload: String,
    val startAddress: String,
    val size: String,
    val region: String,
    val type: String
)

object ScatterParser {
    private val fieldRegex = Regex("""^\s*(?:-\s*)?([A-Za-z0-9_]+)\s*:\s*(.*?)\s*$""")

    fun parse(text: String): List<ScatterPartition> {
        val trimmed = text.trimStart()
        if (trimmed.startsWith("<")) {
            val xmlParts = parseXml(trimmed)
            if (xmlParts.isNotEmpty()) return xmlParts
        }
        return parseYamlLike(text)
    }

    private fun parseYamlLike(text: String): List<ScatterPartition> {
        val blocks = mutableListOf<MutableMap<String, String>>()
        var current = linkedMapOf<String, String>()

        fun flush() {
            if (current.containsKey("partition_name")) {
                blocks.add(current)
            }
            current = linkedMapOf()
        }

        text.lineSequence().forEach { rawLine ->
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#")) return@forEach

            if (trimmed.startsWith("-") && current.containsKey("partition_name")) {
                flush()
            }

            val match = fieldRegex.matchEntire(trimmed) ?: return@forEach
            val key = match.groupValues[1]
            val value = match.groupValues[2].trim().trim('"', '\'')

            if (key == "partition_name" && current.containsKey("partition_name")) {
                flush()
            }
            current[key] = value
        }
        flush()

        return blocks.map { b ->
            ScatterPartition(
                index = b["partition_index"].orEmpty(),
                name = b["partition_name"].orEmpty(),
                fileName = b["file_name"].orEmpty(),
                isDownload = b["is_download"].orEmpty(),
                startAddress = b["linear_start_addr"].orEmpty().ifBlank { b["physical_start_addr"].orEmpty() },
                size = b["partition_size"].orEmpty(),
                region = b["region"].orEmpty(),
                type = b["type"].orEmpty()
            )
        }
    }

    private fun parseXml(text: String): List<ScatterPartition> {
        val list = mutableListOf<ScatterPartition>()
        try {
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(text))
            var event = parser.eventType
            var currentTag = ""
            var map = linkedMapOf<String, String>()
            var insidePartition = false

            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> {
                        currentTag = parser.name.orEmpty().lowercase(Locale.US)
                        if (currentTag == "partition_index" || currentTag == "partition") {
                            if (map.containsKey("partition_name")) {
                                list.add(toPartition(map))
                            }
                            map = linkedMapOf()
                            insidePartition = true
                            val idxAttr = parser.getAttributeValue(null, "name")
                            if (!idxAttr.isNullOrBlank()) map["partition_index"] = idxAttr
                        }
                    }
                    XmlPullParser.TEXT -> {
                        val v = parser.text?.trim().orEmpty()
                        if (v.isNotEmpty() && currentTag.isNotEmpty()) {
                            if (currentTag == "partition_name") insidePartition = true
                            if (insidePartition) map[currentTag] = v
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        val tag = parser.name.orEmpty().lowercase(Locale.US)
                        if ((tag == "partition_index" || tag == "partition") && map.containsKey("partition_name")) {
                            list.add(toPartition(map))
                            map = linkedMapOf()
                            insidePartition = false
                        }
                        currentTag = ""
                    }
                }
                event = parser.next()
            }
            if (map.containsKey("partition_name")) list.add(toPartition(map))
        } catch (_: Exception) {
            return emptyList()
        }
        return list
    }

    private fun toPartition(b: Map<String, String>) = ScatterPartition(
        index = b["partition_index"].orEmpty(),
        name = b["partition_name"].orEmpty(),
        fileName = b["file_name"].orEmpty(),
        isDownload = b["is_download"].orEmpty(),
        startAddress = b["linear_start_addr"].orEmpty()
            .ifBlank { b["start_address"].orEmpty() }
            .ifBlank { b["physical_start_addr"].orEmpty() },
        size = b["partition_size"].orEmpty().ifBlank { b["size"].orEmpty() },
        region = b["region"].orEmpty(),
        type = b["type"].orEmpty()
    )

    private fun formatSize(raw: String): String {
        if (raw.isBlank()) return "(unknown)"
        val clean = raw.trim().lowercase(Locale.US)
        val bytes = when {
            clean.startsWith("0x") -> clean.removePrefix("0x").toLongOrNull(16)
            else -> clean.toLongOrNull()
        } ?: return raw

        val human = when {
            bytes >= 1L shl 30 -> "%.2f GB".format(Locale.US, bytes / (1024.0 * 1024 * 1024))
            bytes >= 1L shl 20 -> "%.2f MB".format(Locale.US, bytes / (1024.0 * 1024))
            bytes >= 1L shl 10 -> "%.1f KB".format(Locale.US, bytes / 1024.0)
            else -> "$bytes B"
        }
        return "$raw ($human)"
    }

    fun format(parts: List<ScatterPartition>): String {
        if (parts.isEmpty()) return "No partition records found."
        return buildString {
            append("Partitions found: ${parts.size}\n")
            parts.forEachIndexed { index, p ->
                val idxLabel = if (p.index.isNotBlank()) " [${p.index}]" else ""
                append("\n${index + 1}. ${p.name}$idxLabel\n")
                append("   file: ${p.fileName.ifBlank { "(none)" }}\n")
                append("   download: ${p.isDownload.ifBlank { "(unknown)" }}")
                if (p.type.isNotBlank()) append(" | type: ${p.type}")
                append("\n")
                append("   start: ${p.startAddress.ifBlank { "(unknown)" }}\n")
                append("   size: ${formatSize(p.size)}\n")
                append("   region: ${p.region.ifBlank { "(unknown)" }}\n")
            }
            append("\nREAD-ONLY ANALYSIS — no partition was written.")
        }
    }
}
