package com.rutool.android

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Pure-Kotlin streaming LZ4 Frame (magic 0x184D2204) decompressor.
 * Used when streaming .img.lz4 entries from Samsung Odin .tar.md5 packages.
 */
class Lz4FrameInputStream(private val source: InputStream) : InputStream() {

    companion object {
        private const val LZ4_FRAME_MAGIC = 0x184d2204
        private const val WINDOW_SIZE = 65536
        private const val WINDOW_MASK = WINDOW_SIZE - 1

        fun readContentSizeFromHeader(src: InputStream): Long? {
            val h = ByteArray(15)
            val n = readExact(src, h, 0, 7)
            if (n < 7) return null
            val magic = ByteBuffer.wrap(h, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (magic != LZ4_FRAME_MAGIC) return null
            val flg = h[4].toInt() and 0xff
            val hasContentSize = (flg and 0x08) != 0
            if (!hasContentSize) return null
            if (readExact(src, h, 7, 8) < 8) return null
            return ByteBuffer.wrap(h, 6, 8).order(ByteOrder.LITTLE_ENDIAN).long
        }

        private fun readExact(input: InputStream, dst: ByteArray, off: Int, len: Int): Int {
            var total = 0
            while (total < len) {
                val r = input.read(dst, off + total, len - total)
                if (r < 0) break
                total += r
            }
            return total
        }
    }

    private var headerParsed = false
    private var finished = false
    private var hasBlockChecksum = false
    private var blockIndep = true
    private val history = ByteArray(WINDOW_SIZE)
    private var historyPos = 0

    private var outBuf = ByteArray(0)
    private var outPos = 0
    private var outLen = 0

    private fun ensureHeader() {
        if (headerParsed) return
        headerParsed = true

        val magicAndDesc = ByteArray(6)
        if (readExact(source, magicAndDesc, 0, 6) < 6) {
            throw IOException("Truncated LZ4 frame header")
        }
        val magic = ByteBuffer.wrap(magicAndDesc, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        if (magic != LZ4_FRAME_MAGIC) {
            throw IOException("Invalid LZ4 magic: 0x%08X".format(magic))
        }
        val flg = magicAndDesc[4].toInt() and 0xff
        val version = (flg ushr 6) and 0x03
        if (version != 1) throw IOException("Unsupported LZ4 frame version: $version")

        blockIndep = (flg and 0x20) != 0
        hasBlockChecksum = (flg and 0x10) != 0
        val hasContentSize = (flg and 0x08) != 0
        val hasDictId = (flg and 0x01) != 0

        val extraBytes = (if (hasContentSize) 8 else 0) + (if (hasDictId) 4 else 0) + 1 // +1 HC byte
        val extra = ByteArray(extraBytes)
        if (readExact(source, extra, 0, extraBytes) < extraBytes) {
            throw IOException("Truncated LZ4 frame descriptor")
        }
    }

    private fun nextBlock(): Boolean {
        ensureHeader()
        if (finished) return false

        val szBuf = ByteArray(4)
        val n = readExact(source, szBuf, 0, 4)
        if (n == 0) {
            finished = true
            return false
        }
        if (n < 4) throw IOException("Truncated LZ4 block size")

        val rawSizeInt = ByteBuffer.wrap(szBuf).order(ByteOrder.LITTLE_ENDIAN).int
        if (rawSizeInt == 0) {
            finished = true
            return false
        }

        val isUncompressed = (rawSizeInt and Int.MIN_VALUE) != 0
        val blockLen = rawSizeInt and 0x7fffffff
        if (blockLen > 64 * 1024 * 1024) throw IOException("LZ4 block exceeds 64MB limit")

        val compressed = ByteArray(blockLen)
        if (readExact(source, compressed, 0, blockLen) < blockLen) {
            throw IOException("Truncated LZ4 block payload")
        }
        if (hasBlockChecksum) {
            val chk = ByteArray(4)
            readExact(source, chk, 0, 4)
        }

        if (isUncompressed) {
            outBuf = compressed
            outPos = 0
            outLen = blockLen
            if (!blockIndep) {
                for (i in 0 until blockLen) {
                    history[historyPos and WINDOW_MASK] = compressed[i]
                    historyPos++
                }
            }
            return true
        }

        val decoded = decodeLz4Block(compressed, blockLen)
        outBuf = decoded
        outPos = 0
        outLen = decoded.size
        return true
    }

    private fun decodeLz4Block(src: ByteArray, len: Int): ByteArray {
        val out = ByteArrayOutputStream(maxOf(len * 2, 4096))
        var i = 0
        if (blockIndep) historyPos = 0

        while (i < len) {
            val token = src[i++].toInt() and 0xff
            var litLen = (token ushr 4) and 0x0f
            if (litLen == 15) {
                var add: Int
                do {
                    if (i >= len) throw IOException("Corrupt LZ4 literal length")
                    add = src[i++].toInt() and 0xff
                    litLen += add
                } while (add == 255)
            }
            if (i + litLen > len) throw IOException("LZ4 literal overrun")
            for (k in 0 until litLen) {
                val b = src[i++]
                out.write(b.toInt() and 0xff)
                history[historyPos and WINDOW_MASK] = b
                historyPos++
            }
            if (i >= len) break

            if (i + 2 > len) throw IOException("Missing LZ4 match offset")
            val offset = (src[i++].toInt() and 0xff) or ((src[i++].toInt() and 0xff) shl 8)
            if (offset <= 0 || offset > WINDOW_SIZE) throw IOException("Invalid LZ4 match offset: $offset")

            var matchLen = (token and 0x0f) + 4
            if ((token and 0x0f) == 15) {
                var add: Int
                do {
                    if (i >= len) throw IOException("Corrupt LZ4 match length")
                    add = src[i++].toInt() and 0xff
                    matchLen += add
                } while (add == 255)
            }

            for (m in 0 until matchLen) {
                val b = history[(historyPos - offset) and WINDOW_MASK]
                out.write(b.toInt() and 0xff)
                history[historyPos and WINDOW_MASK] = b
                historyPos++
            }
        }
        return out.toByteArray()
    }

    override fun read(): Int {
        val single = ByteArray(1)
        val n = read(single, 0, 1)
        return if (n <= 0) -1 else (single[0].toInt() and 0xff)
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        while (outPos >= outLen) {
            if (!nextBlock()) return -1
        }
        val avail = minOf(len, outLen - outPos)
        System.arraycopy(outBuf, outPos, b, off, avail)
        outPos += avail
        return avail
    }
}
