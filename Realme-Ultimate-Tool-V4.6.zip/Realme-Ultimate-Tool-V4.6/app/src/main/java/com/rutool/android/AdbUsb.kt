package com.rutool.android

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.util.Base64
import java.io.File
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher

data class AdbResult(val ok: Boolean, val message: String)

/**
 * Pure Android SDK USB OTG ADB Host Client.
 * Generates & persists a 2048-bit RSA ADB key in filesDir, completes AUTH handshake
 * (prompting "Allow USB Debugging" on target phone if new), and executes reboot targets or shell commands.
 */
class AdbUsb(
    private val context: Context,
    private val manager: UsbManager,
    private val device: UsbDevice
) {
    companion object {
        private const val CMD_AUTH = 0x48545541
        private const val CMD_CNXN = 0x4e584e43
        private const val CMD_OPEN = 0x4e45504f
        private const val CMD_OKAY = 0x59414b4f
        private const val CMD_CLSE = 0x45534c43
        private const val CMD_WRTE = 0x45545257

        private const val AUTH_TOKEN = 1
        private const val AUTH_SIGNATURE = 2
        private const val AUTH_RSAPUBLICKEY = 3

        private const val ADB_VERSION = 0x01000000
        private const val MAX_DATA = 256 * 1024

        // PKCS#1 v1.5 SHA-1 DigestInfo prefix
        private val SHA1_ASN1_PREFIX = byteArrayOf(
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
        )

        fun isAdbDevice(d: UsbDevice): Boolean =
            (0 until d.interfaceCount).any {
                val x = d.getInterface(it)
                x.interfaceClass == 0xff && x.interfaceSubclass == 0x42 && x.interfaceProtocol == 0x01
            }
    }

    private var connection: UsbDeviceConnection? = null
    private var intf: UsbInterface? = null
    private var inEp: UsbEndpoint? = null
    private var outEp: UsbEndpoint? = null
    private var banner: String = ""

    private data class AdbPacket(val cmd: Int, val arg0: Int, val arg1: Int, val payload: ByteArray)

    fun connectAndAuthorize(): AdbResult {
        if (!manager.hasPermission(device)) return AdbResult(false, "USB permission not granted")

        for (i in 0 until device.interfaceCount) {
            val candidate = device.getInterface(i)
            if (candidate.interfaceClass == 0xff && candidate.interfaceSubclass == 0x42 && candidate.interfaceProtocol == 0x01) {
                var input: UsbEndpoint? = null
                var output: UsbEndpoint? = null
                for (e in 0 until candidate.endpointCount) {
                    val ep = candidate.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) input = ep else output = ep
                    }
                }
                if (input != null && output != null) {
                    val c = manager.openDevice(device) ?: return AdbResult(false, "Cannot open ADB USB device")
                    if (!c.claimInterface(candidate, true)) {
                        c.close()
                        return AdbResult(false, "Cannot claim ADB USB interface")
                    }
                    connection = c
                    intf = candidate
                    inEp = input
                    outEp = output
                    break
                }
            }
        }

        if (connection == null) return AdbResult(false, "No ADB USB interface (FF/42/01) found")

        val keys = loadOrCreateKeys()
        val hostBanner = "host::features=shell_v2,cmd\u0000".toByteArray(StandardCharsets.UTF_8)
        if (!writePacket(CMD_CNXN, ADB_VERSION, MAX_DATA, hostBanner)) {
            return AdbResult(false, "Failed sending ADB CNXN")
        }

        var sentPublicKey = false
        for (attempt in 0 until 12) {
            val timeout = if (sentPublicKey) 20000 else 5000
            val pkt = readPacket(timeout)
                ?: return AdbResult(
                    false,
                    if (sentPublicKey) "Timed out waiting for 'Allow USB Debugging' prompt on target phone."
                    else "No response from target ADB daemon."
                )

            when (pkt.cmd) {
                CMD_CNXN -> {
                    banner = String(pkt.payload, StandardCharsets.UTF_8).trimEnd('\u0000')
                    return AdbResult(true, "ADB connected: $banner")
                }
                CMD_AUTH -> {
                    if (pkt.arg0 == AUTH_TOKEN) {
                        if (!sentPublicKey && attempt == 0) {
                            val sig = signAdbToken(keys.private, pkt.payload)
                            writePacket(CMD_AUTH, AUTH_SIGNATURE, 0, sig)
                            sentPublicKey = true
                        } else {
                            val pub = formatAdbPublicKey(keys.public as RSAPublicKey)
                            writePacket(CMD_AUTH, AUTH_RSAPUBLICKEY, 0, pub)
                            sentPublicKey = true
                        }
                    }
                }
            }
        }
        return AdbResult(false, "ADB authorization failed")
    }

    fun rebootTarget(target: String): AdbResult {
        val svc = "reboot:$target\u0000".toByteArray(StandardCharsets.UTF_8)
        if (!writePacket(CMD_OPEN, 1, 0, svc)) {
            return AdbResult(false, "Failed sending ADB OPEN(reboot:$target)")
        }
        val reply = readPacket(5000)
        return if (reply != null && (reply.cmd == CMD_OKAY || reply.cmd == CMD_CLSE)) {
            AdbResult(true, "ADB reboot '${target.ifBlank { "system" }}' command sent ($banner)")
        } else {
            AdbResult(true, "ADB reboot '${target.ifBlank { "system" }}' dispatched")
        }
    }

    private fun loadOrCreateKeys(): KeyPair {
        val privFile = File(context.filesDir, "adb_rsa_priv.der")
        val pubFile = File(context.filesDir, "adb_rsa_pub.der")
        if (privFile.exists() && pubFile.exists()) {
            try {
                val kf = KeyFactory.getInstance("RSA")
                val priv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes()))
                val pub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes()))
                return KeyPair(pub, priv)
            } catch (_: Exception) {}
        }
        val gen = KeyPairGenerator.getInstance("RSA")
        gen.initialize(2048)
        val kp = gen.generateKeyPair()
        privFile.writeBytes(kp.private.encoded)
        pubFile.writeBytes(kp.public.encoded)
        return kp
    }

    private fun signAdbToken(priv: PrivateKey, token: ByteArray): ByteArray {
        val block = ByteArray(256)
        block[0] = 0x00
        block[1] = 0x01
        val padEnd = 256 - SHA1_ASN1_PREFIX.size - token.size - 1
        for (i in 2 until padEnd) block[i] = 0xff.toByte()
        block[padEnd] = 0x00
        System.arraycopy(SHA1_ASN1_PREFIX, 0, block, padEnd + 1, SHA1_ASN1_PREFIX.size)
        System.arraycopy(token, 0, block, padEnd + 1 + SHA1_ASN1_PREFIX.size, token.size)

        val cipher = Cipher.getInstance("RSA/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, priv)
        return cipher.doFinal(block)
    }

    private fun formatAdbPublicKey(pub: RSAPublicKey): ByteArray {
        val words = 64 // 2048 bits / 32
        val n = pub.modulus
        val base32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = base32.subtract(n.modInverse(base32)).and(BigInteger.valueOf(0xffffffffL)).toInt()
        val rr = BigInteger.ONE.shiftLeft(4096).mod(n)

        val struct = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        struct.putInt(words)
        struct.putInt(n0inv)
        for (i in 0 until words) {
            val w = n.shiftRight(i * 32).and(BigInteger.valueOf(0xffffffffL)).toInt()
            struct.putInt(w)
        }
        for (i in 0 until words) {
            val w = rr.shiftRight(i * 32).and(BigInteger.valueOf(0xffffffffL)).toInt()
            struct.putInt(w)
        }
        struct.putInt(pub.publicExponent.toInt())

        val b64 = Base64.encodeToString(struct.array(), Base64.NO_WRAP)
        return "$b64 BreakerSuite@android\u0000".toByteArray(StandardCharsets.UTF_8)
    }

    private fun writePacket(cmd: Int, arg0: Int, arg1: Int, payload: ByteArray): Boolean {
        val c = connection ?: return false
        val out = outEp ?: return false
        var csum = 0
        for (b in payload) csum += (b.toInt() and 0xff)

        val hdr = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        hdr.putInt(cmd)
        hdr.putInt(arg0)
        hdr.putInt(arg1)
        hdr.putInt(payload.size)
        hdr.putInt(csum)
        hdr.putInt(cmd xor -1)

        val hArr = hdr.array()
        if (c.bulkTransfer(out, hArr, hArr.size, 5000) != hArr.size) return false
        if (payload.isNotEmpty()) {
            if (c.bulkTransfer(out, payload, payload.size, 5000) != payload.size) return false
        }
        return true
    }

    private fun readPacket(timeoutMs: Int): AdbPacket? {
        val c = connection ?: return null
        val inp = inEp ?: return null
        val hdrBuf = ByteArray(24)
        var off = 0
        while (off < 24) {
            val n = c.bulkTransfer(inp, hdrBuf, off, 24 - off, timeoutMs)
            if (n <= 0) return null
            off += n
        }
        val hdr = ByteBuffer.wrap(hdrBuf).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = hdr.getInt(0)
        val arg0 = hdr.getInt(4)
        val arg1 = hdr.getInt(8)
        val len = hdr.getInt(12).coerceIn(0, 1024 * 1024)

        val data = ByteArray(len)
        var dOff = 0
        while (dOff < len) {
            val n = c.bulkTransfer(inp, data, dOff, len - dOff, timeoutMs)
            if (n <= 0) break
            dOff += n
        }
        return AdbPacket(cmd, arg0, arg1, data)
    }

    fun close() {
        try {
            if (connection != null && intf != null) connection?.releaseInterface(intf)
        } catch (_: Exception) {}
        try {
            connection?.close()
        } catch (_: Exception) {}
        connection = null
        intf = null
        inEp = null
        outEp = null
    }
}
