# Realme & Samsung Breaker Suite — V4.6 (CodeAssist Edition)

Full-featured Android servicing & flashing box styled after Breaker hubs for Realme (RMX/CPH), Samsung (SM-), MediaTek, and Qualcomm devices via USB OTG — plus local Root / ADB OTG execution.

## Dedicated Pages inside the App
0. **Breaker Hub**: 2-column servicing command grid, live device/OTG status strip, and quick phone inspection.
1. **Devices & ID**: Identify Realme & Samsung devices via `Build.MODEL` & `Build.PRODUCT`, live search + Show All catalog, ADB OTG RSA-authenticated reboots (`download`, `bootloader`, `recovery`, `edl`), and USB OTG scan.
2. **Fastboot**: Fastboot `getvar` inspection + real execution: flash `.img` partitions (`boot`, `init_boot`, `vendor_boot`, `recovery`, `vbmeta`, `dtbo`, custom), `set_active` A/B slot switching, and Fastboot reboot targets.
3. **MediaTek (MTK)**: Local Helio/Dimensity SoC decoder, MTK BROM/Preloader USB detection, and read-only TXT/XML Scatter parser.
4. **Qualcomm EDL**: Snapdragon hardware check, VID 05C6 (9008/9091) OTG detection, and read-only `rawprogram*.xml` / `patch*.xml` inspector.
5. **Samsung Odin & FW**: Odin ID:COM status bar, Download Mode entry (ADB OTG `reboot:download` + Root `reboot download` + hardware guide), full `ODIN -> LOKE` session & live PIT table dump, streaming `.lz4` decompression, and 5-slot `BL/AP/CP/CSC/USERDATA` `.tar`/`.tar.md5` flashing & auto-reboot.
6. **Kernel (.ko)**: ELF header, ABI, `vermagic` verification, and root `insmod` loader.

## Toolchain Profile
- AGP 8.2.2 / Kotlin 1.9.22 / compileSdk 34 / Gradle 8.2

## Build in CodeAssist (Android)
1. Extract this archive into your CodeAssist projects folder (e.g. `CodeAssistProjects/`).
2. Open CodeAssist -> **Open Existing Project** -> select the extracted folder.
3. Wait for Gradle Sync to finish, then tap **Run / Build APK**.
